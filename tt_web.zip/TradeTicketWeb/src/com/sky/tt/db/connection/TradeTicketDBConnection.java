package com.sky.tt.db.connection;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;


/**
 * 
 * @author Jeff Kazen
 * 
 */
public class TradeTicketDBConnection {
	
	private static final Logger log = Logger.getLogger(TradeTicketDBConnection.class);
	
	private DataSource dataSource;
	//private static TradeTicketDBConnection singleton;

	private static class SingletonHolder {
		private static final TradeTicketDBConnection INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new TradeTicketDBConnection();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	private TradeTicketDBConnection() throws TradeTicketDBException {

		log.debug("Initiating connection to TradeTicket Database test");
		
		try {
			// Get DataSource
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/tradeticket"); 

		} catch (NamingException e) {
			log.error(e);
			throw new TradeTicketDBException("Error getting context/data source: " + e.getMessage(), e);
		}
		
		log.debug("Connection established to TradeTicket Database.");
		
	}

	public static Connection getConnection() throws TradeTicketDBException {

		try {
			return SingletonHolder.INSTANCE.dataSource.getConnection(); //use when running web application
			
			//return DriverManager.getConnection("jdbc:sqlserver://skyapxdb;integratedSecurity=true;database=APXFirm;");
		} catch (SQLException sqle) {
			log.error(sqle);
			throw new TradeTicketDBException("Error getting connection: " + sqle.getMessage(), sqle);
		}
	}

}
