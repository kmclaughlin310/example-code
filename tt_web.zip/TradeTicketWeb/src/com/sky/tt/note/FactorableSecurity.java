package com.sky.tt.note;

import java.util.Map;

import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class FactorableSecurity extends TradeTicketNote {

	public FactorableSecurity(int noteId) {
		super(noteId);
	}

	public void init() throws Exception {
		super.init();
	}

	public String getNote(Security security, Map<String, Object> tradeTicketData) {	
		if (security.getValue(SecurityField.SECURITY_FACTORABLE) != null) {
			return security.getValue(SecurityField.SECURITY_FACTORABLE).toString().equalsIgnoreCase("Y") ? "FACTORABLE SECURITY" : "";
		} else {
			return "";
		}
	}

}
