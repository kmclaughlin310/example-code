package com.sky.tt.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.note.NoteChecker;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityConverter;

public class JSONHandlerDashNotes extends JSONHandlerServlet{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -125017299785640865L;
	private static final Logger log = Logger.getLogger(JSONHandlerDashNotes.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject jsonObj;
		
		String jsonStrInput = request.getParameter("jsonString");

		//create security
		JSONObject jsonObjForSecurity;
		JSONArray jsonSecArray = new JSONArray();
		Security security;
		
		jsonObjForSecurity = new JSONObject(jsonStrInput);
		jsonSecArray = new JSONArray(jsonObjForSecurity.get("SecurityData").toString());
		
		JSONObject tempObj = new JSONObject();
		for (String k : jsonSecArray.getJSONObject(0).keySet()) {
			tempObj.put(k, jsonSecArray.getJSONObject(0).get(k));
		}
		//security = converter.convertBBGMapToSecurity(tempObj.toString());
		if (!jsonObjForSecurity.getString("cusip").equalsIgnoreCase("ni")) {
			security = SecurityConverter.convertBBGMapToSecurity(tempObj.toString());
		} else {
			security = SecurityConverter.convertNewIssueBBGMapToSecurity(tempObj.toString());
		}
		//end create security
		
		//get tradeticketdata
		Map<String, Object> parsedMap = new HashMap<String, Object>();		
		parsedMap = JSONStringConverter.getTTMapFromJSONString(jsonStrInput);
		//end get tradeticketdata
		
		Map<String, String> noteResults = NoteChecker.checkNotes(security, parsedMap);
		
		String jsonStrOutput;
		jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(noteResults);
		
		jsonObj = new JSONObject(jsonStrOutput);
		
		return jsonObj;
	}
}
