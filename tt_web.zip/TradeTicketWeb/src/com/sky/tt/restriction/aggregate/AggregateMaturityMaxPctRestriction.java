package com.sky.tt.restriction.aggregate;



import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregateMaturityMaxPctRestriction extends AggregateRestriction {
	
	private static final Logger log = Logger.getLogger(AggregateMaturityMaxPctRestriction.class);
	
	private static final String CHECK_VALUE_PARAMETER_NAME = "CheckValue";	
	private static final String CHECK_INEQUALITY_PARAMETER_NAME = "CheckInequality";
	
	protected double checkValue;
	protected Inequality checkInequality;

	public AggregateMaturityMaxPctRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		
		super.init();	
		
		checkValue = Double.parseDouble(parameterMap.get(CHECK_VALUE_PARAMETER_NAME).toString());
		checkInequality = Inequality.getInequality(parameterMap.get(CHECK_INEQUALITY_PARAMETER_NAME).toString());
	}

	public Object restrictionApplies(Security security, Portfolio portfolio) {
		
		if (security.getValue(SecurityField.MATURITY_DATE) == null) {
			return true;
		}
		String maturityString = security.getValue(SecurityField.MATURITY_DATE).toString();		
		DateFormat format = new SimpleDateFormat(SecurityField.SECURITY_DATE_FORMAT, Locale.ENGLISH);
		
		Date maturityDate = null;
		Date today = new Date();
		double dateDiff = 0;
		
		try {
			maturityDate = format.parse(maturityString);
		} catch (ParseException e) {
			log.error(e);
			e.printStackTrace();
			return true;
		}
		
		dateDiff = ((maturityDate.getTime() - today.getTime()) / (24 * 60 * 60 * 1000)) / 365.0;

		switch (checkInequality) {
		case LT:
			return dateDiff < checkValue;
		case GT:
			return dateDiff > checkValue;
		case LTE:
			return dateDiff <= checkValue;
		case GTE:
			return dateDiff >= checkValue;
		default:
			return true;		
		}
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			if (action.equalsIgnoreCase("sell") || (Boolean) restrictionApplies(security, portfolio) == false) {
				return 0;
			}
	
			double restrictedPortionPortMktVal;
			double totalPortMktVal;
	
			//assuming buy since it's a max percent restriction i.e. wouldn't need to check restriction if it's a sell
			restrictedPortionPortMktVal = PortfolioMarketValue.getRestrictedPortionMktVal(portfolio, mktValueSQLFunctionName, checkInequality, checkValue, true);
			restrictedPortionPortMktVal = restrictedPortionPortMktVal + ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()); 
			
			//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy
			totalPortMktVal = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
	
			//returns % of limit of the restricted portion
			return (restrictedPortionPortMktVal / totalPortMktVal * 100) / restrictionLimit * 100 ;
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return 999;
		} 
	}
	
	

}
