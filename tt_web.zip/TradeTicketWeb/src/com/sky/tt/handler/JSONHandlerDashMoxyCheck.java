package com.sky.tt.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.FilterClause.FieldComparator;
import com.sky.tt.db.query.MoxyTableQuery;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.util.ErrorHandlingUtility;

public class JSONHandlerDashMoxyCheck extends JSONHandlerServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8923608038950834440L;
	private static final Logger log = Logger.getLogger(JSONHandlerDashMoxyCheck.class);


	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		
		JSONObject jsonObjResult = new JSONObject();
		
		String jsonStrInput = request.getParameter("jsonString");
		JSONObject jsonObj =  new JSONObject(jsonStrInput);
		
		String cusip = jsonObj.getString("CUSIP");
		String secType = jsonObj.getString("SecType");
		Map<String, Object> secRecord =  new HashMap<String, Object>();
		Map<String, Object> result = new HashMap<String, Object>();

		try {
			secRecord = MoxyTableQuery.getRowByStringID("MxSec.SecMaster", "Symbol", cusip, new FilterClause("SecType", FieldComparator.EQ, secType));
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			jsonObjResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return jsonObjResult;
		}
		
		result.put("result", secRecord == null || secRecord.isEmpty() ? "false" : "true");
		
		String jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(result);

		jsonObjResult = new JSONObject(jsonStrOutput);
		
		return jsonObjResult;
	}
}
