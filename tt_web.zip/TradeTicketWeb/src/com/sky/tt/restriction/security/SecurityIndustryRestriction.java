package com.sky.tt.restriction.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityIndustryRestriction extends SecurityRestriction{

	private static final String RESTRICTED_INDUSTRIES_PARAMETER_NAME = "RestrictedIndustryList";
	private static final Logger log = Logger.getLogger(SecurityIndustryRestriction.class);
	
	protected String restrictedIndustryString;

	public SecurityIndustryRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		restrictedIndustryString = parameterMap.get(RESTRICTED_INDUSTRIES_PARAMETER_NAME).toString();		
	}

	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			List<String> restrictedIndustryList = new ArrayList<String>(Arrays.asList(restrictedIndustryString.split("\\s*,\\s*")));
			
			//to make list case insensitive
			Set<String> restrictionListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			restrictionListNoCase.addAll(restrictedIndustryList);
			
			restrictionResultText = "Industry: " + security.getValue(SecurityField.INDUSTRY_GROUP).toString() + ", Sector: " + security.getValue(SecurityField.INDUSTRY_SECTOR).toString();
			//check both industry group and industry sector as done in VBA trade ticket code
			if (restrictionListNoCase.contains(security.getValue(SecurityField.INDUSTRY_GROUP).toString()) || restrictionListNoCase.contains(security.getValue(SecurityField.INDUSTRY_SECTOR).toString())) {
				restrictionTested = true;
				restrictionResult = true;
				return true;
			}
			
			restrictionTested = true;
			restrictionResult = false;
			return false;
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 
		
	}
	
	public String getRestrictedListText() {
		return restrictedIndustryString;
	}

}
