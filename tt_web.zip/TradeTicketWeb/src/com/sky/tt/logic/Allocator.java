package com.sky.tt.logic;

import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.security.Security;


public class Allocator {
	
	private static final String TT_ALLOCATION_OVERRIDE = "AllocationOverride";
	
	private static final Logger log = Logger.getLogger(Allocator.class);

	public double allocatePortfolio(String portCode, Map<String, Object> tradeTicketData, double secHoldingMktVal, double secHoldingQuant, 
			double adjPortMktVal, boolean secRestriction, String action, String allocMethod, double issuerHoldingMktVal, double targetAlloc, 
			double price, double accrInt, Security security) {
		
		double allocQuantity = 0;
		
		if (secRestriction == true && action.equals("buy")) {
			allocQuantity = 0;
		} else if (tradeTicketData.containsKey(portCode + TT_ALLOCATION_OVERRIDE) && ! tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString().equals("")) {
			if (action.equals("buy")) {
				allocQuantity = Double.parseDouble(tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString()) * security.getQuantityFactor();
			} else { //if it's a sell, allocation amount cannot be greater than amount held
				allocQuantity = (Double.parseDouble(tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString()) <= secHoldingQuant ? Double.parseDouble(tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString()) * security.getQuantityFactor() : secHoldingQuant);
			}
		} else if (allocMethod.equalsIgnoreCase("security")) {
			if (action.equals("buy")) {
				if ((secHoldingMktVal / adjPortMktVal * 100) > targetAlloc) { //if current weight is greater than target
					allocQuantity = 0;
				} else { //if current weight is underweight
					allocQuantity = (targetAlloc - (secHoldingMktVal / adjPortMktVal * 100)) * adjPortMktVal / (price + accrInt);
				}
			} else { //sell
				if (targetAlloc == 0) {
					allocQuantity = secHoldingQuant;
				} else if ((secHoldingMktVal / adjPortMktVal * 100) < targetAlloc) { //if current weight is greater than target
					allocQuantity = 0;
				} else { //if current weight is underweight
					allocQuantity = ((secHoldingMktVal / adjPortMktVal * 100) - targetAlloc) * adjPortMktVal / (price + accrInt);
				}
			}
		} else { //weight by ticker
			if (action.equals("buy")) {
				if ((issuerHoldingMktVal / adjPortMktVal * 100) > targetAlloc) { //if current weight is greater than target
					allocQuantity = 0;
				} else { //if current weight is underweight
					allocQuantity = (targetAlloc - (issuerHoldingMktVal / adjPortMktVal * 100)) * adjPortMktVal / (price + accrInt);
				}
			} else { //sell
				if (targetAlloc == 0) {
					allocQuantity = secHoldingQuant;
				} else if ((issuerHoldingMktVal / adjPortMktVal * 100) < targetAlloc) { //if current weight is greater than target
					allocQuantity = 0;
				} else { //if current weight is underweight
					allocQuantity = ((issuerHoldingMktVal / adjPortMktVal * 100) - targetAlloc) * adjPortMktVal / (price + accrInt);
				}
			}
		}
		
		return allocQuantity;
		
	}
	
	public double roundAllocation(Security security, double rawAllocationQuant, String action, double SKYHoldingQuant, boolean override) {		
		//if sell and allocation = holdings, assume full sale and don't round
		//if sell and either allocation > holding or rounded allocation > holding, return sky holdings
		if (action.equalsIgnoreCase("sell") && (rawAllocationQuant == SKYHoldingQuant || rawAllocationQuant > SKYHoldingQuant || Math.round(rawAllocationQuant / security.getRoundingFactor()) * security.getRoundingFactor() > SKYHoldingQuant)) {
			return SKYHoldingQuant;
		} else 	if (override) {
			return rawAllocationQuant;
		} else {
			return Math.round(rawAllocationQuant / security.getRoundingFactor()) * security.getRoundingFactor();
		}
	}

}