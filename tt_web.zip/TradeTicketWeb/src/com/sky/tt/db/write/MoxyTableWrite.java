package com.sky.tt.db.write;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.JDBCUtil;
import com.sky.tt.db.connection.TradeTicketDBConnection;
import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.connection.TradeTicketMoxyDBConnection;
import com.sky.tt.db.filter.Filter;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.filter.GenericFilter;

public class MoxyTableWrite {
private static final Logger log = Logger.getLogger(TableWrite.class);
	
	public static int insertRow(String tableName, Map<String, Object> data) throws TradeTicketDBException {
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		int rowID = 0;
		StringBuilder sql = new StringBuilder("INSERT INTO " + tableName + " (");
		StringBuilder sqlValues = new StringBuilder(" VALUES (");
		List<Object> values = new ArrayList<Object>();
		String separator = " ";
		for (String column : data.keySet()) {
			Object value = data.get(column);
			if (value != null) {
				sql.append(separator + column);
				sqlValues.append(separator + "?");
				separator = ", ";
				values.add(value);
			}
		}
		
		/*sql.append(separator + "LastUpdated, LastUpdatedBy)");
		sqlValues.append(separator + "GETDATE(), ?)");*/
		sql.append(")");
		sqlValues.append(")");
		
		connection = TradeTicketMoxyDBConnection.getConnection();
		
		try {
			statement = connection.prepareStatement(sql.toString() + sqlValues.toString(), Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			for (Object value : values) {
				statement.setObject(i++, value);
			}
			
			//statement.setInt(i, currentUser.getUserID());
			//log.debug(statement.toString());
			
			statement.executeUpdate();
			
			rs = statement.getGeneratedKeys();
			
			if (rs.next()) {
				rowID = rs.getInt(1);
			}
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL error inserting data into the " + tableName + " table: " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(rs, statement, connection);
		} 
		
		return rowID;		
	}
	
	public static int deleteRows(String tableName, Filter filter) throws TradeTicketDBException, FilterException {
		
		// Update rows to store username/time modified.
		/*updateRow(tableName, null, filter, currentUser);*/
		
		Connection connection = null;
		PreparedStatement statement = null;
		int rowsAffected = 0;
		StringBuilder sql = new StringBuilder("DELETE FROM " + tableName + " WHERE 1=1 ");
		if (filter != null) {
			sql.append(filter.getWhereClause());
		}
		
		connection = TradeTicketMoxyDBConnection.getConnection();
		
		try {
			statement = connection.prepareStatement(sql.toString());
			if (filter != null) {
				filter.setParameters(statement, 1);
			}
			
			rowsAffected = statement.executeUpdate();
			
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL error deleting data from the " + tableName + " table: " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(null, statement, connection);
		}
		return rowsAffected;		
	}
	
	public static int deleteRowsByID(String tableName, String columnName, int rowID) throws TradeTicketDBException, FilterException {
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause(columnName, FilterClause.FieldComparator.EQ, new Integer(rowID)));
		return deleteRows(tableName, filter);	
	}
	

	public static int updateRow(String tableName, Map<String, Object> updateData, Filter filter) throws TradeTicketDBException, FilterException {
		Connection connection = null;
		PreparedStatement statement = null;
		int rowsAffected = 0;
		StringBuilder sql = new StringBuilder("UPDATE " + tableName + " SET ");
		List<Object> values = new ArrayList<Object>();
		String separator = " ";
		if (updateData != null) {
			for (String column : updateData.keySet()) {
				Object value = updateData.get(column);
				if (value == null) {
					sql.append(separator + column + " = NULL");
				} else {
					sql.append(separator + column + " = ?");
					values.add(value);
				}
				
				separator = ", ";
			}
			/*sql.append(")");*/
			/*values.add(")");*/
		} else {
			return 0;
		}
		
		/*sql.append(separator + "LastUpdated = GETDATE(), LastUpdatedBy = ? ");*/
		
		/*sql.append(")");
		values.add(")");*/
		
		sql.append(" WHERE 1=1");
		if (filter != null) {
			sql.append(filter.getWhereClause());
		}
		/*log.debug("start");
		log.debug(sql.toString());
		log.debug(values.toString());*/
		connection = TradeTicketMoxyDBConnection.getConnection();
		
		try {
			statement = connection.prepareStatement(sql.toString());
			int i = 1;
			for (Object value : values) {
				statement.setObject(i++, value);
			}
			
			/*statement.setInt(i++, currentUser.getUserID());*/
			
			filter.setParameters(statement, i);
			rowsAffected = statement.executeUpdate();
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL error updating data in the " + tableName + " table: " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(null, statement, connection);
		} 
		
		return rowsAffected;		
	}
	
	public static int updateRowByID(String tableName, Map<String, Object> updateData, String columnName, int rowID) throws TradeTicketDBException, FilterException {
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause(columnName, FilterClause.FieldComparator.EQ, new Integer(rowID)));
		return updateRow(tableName, updateData, filter);
	}
	
	public static void executeStoredProcNoReturn(String procName, Map<Integer, Object> inputParams) throws TradeTicketDBException, FilterException {
		Connection connection = null;
		connection = TradeTicketMoxyDBConnection.getConnection();
		PreparedStatement stmt = null;
		String paramList = "";
		
		//inputparams maps ordinal position of parameter (Integer) to parameter value (Object)
		
		try {
			for (Integer i : inputParams.keySet()) {
				paramList = paramList + "?,";
			}
			paramList = paramList.substring(0, paramList.length() - 1);
			
			stmt = connection.prepareStatement("{call " + procName + "(" + paramList + ")}");
			
			for (Integer i : inputParams.keySet()) {
				stmt.setObject(i, inputParams.get(i));
			}
			
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeEverything(null, stmt, connection);
		}
	}
	
	public static List<Map<String, Object>> executeStoredProcWithReturn(String procName, Map<Integer, Object> inputParams) throws TradeTicketDBException, FilterException {
		Connection connection = null;
		connection = TradeTicketMoxyDBConnection.getConnection();
		PreparedStatement stmt = null;
		String paramList = "";
		ResultSet rs = null;
		
		List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
		
		//inputparams maps ordinal position of parameter (Integer) to parameter value (Object)
		
		try {
			for (Integer i : inputParams.keySet()) {
				paramList = paramList + "?,";
			}
			paramList = paramList.substring(0, paramList.length() - 1);
			
			stmt = connection.prepareStatement("{call " + procName + "(" + paramList + ")}");
			
			for (Integer i : inputParams.keySet()) {
				stmt.setObject(i, inputParams.get(i));
			}

			rs = stmt.executeQuery();
			
			while (rs.next()) {
				Map<String, Object> row = new HashMap<String, Object>();
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnCount = rsmd.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					row.put(rsmd.getColumnName(i), rs.getObject(i));
				}
				rows.add(row);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.closeEverything(rs, stmt, connection);
		}
		
		return rows;		
	}
}








