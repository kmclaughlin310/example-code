package com.sky.tt.restriction.aggregate;



import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregateMaxPctCheckMandRestriction extends AggregateRestriction {
	
	private static final Logger log = Logger.getLogger(AggregateMaxPctCheckMandRestriction.class);
	
	private static final String CHECK_SECURITY_FIELD_PARAMETER_NAME = "CheckField";
	private static final String NULLABLE_PARAMETER_NAME = "Nullable";
	
	protected SecurityField field;
	protected boolean nullable = false;
	
	public AggregateMaxPctCheckMandRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		
		super.init();	
		
		field = SecurityField.getSecurityField(parameterMap.get(CHECK_SECURITY_FIELD_PARAMETER_NAME).toString()); //needs to exactly match field name in SecurityField enum
		
		if (parameterMap.containsKey(NULLABLE_PARAMETER_NAME)) {
			nullable = (parameterMap.get(NULLABLE_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
	}

	@Override
	public Object restrictionApplies(Security security, Portfolio portfolio) {
		String fieldValue = null;
		
		fieldValue = (security.getValue(field) != null ? security.getValue(field).toString() : null);
		
		if (nullable) {
			return (fieldValue != null ? fieldValue : "n/a");
		} else {
			return (fieldValue);
		}
		
	}

	@Override
	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			String restrictedValue = restrictionApplies(security, portfolio).toString();
			
			if (action.equalsIgnoreCase("sell") || restrictedValue == "n/a") {
				return 0;
			}
	
			double restrictedPortionPortMktVal;
			double totalPortMktVal;
	
			//assuming buy since it's a max percent restriction i.e. wouldn't need to check restriction if it's a sell
			restrictedPortionPortMktVal = PortfolioMarketValue.getRestrictedPortionMktVal(portfolio, mktValueSQLFunctionName, Inequality.EQ, restrictedValue, true);
			restrictedPortionPortMktVal = restrictedPortionPortMktVal + ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()); 
			
			//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy
			totalPortMktVal = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
	
			//returns % of limit of the restricted portion
			return (restrictedPortionPortMktVal / totalPortMktVal * 100) / restrictionLimit * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
		
	}

}
