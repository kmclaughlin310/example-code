package com.sky.tt.security.ratingcounter;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.security.Security;

public interface SecurityRatingCounter {
	
	public int getSecurityRatingsCount(Security security, boolean includeEPURatings, boolean includeFitch) throws TradeTicketDBException;

}
