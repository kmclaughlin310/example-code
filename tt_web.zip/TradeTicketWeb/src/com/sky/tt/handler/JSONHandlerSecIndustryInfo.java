package com.sky.tt.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.security.MLIndustryLookupSingleton;
import com.sky.tt.security.APXIndustryLookupSingleton;
import com.sky.util.ErrorHandlingUtility;

public class JSONHandlerSecIndustryInfo extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 812272185256968128L;
	
	private static final Logger log = Logger.getLogger(JSONHandlerSecIndustryInfo.class);


	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject jsonObj = new JSONObject();
		
		String jsonStrInput = request.getParameter("dataString");
		JSONObject jsonInputObj = new JSONObject(jsonStrInput);
		
		String cusip = jsonInputObj.getString("CUSIP");
		String indSubgroupNum = jsonInputObj.getString("IndustrySubgroupNum");
		
		Map<String, Object> secIndustryInfo =  new HashMap<String, Object>();
		
		//try for index grouping
		MLIndustryLookupSingleton mlIndLookup = null;
		try {
			mlIndLookup = MLIndustryLookupSingleton.getInstance();
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			jsonObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return jsonObj;
		}
		
		if (mlIndLookup.inMaster2Index(cusip)) {
			secIndustryInfo.put("sector", mlIndLookup.getIndustrySector(cusip));
			secIndustryInfo.put("group", mlIndLookup.getIndustryGroup(cusip));
			secIndustryInfo.put("masterII", "Y");
		} else {
			APXIndustryLookupSingleton apxIndLookup = null;
			try {
				apxIndLookup = APXIndustryLookupSingleton.getInstance();
			} catch (Exception e) {
				log.error(e);
				e.printStackTrace();
				jsonObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return jsonObj;
			}
			
			
			String groupCode = apxIndLookup.getIndustryGroupCodeFromBBG(indSubgroupNum);
			String sectorCode = apxIndLookup.getIndustrySectorCodeFromBBG(indSubgroupNum);
			
			secIndustryInfo.put("sector", apxIndLookup.getIndustrySector(sectorCode));
			secIndustryInfo.put("group", apxIndLookup.getIndustryGroup(groupCode));
			secIndustryInfo.put("masterII", "N");
			
		}
		
		if (mlIndLookup.getBarclaysIndustry(cusip) != null) {
			secIndustryInfo.put("barclays", mlIndLookup.getBarclaysIndustry(cusip));
		} else {
			secIndustryInfo.put("barclays", "Not in index");
		}
		
		
		String jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(secIndustryInfo);
		jsonObj = new JSONObject(jsonStrOutput);
		
		return jsonObj;
	}

}
