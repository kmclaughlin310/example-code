package com.sky.tt.security;

import java.util.Map;

public class BBGSecurity {
	private Map<BBGSecurityField, Object> fields;
	private String secType;
	private String symbol;
	
	public BBGSecurity(Map<BBGSecurityField, Object> data) {
		fields = data;
		secType = data.get(BBGSecurityField.SECTYPE).toString();
		symbol = data.get(BBGSecurityField.SYMBOL).toString();
	}
	
	public String getSecType() {
		return secType;
	}
	
	public String getSymbol() {
		return symbol;
	}
	
	public Object getValue(BBGSecurityField field) {
		return fields.get(field);
	}
	
	public Object putValue(BBGSecurityField field, Object value) {
		return fields.put(field, value);
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer("SECURITY: " + secType + "/" + symbol + "\n");
		for (BBGSecurityField field : fields.keySet()) {
			buffer.append("\t" + field.getSecurityFieldName() + " = " + fields.get(field) + "\n");
		}
		return buffer.toString();
	}
	
	/*public void processOverrides(Map<BBGSecurityField, Object> overrides) {
		fields.putAll(overrides);
	}
	
	public String shortDescription() {
		
		String date = "";
		
		try {
			date = (new SimpleDateFormat("MM/dd/yyyy").format((new SimpleDateFormat(APXSecurityFormatter.APX_DATE_FORMAT)).parse(fields.get(APXSecurityField.MATURITY_DATE).toString())));
		} catch (Exception ignored) {}
		
		return SKYUtil.isNull(fields.get(APXSecurityField.TICKER), "") + " " 
				+ SKYUtil.isNull(fields.get(APXSecurityField.DIVINT_RATE), "") + (("vbus".equals(secType) ? "VAR " : "% ")) 
				+ date;
	}
	
	public boolean equals(APXSecurity compareTo) {
		for (APXSecurityField field : fields.keySet()) {
			if (!field.isFieldEqual(fields.get(field), compareTo.getValue(field))) {
				return false;
			}
		}
		
		return true;
	}*/
}
