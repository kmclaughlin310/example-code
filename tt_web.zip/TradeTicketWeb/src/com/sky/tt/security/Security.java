package com.sky.tt.security;

import java.util.Map;
import com.sky.util.SKYUtil;

public class Security {

	/*public Object getValue(APXSecurityField secField) {
		// TODO Auto-generated method stub
		return null;
	}*/




	//list of fields - superset of what is pulled into trade ticket from BB and what is stored in APX
	//get list within module in VBA code of trade ticket
	
	//one way to pull data from APX - a couple missing fields, but acceptable for most cases; look at security setup in BB
	//another way to pull data in from BB as json string - constructor can take in json string and construct it as security
	//map of field-value pairs
	//field key will be enum, value will be object
	
	
	
	//security may not exist in APX and without setting up, should have ability to get enough data from BBG to check restrictions
	
	private Map<SecurityField, Object> fields;
	private String secType;
	private String symbol;
	
	/*private static final int SP_FITCH_SQL_RATING_TYPE_ID = 1;
	private static final int SP_FITCH_WARF_SQL_RATING_TYPE_ID = 2;
	private static final int MOODY_SQL_RATING_TYPE_ID = 3;
	private static final int MOODY_WARF_SQL_RATING_TYPE_ID = 4;*/
	
	
	public Security(Map<SecurityField, Object> data) {
		fields = data;
		secType = data.get(SecurityField.SECTYPE).toString();
		symbol = data.get(SecurityField.SYMBOL).toString();
	}
	
	public String getSecType() {
		return secType;
	}
	
	public String getSymbol() {
		return symbol;
	}
	
	public Object getValue(SecurityField field) {
		return fields.get(field);
	}
	
	public Object putValue(SecurityField field, Object value) {
		return fields.put(field, value);
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer("SECURITY: " + secType + "/" + symbol + "\n");
		for (SecurityField field : fields.keySet()) {
			buffer.append("\t" + field.getName() + " = " + fields.get(field) + "\n");
		}
		return buffer.toString();
	}
	
	public void processOverrides(Map<SecurityField, Object> overrides) {
		fields.putAll(overrides);
	}
	
	public String shortDescription() {
		
		return SKYUtil.isNull(fields.get(SecurityField.TICKER), "") + " " 
				+ SKYUtil.isNull(fields.get(SecurityField.DIVINT_RATE), "") + (("vbus".equals(secType) ? "VAR " : "% ")) 
				+ SKYUtil.isNull(fields.get(SecurityField.MATURITY_DATE), "");
	}
	
	public boolean equals(Security compareTo) {
		for (SecurityField field : fields.keySet()) {
			if (!field.isFieldEqual(fields.get(field), compareTo.getValue(field))) {
				return false;
			}
		}
		
		return true;
	}
	
	public double getValuationFactor() {
		String securityType;
		securityType = this.getValue(SecurityField.SECTYPE_OVERRIDE).toString();
		//securityType = security.getValue(SecurityField.SECTYPE_OVERRIDE).toString();
		
		/*<option value="cbus" selected>Corporate Bond</option>
		<option value="vbus">Variable Bond</option>
		<option value="blus">Bank Loan</option>
		<option value="csus">Common Stock</option>*/
		
		if (securityType.equalsIgnoreCase("csus")) {
			return 1.0;
		} else {
			return 100.0;
		}
	}
	
	public static double getValuationFactor(String secType) {
		if (secType.equalsIgnoreCase("csus")) {
			return 1.0;
		} else {
			return 100.0;
		}
	}
	
	public double getQuantityFactor() {
		String securityType;
		securityType = this.getValue(SecurityField.SECTYPE_OVERRIDE).toString();
		//securityType = security.getValue(SecurityField.SECTYPE_OVERRIDE).toString();
		
		if (securityType.equalsIgnoreCase("csus")) {
			return 1.0;
		} else {
			return 1000.0;
		}
	}
	
	public static double getQuantityFactor(String secType) {
		if (secType.equalsIgnoreCase("csus")) {
			return 1.0;
		} else {
			return 1000.0;
		}
	}
	
	public double getRoundingFactor() {
		String securityType;
		securityType = this.getValue(SecurityField.SECTYPE_OVERRIDE).toString();
		//securityType = security.getValue(SecurityField.SECTYPE_OVERRIDE).toString();
		
		if (securityType.equalsIgnoreCase("csus")) {
			return 1.0;
		} else {
			return 5000.0;
		}
	}
	
	
	/*public double getNumericRating(Security security, RatingType ratingType, boolean includeEPURatings) {
		String textRating = null;
		double numericRating = 0;
		
		//get ratings
		Map<String, Object> rating = new HashMap<String, Object>();		
		
		if (includeEPURatings) {
			textRating = ((security.getValue(ratingType.secField) == null) ? "NR" : CleanRating.getCleanRating(security.getValue(ratingType.secField).toString()));
		} else { //if includeEPURatings is false, lookups will fail below when converting from EPU text rating to integer from SQL table
			textRating = ((security.getValue(ratingType.secField) == null) ? "NR" : security.getValue(ratingType.secField).toString());
		}
		
		//rating.get("NumericRating") will be null if it is an EPU rating, therefore give it a -2, as in else case from VBA code in trade ticket
		try {
			rating = TableQuery.getRowByID("CustomTradeTktRestriction.RatingCrossRef", "RatingAgencyID", SP_FITCH_SQL_RATING_TYPE_ID, new FilterClause("TextRating", FilterClause.FieldComparator.EQ, textRating));
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
		}
		if (! rating.isEmpty()) {
			numericRating = (Double) rating.get("NumericRating");
		} else {
			numericRating = -2;
		}
		
		return numericRating;
		
		
	}
	
	public double getNumericRating(Security security, RatingType ratingType) {
		return getNumericRating(security, ratingType, false);
	}*/

	
}
