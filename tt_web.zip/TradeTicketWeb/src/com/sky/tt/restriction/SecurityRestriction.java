package com.sky.tt.restriction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.*;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.security.Security;

public abstract class SecurityRestriction {

	protected int restrictionId;
	protected boolean restrictionResult = true;
	protected boolean restrictionTested = false;
	protected String restrictionResultText = "";
	
	protected Map<String, Object> parameterMap;
	
	public SecurityRestriction(int restrictionId) {
		this.restrictionId = restrictionId;
		this.parameterMap = new HashMap<String, Object>();
	}
	
	public void init() throws Exception {
		
		// code to load key-value pairs from DB
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause("SecurityRestrictionID", FilterClause.FieldComparator.EQ, restrictionId));
		List<Map<String, Object>> parameterMapList = TableQuery.getRows("CustomTradeTktRestriction.SecurityRestrictionParams", filter);
		
		for(Map<String, Object> map : parameterMapList) {
			parameterMap.put(map.get("ParameterName").toString(), map.get("ParameterValue"));
		}
	}
	
	public boolean getRestrictionResult() throws RestrictionException {
		if (!restrictionTested) {
			throw new RestrictionException("Restriction has not been tested.");
		}
		
		return restrictionResult;
	}
	
	public String getRestrictionResultText() throws RestrictionException {
		if (!restrictionTested) {
			throw new RestrictionException("Restriction has not been tested.");
		}
		
		return restrictionResultText;
	}
	
	public String getRestrictedListText() {
		return null;
	}
	
	public abstract boolean checkRestriction(Security security, Portfolio portfolio);
	

	
}
