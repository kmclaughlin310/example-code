package com.sky.tt.restriction;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public abstract class AggregateValRestriction {
	
	protected int restrictionId;
	
	protected Map<String, Object> restrictionMap = new HashMap<String, Object>();
	
	private static final Logger log = Logger.getLogger(AggregateValRestriction.class);
	
	protected int portfolioId;
	protected Inequality inequal;
	protected double restrictionLimitPct;
	protected String holdingsSumColumn;
	protected String holdingsFilterField;
	protected SecurityField secFilterField;
	protected SecurityField denominatorField;
	
	private String PORTFOLIO_COLUMN = "PortfolioID";
	private String INEQUALITY_COLUMN = "RestrictionInequality";
	private String LIMIT_COLUMN = "RestrictionLimitPct";
	private String HOLDINGS_SUM_COLUMN = "HoldingsSumColumn";
	private String HOLDINGS_FILTER_COLUMN = "HoldingsFilterField";
	private String SEC_FILTER_FIELD_COLUMN = "SecurityFilterField";
	private String DENOMINATOR_FIELD_COLUMN = "DenominatorField";
	
	//public abstract double restrictionApplies(Security security, String action, boolean exCash); //return 0 if it does not apply, else returns value of field; i.e. if looking at avg maturity restriction of < 4, will return maturity if > 4
	public abstract double checkRestriction(Security security, Portfolio portfolio, String action, double quantity); //returns % of the limit reached
	 
	public AggregateValRestriction(int restrictionId) {
		this.restrictionId = restrictionId;
	}
	
	public void init() throws Exception {
		
		try {
			restrictionMap = TableQuery.getRowByID("CustomTradeTktRestriction.AggregateValRestrictionList", "AggregateRestrictionID", restrictionId);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
		}
		
		portfolioId = Integer.parseInt(restrictionMap.get(PORTFOLIO_COLUMN).toString());
		inequal = Inequality.getInequality(restrictionMap.get(INEQUALITY_COLUMN).toString());
		restrictionLimitPct = Double.parseDouble(restrictionMap.get(LIMIT_COLUMN).toString());
		holdingsSumColumn = restrictionMap.get(HOLDINGS_SUM_COLUMN).toString();
		holdingsFilterField = restrictionMap.get(HOLDINGS_FILTER_COLUMN).toString();
		secFilterField = SecurityField.getSecurityField(restrictionMap.get(SEC_FILTER_FIELD_COLUMN).toString());
		denominatorField = SecurityField.getSecurityField(restrictionMap.get(DENOMINATOR_FIELD_COLUMN).toString());
		
		//load parameter map from parameter table
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause("AggregateRestrictionID", FilterClause.FieldComparator.EQ, restrictionId));		
	}
	
	public int getPortfolioID() {
		return portfolioId;
	}

	public int getRestrictionID() {
		return restrictionId;
	}
	
	public double getRestrictionLimit() {
		return restrictionLimitPct;
	}
}
