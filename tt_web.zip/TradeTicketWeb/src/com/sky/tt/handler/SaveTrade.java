package com.sky.tt.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.write.TableWrite;
import com.sky.tt.user.UserNotFoundException;
import com.sky.tt.user.UserNotLoggedInException;
import com.sky.tt.user.UserSession;
import com.sky.tt.user.UserSessionException;
import com.sky.util.ErrorHandlingUtility;


public class SaveTrade extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5922156445328219486L;

	private static final Logger log = Logger.getLogger(SaveTrade.class);
	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		
		JSONObject ttObj = new JSONObject(request.getParameter("jsonString").toString());
		JSONObject allocationObj = new JSONObject();
		Map<String, Object> insertData = new HashMap<String, Object>();
		JSONObject returnObj = new JSONObject();
		
		insertData.put("TradeName", ttObj.getString("tradeName"));
		insertData.put("SecDescription", ttObj.getString("secDesc"));
		insertData.put("SecType", ttObj.getString("SECTYPE_OVERRIDE"));
		insertData.put("Ticker", ttObj.getString("ticker"));
		insertData.put("CUSIP", ttObj.getString("cusip"));
		insertData.put("EstPrice", ttObj.getString("price"));
		insertData.put("IDCMark", ttObj.getString("IDCPrice"));
		insertData.put("Action", ttObj.getString("action"));
		insertData.put("LimitComment", ttObj.getString("tradeLimit"));
		insertData.put("TimingComment", ttObj.getString("tradeTiming"));
		insertData.put("NotesComment", ttObj.getString("tradeComments"));
		insertData.put("PMValuationComment", ttObj.getString("valComment"));
		insertData.put("TraderComment", "");
		try {
			insertData.put("SavedBy", UserSession.getUserSessionFromRequest(request).getUser().getUserID());
		} catch (UserNotFoundException e1) {
			log.error(e1);
			e1.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e1));
			return returnObj;
		} catch (UserNotLoggedInException e1) {
			log.error(e1);
			e1.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e1));
			return returnObj;
		} catch (UserSessionException e1) {
			log.error(e1);
			e1.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e1));
			return returnObj;
		}
		
		//add: TargetAllocation 16, AllocationMethod 16, AllocationOverride 18, TotalAllocation 15
		for (String k : ttObj.keySet()) {
			if (k.length() > 18 && (k.substring(k.length() - 15).equalsIgnoreCase("TotalAllocation") || k.substring(k.length() - 16).equalsIgnoreCase("TargetAllocation") || k.substring(k.length() - 16).equalsIgnoreCase("AllocationMethod") || k.substring(k.length() - 18).equalsIgnoreCase("AllocationOverride"))) {
				allocationObj.put(k, ttObj.get(k));
			}
		}
		insertData.put("AllocationJSONString", allocationObj.toString());
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
		String timestamp = sdf.format(date);
		
		insertData.put("SaveDate", timestamp);
		
		try {
			TableWrite.insertRow("CustomTradeTicket.SavedTrades", insertData);
			returnObj.put("message", "Trade succesfully saved.");
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}
		
		return returnObj;
	}

}
