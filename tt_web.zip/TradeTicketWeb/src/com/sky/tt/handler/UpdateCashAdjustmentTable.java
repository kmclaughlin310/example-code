package com.sky.tt.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.filter.FilterClause.FieldComparator;
import com.sky.tt.db.write.TableWrite;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.user.*;
import com.sky.util.ErrorHandlingUtility;



public class UpdateCashAdjustmentTable extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 27767368041021795L;
	private static final Logger log = Logger.getLogger(PreTradeSubmitServlet.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject jsonResult = new JSONObject(); 
		
		UserSession userSession = null;
		
		try {
			userSession = UserSession.getUserSessionFromRequest(request);
		} catch (UserNotFoundException e) {
			log.error(e);
			e.printStackTrace();
			jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return jsonResult;
		} catch (UserNotLoggedInException e) {
			log.error(e);
			e.printStackTrace();
			jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return jsonResult;
		} catch (UserSessionException e) {
			log.error(e);
			e.printStackTrace();
			jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return jsonResult;
		}

		String jsonStrInput = request.getParameter("jsonString");
		log.debug(jsonStrInput);
		
		JSONObject jsonObj;
		jsonObj = new JSONObject(jsonStrInput);

		int portID = Integer.parseInt(jsonObj.getString("PortID"));
		String thruDate = jsonObj.getString("ThruDate");
		String newThruDate = jsonObj.getString("NewThruDate"); //for edit only in case thru date is updated
		double cashAdj = Double.parseDouble(jsonObj.getString("CashAdjustment").replace(",",""));
		double newCashAdj = Double.parseDouble(jsonObj.getString("NewCashAdjustment").replace(",",""));
		String action = jsonObj.getString("Action");
		String notes = jsonObj.getString("Notes");
		Map<String, Object> updateData = new HashMap<String, Object>();
		
		
		//just to update current user
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause("PortfolioID", FieldComparator.EQ, portID));
		filter.addFilterClause(new FilterClause("ThruDate", FieldComparator.EQ, thruDate));
		filter.addFilterClause(new FilterClause("CashAdjustment", FieldComparator.EQ, cashAdj));
		
		log.debug(filter.toString());
		if (action.equalsIgnoreCase("remove")) {
			updateData.put("UserID", userSession.getUser().getUserID());
			try {
				TableWrite.updateRow("CustomTradeTicket.PortfolioCashAdjustments", updateData, filter);
				TableWrite.deleteRows("CustomTradeTicket.PortfolioCashAdjustments", filter);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return jsonResult;
			} catch (FilterException e) {
				log.error(e);
				e.printStackTrace();
				jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return jsonResult;
			} 
		} else if (action.equalsIgnoreCase("add")) {
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
			String formattedDate = sdf.format(date);
			
			updateData.put("PortfolioID", portID);
			updateData.put("ThruDate", thruDate);
			updateData.put("CashAdjustment", cashAdj);
			updateData.put("Notes", notes);
			updateData.put("UserID", userSession.getUser().getUserID());
			updateData.put("EntryDate", formattedDate);
			try {
				TableWrite.insertRow("CustomTradeTicket.PortfolioCashAdjustments", updateData);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return jsonResult;
			}
		} else if (action.equalsIgnoreCase("edit")) {			
			updateData.put("ThruDate", newThruDate);
			updateData.put("CashAdjustment", newCashAdj);
			updateData.put("Notes", notes);
			updateData.put("UserID", userSession.getUser().getUserID());	
			try {
				TableWrite.updateRow("CustomTradeTicket.PortfolioCashAdjustments", updateData, filter);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return jsonResult;
			} catch (FilterException e) {
				log.error(e);
				e.printStackTrace();
				jsonResult.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return jsonResult;
			}
		}
		
		Map<String, String> minorErrors = new HashMap<String, String>();
		try {
			MarketValueSingleton.forceMarketValueSingletonRefresh();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			minorErrors.put("minorError", "Error occurred while refreshing market value singleton.");
		}
		
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("test","test");
		
		String jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(results);
		jsonResult = new JSONObject(jsonStrOutput);
		
		if (! minorErrors.isEmpty()) {
			for (String e : minorErrors.keySet()) {
				results.put(e, minorErrors.get(e));
			}
		}
		
		return jsonResult;
		
	}

}
