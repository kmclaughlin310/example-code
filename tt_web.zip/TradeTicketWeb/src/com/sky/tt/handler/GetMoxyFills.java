package com.sky.tt.handler;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.write.MoxyTableWrite;
import com.sky.util.ErrorHandlingUtility;

public class GetMoxyFills extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -202068982132371062L;
	private static final Logger log = Logger.getLogger(GetMoxyFills.class);
	
	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject returnObj = new JSONObject();
		
		int orderID = Integer.parseInt(request.getParameter("orderID"));
		Map<Integer, Object> inputParams = new HashMap<Integer, Object>();
		List<Map<String, Object>> fillRows = null;
		
		inputParams.put(1, orderID);

		try {
			fillRows = MoxyTableWrite.executeStoredProcWithReturn("pCustGetFillsForOrder", inputParams);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		} catch (FilterException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}

		String tableString = "";
		DecimalFormat numNoDec = new DecimalFormat("#,###");
		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		DecimalFormat numThreeDec = new DecimalFormat("#,###.00");
		SimpleDateFormat noFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		SimpleDateFormat USdate = new SimpleDateFormat("MM/dd/yyyy");
		Map<String, String> minorErrors = new HashMap<String, String>();
		
		for (Map<String, Object> fill : fillRows){
			try {
				tableString = tableString +
						"<tr class='clickFillDetails'><td>" + fill.get("FillID") + "</td>" +
						"<td class='centerAlign'>" + USdate.format(noFormat.parse(fill.get("TradeDate").toString())) + "</td>" +
						"<td class='centerAlign'>" + USdate.format(noFormat.parse(fill.get("SettleDate").toString())) + "</td>" +
						"<td class='rightAlign'>" + numNoDec.format(fill.get("Quantity")) + "</td>" +
						"<td class='rightAlign'>" + numThreeDec.format(fill.get("Price")) + "</td>" +
						"<td class='rightAlign'>" + numNoDec.format(fill.get("Principal")) + "</td>" +
						"<td class='rightAlign'>" + numTwoDec.format(fill.get("AI")) + "</td>" +
						"<td class='rightAlign'>" + numTwoDec.format(fill.get("NetAmount")) + "</td>" +
						"<td class='centerAlign'>" + fill.get("BrokerID") + "</td></tr>";
			} catch (ParseException e) {
				log.error(e);
				e.printStackTrace();
				minorErrors.put("minorError", "Parse error occurred.");
			}			
		}
		
		String jsonStrOutput = "{\"Rows\":\"" + tableString + "\"}";
		returnObj = new JSONObject(jsonStrOutput);
		
		if (! minorErrors.isEmpty()) {
			for (String e : minorErrors.keySet()) {
				returnObj.put(e, minorErrors.get(e));
			}
		}
		
		return returnObj;
	}

}
