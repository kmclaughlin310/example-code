package com.sky.tt.db.filter;

/*import com.sky.skyaudit.db.filter.FilterClause;
import com.sky.skyaudit.db.filter.FilterClause.FieldComparator;

public class FilterClause {

}


package com.sky.skyaudit.db.filter;*/


public class FilterClause {
	
	private String fieldName;
	private FieldComparator comparator;
	private Object value;
	private boolean isAnd;
	private boolean isOpenParen;
	private boolean isCloseParen;
	private String subSelect;
	private boolean addNotBeforeClause;
	
	public FilterClause(String fieldName, FieldComparator comparator, Object value, boolean isAnd, boolean isOpenParen, boolean isCloseParen) {
		this.fieldName = fieldName;
		this.comparator = comparator;
		this.value = value;
		this.isAnd = isAnd;
		this.isOpenParen = isOpenParen;
		this.isCloseParen = isCloseParen;
		this.subSelect = null;
		this.addNotBeforeClause = false;
	}
	
	public FilterClause(String fieldName, FieldComparator comparator, Object value, boolean isAnd, boolean isOpenParen, boolean isCloseParen, boolean addNotBeforeClause) {
		this.fieldName = fieldName;
		this.comparator = comparator;
		this.value = value;
		this.isAnd = isAnd;
		this.isOpenParen = isOpenParen;
		this.isCloseParen = isCloseParen;
		this.subSelect = null;
		this.addNotBeforeClause = addNotBeforeClause;
	}
	
	public FilterClause(String fieldName, FieldComparator comparator, Object value) {
		this.fieldName = fieldName;
		this.comparator = comparator;
		this.value = value;
		this.isAnd = true;
		this.isOpenParen = false;
		this.isCloseParen = false;
		this.subSelect = null;
		this.addNotBeforeClause = false;
	}
	
	public FilterClause(String fieldName, FieldComparator comparator, Object value, boolean isAnd) {
		this.fieldName = fieldName;
		this.comparator = comparator;
		this.value = value;
		this.isAnd = isAnd;
		this.isOpenParen = false;
		this.isCloseParen = false;
		this.subSelect = null;
		this.addNotBeforeClause = false;
	}
	
	//subselect filter clause where value isn't needed - select from table where field =/in (select....)
	public FilterClause(String fieldName, FieldComparator comparator, Object value, boolean isAnd, boolean isOpenParen, boolean isCloseParen, String subSelect) {
		this.fieldName = fieldName;
		this.comparator = comparator;
		this.value = value;
		this.isAnd = isAnd;
		this.isOpenParen = isOpenParen;
		this.isCloseParen = isCloseParen;
		this.subSelect = subSelect;
		this.addNotBeforeClause = false;
	}
	
	public enum FieldComparator {
		
		EQ(" = "), 				// 0
		LT(" < "), 				// 1
		GT(" > "), 				// 2
		LTE(" <= "), 			// 3
		GTE(" >= "), 			// 4
		NE(" <> "),  			// 5
		LIKE(" like "), 		// 6
		NOTLIKE(" not like "),  // 7
		ISNULL(" is null "),    // 8
		ISNOTNULL(" is not null "),  // 9 	
		IN(" in "); //10
		
		private String sql;
		
		private FieldComparator(String sql) {
			this.sql = sql;
		}
		
		public String getSQL() {
			return sql;
		}
		
		public static FieldComparator get(int index) {
			return FieldComparator.values()[index];
		}
		
		public static FieldComparator getFieldComparator(String symbol) {
			for(FieldComparator fc : FieldComparator.values()) {
				if (fc.getSQL().equals(" " + symbol + " ")) {
					return fc;
				}
			}
			return null;
		}
		
	}
	
	public boolean needsValue() {
		return !(comparator == FieldComparator.ISNOTNULL || comparator == FieldComparator.ISNULL);
	}

	public String getFilterSQL() {
		if (!needsValue()) {
			return ((isAnd) ? " AND " : " OR ") + ((addNotBeforeClause) ? " NOT " : "") + ((isOpenParen) ? " ( " : "") + fieldName + comparator.getSQL() + ((isCloseParen) ? " ) " : " ") ;
		} else {
			if (subSelect == null) {
				return ((isAnd) ? " AND " : " OR ") + ((addNotBeforeClause) ? " NOT " : "") + ((isOpenParen) ? " ( " : "") + fieldName + comparator.getSQL() + "?" + ((isCloseParen) ? " ) " : " ") ;
			} else {
				return ((isAnd) ? " AND " : " OR ") + ((addNotBeforeClause) ? " NOT " : "") + ((isOpenParen) ? " ( " : "") + fieldName + comparator.getSQL() + " (" + subSelect + ") " + ((isCloseParen) ? " ) " : " ") ;				
			}
		}	
	}
	
	public Object getValue() {
		return value;
	}
	
	public String toString() {
		if (subSelect == null) {
			return ((isAnd) ? " AND " : " OR ") + ((isOpenParen) ? " ( " : "") + fieldName + comparator.getSQL() + "\"" + value.toString() + "\"" + ((isCloseParen) ? " ) " : " ") ;
		} else {
			return ((isAnd) ? " AND " : " OR ") + ((isOpenParen) ? " ( " : "") + fieldName + comparator.getSQL() + "\"" + "(" + subSelect + ")" + "\"" + ((isCloseParen) ? " ) " : " ");
		}
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((comparator == null) ? 0 : comparator.hashCode());
		result = prime * result
				+ ((fieldName == null) ? 0 : fieldName.hashCode());
		result = prime * result + (isAnd ? 1231 : 1237);
		result = prime * result + (isCloseParen ? 1231 : 1237);
		result = prime * result + (isOpenParen ? 1231 : 1237);
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		FilterClause other = (FilterClause) obj;
		if (comparator != other.comparator) {
			return false;
		}
		if (fieldName == null) {
			if (other.fieldName != null) {
				return false;
			}
		} else if (!fieldName.equals(other.fieldName)) {
			return false;
		}
		if (isAnd != other.isAnd) {
			return false;
		}
		if (isCloseParen != other.isCloseParen) {
			return false;
		}
		if (isOpenParen != other.isOpenParen) {
			return false;
		}
		if (value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!value.equals(other.value)) {
			return false;
		}
		return true;
	}
	
}
