package com.sky.tt.security;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.json.*;
import com.sky.tt.bloomberg.BloombergException;
import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;


public class SecurityConverter {
	
	private static final Logger log = Logger.getLogger(SecurityConverter.class);	
	//private static SecurityConverter securityConverter;
	
	/*
	public static SecurityConverter getInstance() {
		
		if (securityConverter == null) {
			log.debug("Instance does not exist yet, creating a new one.");
			securityConverter = new SecurityConverter();
		}
		
		return securityConverter;
		
	}
	*/
	

	
	public static Security convertBBGMapToSecurity(String jsonSecurityDataString) {
		JSONObject jsonData =  new JSONObject(jsonSecurityDataString);
		Map<String, String> parsedData = new HashMap<String, String>();
	
		for (String keys : jsonData.keySet()) {
			parsedData.put(keys, jsonData.getString(keys));
		}
		
		Map<SecurityField, Object> fieldMap = new HashMap<SecurityField, Object>();
		
		for (BBGSecurityField field : BBGSecurityField.values()) {
			try {
				if (field.getSecurityFieldName().equalsIgnoreCase(SecurityField.ISSUER_OUT.getName())) {
					fieldMap.put(field.getSecurityField(), Double.parseDouble(field.convertField(parsedData).toString()) * 1000);
				} else {
					fieldMap.put(field.getSecurityField(), field.convertField(parsedData));
				}
			} catch (BloombergException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			}
		}
		
		//check for security override and overwrite sectype if available
		if (fieldMap.containsKey(SecurityField.SECTYPE_OVERRIDE) && fieldMap.get(SecurityField.SECTYPE_OVERRIDE) != null) {
			//System.out.println("yes");
			fieldMap.put(SecurityField.SECTYPE, fieldMap.get(SecurityField.SECTYPE_OVERRIDE));
		}
		
		return new Security(fieldMap);		
	}
	
	public static Security convertNewIssueBBGMapToSecurity(String jsonSecurityDataString) {
		JSONObject jsonData =  new JSONObject(jsonSecurityDataString);
		Map<String, String> parsedData = new HashMap<String, String>();
	
		for (String keys : jsonData.keySet()) {
			parsedData.put(keys, jsonData.getString(keys));
		}
		
		//add mandatory fields missing from new issue user inputs
		parsedData.put("ID_CUSIP", "ni");
		parsedData.put("ISSUER", "n/a");
		//parsedData.put("INDUSTRY_SUBGROUP_NUM", "0");
		parsedData.put("144A_FLAG", "");
		parsedData.put("144A_REG_RIGHTS", "");
		parsedData.put("INT_ACC", "0");
		
		//add fields to avoid erroneous restriction violations
		parsedData.put("ID_BB_ULTIMATE_PARENT_CO_NAME", "n/a");
		parsedData.put("COLLAT_TYP", "n/a");
		parsedData.put("REAL_BLOOMBERG_DEPT_DES", "n/a");
		
		
		Map<SecurityField, Object> fieldMap = new HashMap<SecurityField, Object>();
		
		for (BBGSecurityField field : BBGSecurityField.values()) {
			try {
				if (field.getSecurityFieldName().equalsIgnoreCase(SecurityField.ISSUER_OUT.getName())) {
					fieldMap.put(field.getSecurityField(), Double.parseDouble(field.convertField(parsedData).toString()) * 1000);
				} else {
					fieldMap.put(field.getSecurityField(), field.convertField(parsedData));
				}
			} catch (BloombergException e) {
				e.printStackTrace();
				log.error(e);
				return null;
			}
		}
		
		//check for security override and overwrite sectype if available
		if (fieldMap.containsKey(SecurityField.SECTYPE_OVERRIDE) && fieldMap.get(SecurityField.SECTYPE_OVERRIDE) != null) {
			fieldMap.put(SecurityField.SECTYPE, fieldMap.get(SecurityField.SECTYPE_OVERRIDE));
		}
		
		//add group and sector INDUSTRY_GROUP, INDUSTRY_SECTOR
		fieldMap.put(SecurityField.INDUSTRY_GROUP, parsedData.get("INDUSTRY_GROUP").toString());	
		try {
			fieldMap.put(SecurityField.INDUSTRY_SECTOR, TableQuery.getRowByID("AdvApp.vIndustrySector", "SectorID", Integer.parseInt(parsedData.get("INDUSTRY_SECTOR").toString())).get("SectorCode").toString());
		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		return new Security(fieldMap);		
	}
	
	
	
}
