package com.sky.util;

import java.util.EnumMap;

public class SKYUtil {

	
	public static Object isNull(Object test, Object replacement) {
		if (test == null) {
			return replacement;
		} else {
			return test;
		}
	}
	
	
	public static <K extends Enum<K>, V> EnumMap<K, V> loadArrayIntoEnumMap(Class<K> type, V[] array) {
		
		EnumMap<K, V> value = new EnumMap<K, V>(type);
		
		for (K enumValue : type.getEnumConstants()) {
			value.put(enumValue, array[enumValue.ordinal()]);
		}
		
		return value;
	}
}
