package com.sky.tt.restriction;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.Security;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;

public abstract class AggregateRestriction {
	
	protected int restrictionId;
	
	protected Map<String, Object> restrictionMap = new HashMap<String, Object>();
	
	private static final Logger log = Logger.getLogger(AggregateRestriction.class);
	
	protected int portfolioId;
	protected String mktValueSQLFunctionName;
	protected Inequality inequal;
	protected double restrictionLimit;
	protected boolean exCash = false;
	protected List<Map<String, Object>> parameterMapList;
	protected Map<String, Object> parameterMap;
	
	private String PORTFOLIO_COLUMN = "PortfolioID";
	private String SQL_FUNCTION_NAME_COLUMN = "MarketValueSQLFunctionName";
	private String INEQUALITY_COLUMN = "RestrictionInequality";
	private String LIMIT_COLUMN = "RestrictionLimitPct";
	private String EX_CASH_COLUMN = "ExCash";
	
	
	public abstract Object restrictionApplies(Security security, Portfolio portfolio); //returns null if restriction does not apply; else returns arbitrary value (i.e. if checking CCC concentration) or the field that is in question (i.e. industry or country) 
	public abstract double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice); //returns new market value of restricted portion of portfolio included addition/subtraction of security
	
	
	 
	public AggregateRestriction(int restrictionId) {
		this.restrictionId = restrictionId;
		this.parameterMap = new HashMap<String, Object>();
	}
	
	public void init() throws Exception {
		
		try {
			restrictionMap = TableQuery.getRowByID("CustomTradeTktRestriction.AggregateRestrictionList", "AggregateRestrictionID", restrictionId);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
		}
		
		portfolioId = Integer.parseInt(restrictionMap.get(PORTFOLIO_COLUMN).toString());
		mktValueSQLFunctionName = restrictionMap.get(SQL_FUNCTION_NAME_COLUMN).toString();
		inequal = Inequality.getInequality(restrictionMap.get(INEQUALITY_COLUMN).toString());
		restrictionLimit = Double.parseDouble(restrictionMap.get(LIMIT_COLUMN).toString());
		exCash = Boolean.parseBoolean(restrictionMap.get(EX_CASH_COLUMN).toString());
		
		//load parameter map from parameter table
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause("AggregateRestrictionID", FilterClause.FieldComparator.EQ, restrictionId));
		try {
			parameterMapList = TableQuery.getRows("CustomTradeTktRestriction.AggregateRestrictionParams", filter);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
		}
		
		for(Map<String, Object> map : parameterMapList) {
			parameterMap.put(map.get("ParameterName").toString(), map.get("ParameterValue"));
		}
		
		
	}
	
	public int getPortfolioID() {
		return portfolioId;
	}

	public int getRestrictionID() {
		return restrictionId;
	}
	
	public double getRestrictionLimit() {
		return restrictionLimit;
	}

}
