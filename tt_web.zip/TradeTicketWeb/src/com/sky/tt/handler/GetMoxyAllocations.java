package com.sky.tt.handler;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.write.MoxyTableWrite;
import com.sky.util.ErrorHandlingUtility;

public class GetMoxyAllocations extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3759221788670021534L;
	private static final Logger log = Logger.getLogger(GetMoxyAllocations.class);
	
	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject returnObj = new JSONObject();
		JSONObject inputObj = new JSONObject(request.getParameter("jsonString"));
		
		int orderID = Integer.parseInt(inputObj.get("orderID").toString());
		int fillID = Integer.parseInt(inputObj.get("fillID").toString());
		Map<Integer, Object> inputParams = new HashMap<Integer, Object>();
		List<Map<String, Object>> allocationRows = null;

		inputParams.put(1, orderID);
		if (fillID != 0) {
			inputParams.put(2, fillID);
		}

		try {
			allocationRows = MoxyTableWrite.executeStoredProcWithReturn("pCustGetAllocsForOrder", inputParams);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		} catch (FilterException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}

		String tableString = "";
		DecimalFormat numNoDec = new DecimalFormat("#,###");
		DecimalFormat numThreeDec = new DecimalFormat("#,###.000");
		
		for (Map<String, Object> allocation : allocationRows){
			tableString = tableString +
					"<tr><td>" + allocation.get("PortfolioCode") + "</td>" +
					"<td class='rightAlign'>" + numNoDec.format(allocation.get("TargetQuantity")) + "</td>" +
					"<td class='rightAlign'>" + numNoDec.format(allocation.get("FillQuantity")) + "</td>" +
					"<td class='rightAlign'>" + numNoDec.format( allocation.get("LeftQuantity")) + "</td>" +
					"<td class='rightAlign'>" + (Double.parseDouble(allocation.get("AvgPrice").toString()) == 0 ? "0" : numThreeDec.format(allocation.get("AvgPrice"))).toString() + "</td>" +
					"<td class='rightAlign'>" + numNoDec.format(allocation.get("SelectedFillQuantity")) + "</td></tr>";			
		}
		
		String jsonStrOutput = "{\"Rows\":\"" + tableString + "\"}";
		returnObj = new JSONObject(jsonStrOutput);
		
		return returnObj;
	}

}
