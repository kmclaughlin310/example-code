package com.sky.tt.jsonconvert;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



public class JSONStringConverter {
	private static final Logger log = Logger.getLogger(JSONStringConverter.class);
	
	public static Map<String, Object> getTTMapFromJSONString(String jsonString) {
		//used for taking basic TT info to retrieve bottom half of TT next
		//if no cusip, should only return non-changing columns
		
		JSONObject jsonData = new JSONObject(jsonString);
		JSONArray jsonArray = new JSONArray();
		Map<String, Object> parsedData = new HashMap<String, Object>();
		Map<String, Object> subMap = new HashMap<String, Object>(); //used for allocations map
		
		
		for (String key : jsonData.keySet()) {
			
			//if (jsonData.get(key).getClass().toString().equalsIgnoreCase("class org.json.JSONArray")) {
			if (key.equalsIgnoreCase("ALLOCATIONS")) { //used in testing
				jsonArray = new JSONArray(jsonData.get(key).toString());
				for(int i = 0; i < jsonArray.length(); i++) {
					JSONObject jsonObj = jsonArray.getJSONObject(i);
					subMap.put(jsonObj.getString("PORTCODE"), Double.parseDouble(jsonObj.get("QUANTITY").toString()));
				}
				parsedData.put(key, subMap);
				subMap = new HashMap<String, Object>();
			} else if (key.equalsIgnoreCase("SecurityData")) { //currently creating security in handler, but still needs to be processed in JSON string
				//array will only have 1 entry; will be used to create Security
				jsonArray = new JSONArray(jsonData.get(key).toString());
				JSONObject jsonObj = jsonArray.getJSONObject(0);
				for (String k : jsonObj.keySet()) {
					subMap.put(k, jsonObj.get(k));
				}
				parsedData.put(key, subMap);
				subMap = new HashMap<String, Object>();				
			} else {
				parsedData.put(key, jsonData.get(key));
			}
		}
		return parsedData;
	}
	
	public static String getJSONForTTHoldings(Object dashHoldings) {
		String jsonObj = null;
		
		ObjectMapper objMapper = new ObjectMapper();
		
		try {
			jsonObj = objMapper.writeValueAsString(dashHoldings);
		} catch (JsonProcessingException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		return jsonObj;
	}
	

}
