package com.sky.tt.restriction.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityGenericListRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityGenericListRestriction.class);
	
	private static final String RESTRICTED_LIST_PARAMETER_NAME = "RestrictionList";
	private static final String IS_INCLUSIVE_PARAMETER_NAME = "IsInclusive";
	private static final String FIELD_PARAMETER_NAME = "FieldName";	

	protected String restrictionListString;
	protected boolean isInclusive;
	protected SecurityField field;
	
	public SecurityGenericListRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		
		restrictionListString = parameterMap.get(RESTRICTED_LIST_PARAMETER_NAME).toString();
		field = SecurityField.getSecurityField(parameterMap.get(FIELD_PARAMETER_NAME).toString()); //needs to exactly match field name in SecurityField enum		
		isInclusive = (parameterMap.get(IS_INCLUSIVE_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
	}

	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			List<String> restrictionList = new ArrayList<String>(Arrays.asList(restrictionListString.split("\\s*,\\s*")));
			
			//to make list case insensitive
			Set<String> restrictionListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			restrictionListNoCase.addAll(restrictionList);
			
			String fieldValue = null;
			//fieldValue = security.getValue(field).toString();
			
			if (security.getValue(field) != null) {
				fieldValue = security.getValue(field).toString();
			} else {
				fieldValue = "";
			}
			
			restrictionResultText = fieldValue;
	
			if (isInclusive == true) {
				//value must be contained in list, therefore return true if value is not in list
				if (!restrictionListNoCase.contains(fieldValue)) {
					restrictionTested = true;
					restrictionResult = true;
					return true;
				} else {
					restrictionTested = true;
					restrictionResult = false;
					return false;
				}
			} else {
				//value cannot be in list, therefore if value is contained in list, return true
				if (restrictionListNoCase.contains(fieldValue)) {
					restrictionTested = true;
					restrictionResult = true;
					return true;
				} else {
					restrictionTested = true;
					restrictionResult = false;
					return false;
				}	
			}
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			restrictionResult = true;
			return true;
		}		
	}
	
	public String getRestrictedListText() {
		return restrictionListString + ((isInclusive) ? " (inclusive)" : "");
	}

}
