package com.sky.tt.restriction.aggregate;



import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregateGenericMaxPctRestriction extends AggregateRestriction {
	//parameters: CheckField, CheckValue, CheckInequality - if field value of the security matches the inequality and value, then returns true via restrictionApplies and check continues
	
	private static final Logger log = Logger.getLogger(AggregateGenericMaxPctRestriction.class);
	
	private static final String CHECK_SECURITY_FIELD_PARAMETER_NAME = "CheckField";
	private static final String CHECK_VALUE_PARAMETER_NAME = "CheckValue";
	private static final String CHECK_INEQUALITY_PARAMETER_NAME = "CheckInequality";
	private static final String NULLABLE_PARAMETER_NAME = "Nullable";
	
	protected SecurityField field;
	protected Object checkValue;
	protected Inequality checkInequality;
	protected boolean nullable = false;
	
	public AggregateGenericMaxPctRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		
		super.init();	
		
		field = SecurityField.getSecurityField(parameterMap.get(CHECK_SECURITY_FIELD_PARAMETER_NAME).toString()); //needs to exactly match field name in SecurityField enum
		checkValue = parameterMap.get(CHECK_VALUE_PARAMETER_NAME);
		checkInequality = Inequality.getInequality(parameterMap.get(CHECK_INEQUALITY_PARAMETER_NAME).toString());
		
		if (parameterMap.containsKey(NULLABLE_PARAMETER_NAME)) {
			nullable = (parameterMap.get(NULLABLE_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
	}

	public Object restrictionApplies(Security security, Portfolio portfolio) {
		Object fieldValue = null;
		
		if (security.getValue(field) != null) {
			fieldValue = security.getValue(field);
		} else if (nullable == true & security.getValue(field) == null) {
			return false;
		} else {   
			return true;
		}
		
		switch (field.getFieldType()) {
		case INTEGER:
			try {
				switch (checkInequality) {
				case LT:
					return Integer.parseInt(fieldValue.toString()) < Integer.parseInt(checkValue.toString());
				case GT:
					return Integer.parseInt(fieldValue.toString()) > Integer.parseInt(checkValue.toString());
				case LTE:
					return Integer.parseInt(fieldValue.toString()) <= Integer.parseInt(checkValue.toString());
				case GTE:
					return Integer.parseInt(fieldValue.toString()) >= Integer.parseInt(checkValue.toString());
				case EQ:
					return Integer.parseInt(fieldValue.toString()) == Integer.parseInt(checkValue.toString());
				case NE:
					return Integer.parseInt(fieldValue.toString()) != Integer.parseInt(checkValue.toString());
				default:
					return true;		
				}
			} catch (NumberFormatException e) {
				log.error(e);
				return true;
			}
		case STRING:
			switch (checkInequality) {
			case EQ:
				return fieldValue.toString().equalsIgnoreCase(checkValue.toString());
			case NE:
				return ! fieldValue.toString().equalsIgnoreCase(checkValue.toString());
			default:
				return true;		
			}
		case BOOLEAN:
			switch (checkInequality) {
			case EQ:
				return Boolean.parseBoolean(fieldValue.toString()) == Boolean.parseBoolean(checkValue.toString());
			case NE:
				return Boolean.parseBoolean(fieldValue.toString()) != Boolean.parseBoolean(checkValue.toString());
			default:
				return true;		
			}
		case FLOAT:
			try {
				switch (checkInequality) {
				case LT:
					return Float.parseFloat(fieldValue.toString()) < Float.parseFloat(checkValue.toString());
				case GT:
					return Float.parseFloat(fieldValue.toString()) > Float.parseFloat(checkValue.toString());
				case LTE:
					return Float.parseFloat(fieldValue.toString()) <= Float.parseFloat(checkValue.toString());
				case GTE:
					return Float.parseFloat(fieldValue.toString()) >= Float.parseFloat(checkValue.toString());
				case EQ:
					return Float.parseFloat(fieldValue.toString()) == Float.parseFloat(checkValue.toString());
				case NE:
					return Float.parseFloat(fieldValue.toString()) != Float.parseFloat(checkValue.toString());
				default:
					return true;	
				} 
			} catch (NumberFormatException e) {
				log.error(e);
				return true;
			}
		default:
			return true;
		}
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		//restrictionApplies will return boolean
		try {
			if (action.equalsIgnoreCase("sell") || (Boolean) restrictionApplies(security, portfolio) == false) {
				return 0;
			}
			
			double restrictedPortionPortMktVal;
			double totalPortMktVal;
	
			//assuming buy since it's a max percent restriction i.e. wouldn't need to check restriction if it's a sell
			restrictedPortionPortMktVal = PortfolioMarketValue.getRestrictedPortionMktVal(portfolio, mktValueSQLFunctionName, checkInequality, checkValue, true);
			restrictedPortionPortMktVal = restrictedPortionPortMktVal + ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()); 
			
			//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy
			totalPortMktVal = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
	
			//returns % of limit of the restricted portion
			return (restrictedPortionPortMktVal / totalPortMktVal * 100) / restrictionLimit * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}
	


}
