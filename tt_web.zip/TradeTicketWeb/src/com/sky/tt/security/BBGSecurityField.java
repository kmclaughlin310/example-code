package com.sky.tt.security;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import com.sky.tt.bloomberg.BloombergException;
import com.sky.tt.db.connection.TradeTicketDBException;



public enum BBGSecurityField {
	
	//from existing security setup (com.sky.apx.security.SecurityField.java)
	SECTYPE(SecurityField.SECTYPE, "SECTYPE_OVERRIDE"),
	SYMBOL(SecurityField.SYMBOL, "SECTYPE_OVERRIDE", "ID_CUSIP", new Symbol()),
	CUSIP(SecurityField.CUSIP, "ID_CUSIP", "ID_BB", new BackupValue()),
	DESCRIPTION(SecurityField.DESCRIPTION, "ISSUER"),
	INDUSTRY_GROUP(SecurityField.INDUSTRY_GROUP, "ID_CUSIP", "INDUSTRY_SUBGROUP_NUM", new IndustryGroupLookup()), //needs function
	INDUSTRY_SECTOR(SecurityField.INDUSTRY_SECTOR, "ID_CUSIP", "INDUSTRY_SUBGROUP_NUM", new IndustrySectorLookup()), //needs function
	RISK_COUNTRY(SecurityField.RISK_COUNTRY, "CNTRY_OF_RISK", new LowerCase(), true),
	ISSUE_COUNTRY(SecurityField.ISSUE_COUNTRY, "CNTRY_OF_DOMICILE", new LowerCase(), true),
	ISSUE_DATE(SecurityField.ISSUE_DATE, "INT_ACC_DT", new ConvertDate(), true),
	//FIRST_COUPON_DATE(SecurityField.FIRST_COUPON_DATE, "FIRST_CPN_DT", new ConvertDate(), true),
	//LAST_COUPON_DATE(SecurityField.LAST_COUPON_DATE, "PENULTIMATE_CPN_DT", new ConvertDate(), true),
	MATURITY_DATE(SecurityField.MATURITY_DATE, "MATURITY", new ConvertDate(), true),
	DIVINT_RATE(SecurityField.DIVINT_RATE, "CPN", true),
	//ACCRUAL_CALENDAR(SecurityField.ACCRUAL_CALENDAR, "DAY_CNT_DES", new ParseCalendar(), true),
	//PAYMENT_FREQUENCY(SecurityField.PAYMENT_FREQUENCY, "CPN_FREQ", "CPN_TYP", new VROnly(false,"0"), true),
	TICKER(SecurityField.TICKER, "TICKER", true),
	SEDOL(SecurityField.SEDOL, "ID_SEDOL1", true),
	ISIN(SecurityField.ISIN, "ID_ISIN", true),
	BBID(SecurityField.BBID, "ID_BB", true),
	//PRIMARY_SYMBOL(SecurityField.PRIMARY_SYMBOL, null, new HardCode("C")), //why is this null
	SP_RATING(SecurityField.SP_RATING, "RTG_SP_NO_WATCH", new CleanRating(), true),
	MOODY_RATING(SecurityField.MOODY_RATING, "RTG_MOODY_NO_WATCH", new CleanRating(), true),
	FITCH_RATING(SecurityField.FITCH_RATING, "RTG_FITCH_NO_WATCH", new CleanRating(), true),
	//RESET_FREQUENCY(SecurityField.RESET_FREQUENCY, "REFIX_FREQ_FEATURE", "CPN_TYP", new VROnly(true), true),
	//COUPON_PAYMENT_RULE(SecurityField.COUPON_PAYMENT_RULE, "CPN_TYP", new VRHardCode("0",true), true), //needs function
	//COUPON_PAYMENT_FREQUENCY(SecurityField.COUPON_PAYMENT_FREQUENCY, "CPN_TYPE", new VRHardCode("253",true), true), //needs function
	//COUPON_PAYMENT_HOLIDAY(SecurityField.COUPON_PAYMENT_HOLIDAY, "CPN_TYP", new VRHardCode("s",true), true), //needs function
	//RESET_METHOD(SecurityField.RESET_METHOD, "CPN_TYPE", new VRHardCode("5",true), true), //needs function
	//COUPON_PAYMENT_METHOD(SecurityField.COUPON_PAYMENT_METHOD, "CPN_TYP", new VRHardCode("3",true), true), //needs function
	R144A(SecurityField.R144A, "144A_FLAG", new Default("N/A"), true),
	REG_RIGHTS(SecurityField.REG_RIGHTS, "144A_REG_RIGHTS", new Default("N/A"), true),
	COUPON_TYPE(SecurityField.COUPON_TYPE, "CPN_TYP", new Default("N/A"), true),
	RAW_SP(SecurityField.RAW_SP, "RTG_SP_NO_WATCH", true),
	RAW_MOODY(SecurityField.RAW_MOODY, "RTG_MOODY_NO_WATCH", true),
	RAW_FITCH(SecurityField.RAW_FITCH, "RTG_FITCH_NO_WATCH", true),
	BAML_MASTER_II(SecurityField.BAML_MASTER_II, "ID_CUSIP", new IsInMasterII()), //needs function
	ISSUER_OUT(SecurityField.ISSUER_OUT, "SECTYPE_OVERRIDE", "DDIS_AMT_OUTSTANDING_ISSUER_SUBS", new IssuerOutstanding(), true),
	AMT_ISSUED(SecurityField.AMT_ISSUED, "SECTYPE_OVERRIDE", "AMT_OUTSTANDING", new IssueAmount(), true),
	COUNTRY_INCORP(SecurityField.COUNTRY_INCORP, "CNTRY_OF_INCORPORATION", new LowerCase(), true),
	ACTUAL_ISSUE_DATE(SecurityField.ACTUAL_ISSUE_DATE, "ISSUE_DT", new ConvertDate(), true),
	//new fields
	MIN_PIECE(SecurityField.MIN_PIECE, "MIN_PIECE", new Default("0"), true),
	INTEREST_ACCRUED(SecurityField.INTEREST_ACCRUED, "INT_ACC", new Default("0"), true),
	SEC_DESC(SecurityField.SEC_DESC, "SECURITY_DES", true),
	COLLAT_TYPE(SecurityField.COLLAT_TYPE, "COLLAT_TYP", true),
	IS_PERPETUAL(SecurityField.IS_PERPETUAL, "IS_PERPETUAL", true),
	BBG_PARENT_CO(SecurityField.BBG_PARENT_CO, "ID_BB_ULTIMATE_PARENT_CO_NAME", true),
	LOAN_SPREAD(SecurityField.LOAN_SPREAD, "LN_CURRENT_MARGIN", true),
	SECURITY_FACTORABLE(SecurityField.SECURITY_FACTORABLE, "SECURITY_FACTORABLE", true),
	CAPITAL_CONTINGENT_SEC(SecurityField.CAPITAL_CONTINGENT_SEC, "CAPITAL_CONTINGENT_SECURITY", true),
	DRD_ELIGIBLE(SecurityField.DRD_ELIGIBLE, "DRD_ELIGIBLE", true),
	REAL_BBG_DEPT_DES(SecurityField.REAL_BBG_DEPT_DES, "REAL_BLOOMBERG_DEPT_DES", true),
	IS_HYBRID(SecurityField.IS_HYBRID, "HYBRID", true),
	IS_DEFAULTED(SecurityField.IS_DEFAULTED, "DEFAULTED", true),
	SECTYPE_OVERRIDE(SecurityField.SECTYPE_OVERRIDE, "SECTYPE_OVERRIDE", true); //this is so you can manually pass the sec type (csus, blus, cbus) from the trade ticket - otherwise null
	
	
	private static final Logger log = Logger.getLogger(BBGSecurityField.class);
	
	private final SecurityField secField;
	private final String bbgField;
	private final String bbgSecondaryField;
	private final BBGConverterFunction<String, String, String> function;
	private final boolean nullAllowed;

	private static final String BBG_DATE_FORMAT = "yyyy-MM-dd";
	
	
	BBGSecurityField(SecurityField secField, String bbgField) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = null;
		this.function = null;
		this.nullAllowed = false;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, boolean nullAllowed) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = null;
		this.function = null;
		this.nullAllowed = nullAllowed;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, BBGConverterFunction<String, String, String> function) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = null;
		this.function = function;
		this.nullAllowed = false;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, BBGConverterFunction<String, String, String> function, boolean nullAllowed) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = null;
		this.function = function;
		this.nullAllowed = nullAllowed;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, String bbgSecondaryField) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = bbgSecondaryField;
		this.function = null;
		this.nullAllowed = false;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, String bbgSecondaryField, boolean nullAllowed) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = bbgSecondaryField;
		this.function = null;
		this.nullAllowed = nullAllowed;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, String bbgSecondaryField, BBGConverterFunction<String, String, String> function) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = bbgSecondaryField;
		this.function = function;
		this.nullAllowed = false;
	}
	
	BBGSecurityField(SecurityField secField, String bbgField, String bbgSecondaryField, BBGConverterFunction<String, String, String> function, boolean nullAllowed) {
		this.secField = secField;
		this.bbgField = bbgField;
		this.bbgSecondaryField = bbgSecondaryField;
		this.function = function;
		this.nullAllowed = nullAllowed;
	}
	
	public String convertField(Map<String, String> bbgFields) throws BloombergException {
		String value;
		if (function != null) {
			value = function.apply(bbgFields.get(bbgField), bbgFields.get(bbgSecondaryField), bbgFields);
		} else {
			value = bbgFields.get(bbgField);
		}
		
		if (!nullAllowed && value == null) {
			log.debug("Required field '" + this.toString() + "' (BBG Field '" + bbgField + "') missing, throwing exception.");
			throw new BloombergException("Required field '" + this.toString() + "' (BBG Field '" + bbgField + "') is null.");
		} else {
			return value;
		}
	}
	
	public SecurityField getSecurityField() {
		return secField;
	}
	
	public String getSecurityFieldName() {
		return secField.getName();
	}
	
	public String getBBGField() {
		return bbgField;
	}
	
	public String getBBGSecondaryField() {
		return bbgSecondaryField;
	}
	
	/*public Map<String, String> getFieldMap() {
		Map<String, String> results = new HashMap<String, String>();
		
		results.put("secField", this.secField.toString());
		results.put("bbgField", this.bbgField.toString());
		results.put("bbgSecondaryField", this.bbgSecondaryField.toString());
		results.put("function", this.function.toString());
		results.put("nullAllowed", this.nullAllowed.toString());
		
		return results;
	}*/
	
	static class Symbol implements BBGConverterFunction<String, String, String> {
		public String apply(String secType, String cusip, Map<String, String> bbgData) throws BloombergException {
			if ("cbus".equalsIgnoreCase(secType) || "vbus".equalsIgnoreCase(secType)) {
				return cusip;
			} else if ("blus".equalsIgnoreCase(secType)) {
				return bbgData.get("ID_BB");
			} else if ("csus".equalsIgnoreCase(secType)) {
				return bbgData.get("TICKER");
			} else {
				throw new BloombergException("Invalid sec type passed to Symbol function: '" + secType + "'");
			}
		}
	}
	
	//"DDIS_AMT_OUTSTANDING_ISSUER_SUBS", "AMT_OUTSTANDING"
	
	static class IssuerOutstanding implements BBGConverterFunction<String, String, String> {
		public String apply(String secType, String bloombergIssuerOut, Map<String, String> bbgData) throws BloombergException {
			if ("csus".equalsIgnoreCase(secType)) {
				if (bbgData.containsKey("EQY_SH_OUT_REAL")) {
					return Long.toString(Math.round(Double.parseDouble(bbgData.get("EQY_SH_OUT_REAL"))));
				} else {
					return "0";
				}
			} else {
				if (bloombergIssuerOut == null) {
					return Long.toString(Math.round(Double.parseDouble(bbgData.get("AMT_OUTSTANDING"))));
				} else {
					return Long.toString(Math.round(Double.parseDouble(bloombergIssuerOut)));
				}
			}
		}
	}
	
	static class IssueAmount implements BBGConverterFunction<String, String, String> {
		public String apply(String secType, String bloombergAmountOut, Map<String, String> bbgData) throws BloombergException {
			if ("csus".equalsIgnoreCase(secType)) {
				if (bbgData.containsKey("EQY_SH_OUT_REAL")) {
					return Long.toString(Math.round(Double.parseDouble(bbgData.get("EQY_SH_OUT_REAL"))));
				} else {
					return "0";
				}
			} else {
				if (bloombergAmountOut == null) {
					return Long.toString(0);
				} else {
					return Long.toString(Math.round(Double.parseDouble(bloombergAmountOut)));
				}
			}
		}
	}
	
	/*
	static class ParseSecType implements BBGConverterFunction<String, String, String> {
		public String apply(String bloombergCouponType, String ignored, Map<String, String> ignored2) throws BloombergException {
			return getSecTypeFromCouponType(bloombergCouponType);
		}
	}
	*/
	static class Default implements BBGConverterFunction<String, String, String> {
		
		private String defaultValue;
		
		protected Default(String defaultValue) {
			this.defaultValue = defaultValue;
		}
		
		public String apply(String bloombergField, String ignored, Map<String, String> ignored2) throws BloombergException {
			return (bloombergField == null) ? defaultValue : bloombergField;

		}
	}
	
	static class BackupValue implements BBGConverterFunction<String, String, String> {
		
		public String apply(String bloombergField, String secondaryField, Map<String, String> ignored2) throws BloombergException {
			return (bloombergField == null) ? secondaryField : bloombergField;

		}
	}
	
	/*
	static class ParseCalendar implements BBGConverterFunction<String, String, String> {
		public String apply(String bloombergCalendar, String ignored, Map<String, String> ignored2) throws BloombergException {
			if (bloombergCalendar == null) {
				return null;
			} else if (bloombergCalendar.startsWith("30/360")) {
				return "7";
			} else if (bloombergCalendar.startsWith("ISMA-30/360")) {
				return "4";
			} else if (bloombergCalendar.startsWith("ACT/360")) {
				return "c";
			} else if (bloombergCalendar.startsWith("ACT/365")) {
				return "b";
			} else if (bloombergCalendar.startsWith("ACT/ACT")) {
				return "a";
			} else {
				log.debug("Invalid accrual calendar: '" + bloombergCalendar + "', throwing exception.");
				throw new BloombergException("Invalid accrual calendar: '" + bloombergCalendar + "'");
			}
		}
	}
	*/
	
	static class CleanRating implements BBGConverterFunction<String, String, String> {
		public String apply(String bloombergRating, String ignored, Map<String, String> ignored2) {
			if (bloombergRating == null) {
				return null;
			} else if (bloombergRating.endsWith("u") || bloombergRating.endsWith("e")) {
				return bloombergRating.substring(0, bloombergRating.length() - 1);
			} else if (bloombergRating.startsWith("(P)")) {
				return bloombergRating.substring(3);
			} else {
				return bloombergRating;
			}
		}
	}
	
	static class RawRating implements BBGConverterFunction<String, String, String> {
		public String apply(String bloombergRating, String ignored, Map<String, String> ignored2) {
			if (bloombergRating == null) {
				return null;
			} else if (bloombergRating.endsWith("u") || bloombergRating.endsWith("e") || bloombergRating.startsWith("(P)")) {
				return bloombergRating;
			} else {
				return null;
			}
		}
	}
	
	static class ConvertDate implements BBGConverterFunction<String, String, String> {
		public String apply(String bbgDate, String ignored, Map<String, String> ignored2)  throws BloombergException {
			if (bbgDate == null) {
				return null;
			}
			
			SimpleDateFormat bbgFormat = new SimpleDateFormat(BBG_DATE_FORMAT);
			SimpleDateFormat secFormat = new SimpleDateFormat(SecurityField.SECURITY_DATE_FORMAT);
			try {
				return secFormat.format(bbgFormat.parse(bbgDate));
			} catch (ParseException e) {
				log.debug("Error parsing date '" + bbgDate + "': " + e.getMessage() + ", throwing exception.");
				throw new BloombergException("Error parsing date '" + bbgDate + "': " + e.getMessage(), e);
			}
		}
	}
	
	/*
	static class VRConvertDate implements BBGConverterFunction<String, String, String> {
		private boolean forVR;
		
		public VRConvertDate(boolean forVR) {
			this.forVR = forVR;
		}
		
		public String apply(String bbgDate, String couponType, Map<String, String> ignored2)  throws BloombergException {
			
			if (bbgDate == null) {
				return null;
			}
			
			if ("vbus".equals(getSecTypeFromCouponType(couponType)) == forVR) {
				SimpleDateFormat bbgFormat = new SimpleDateFormat(BBG_DATE_FORMAT);
				SimpleDateFormat secFormat = new SimpleDateFormat(SecurityField.SECURITY_DATE_FORMAT);
				try {
					return secFormat.format(bbgFormat.parse(bbgDate));
				} catch (ParseException e) {
					log.debug("Error parsing date '" + bbgDate + "': " + e.getMessage() + ", throwing exception.");
					throw new BloombergException("Error parsing date '" + bbgDate + "': " + e.getMessage(), e);
				}
			} else {
				return null;
			}
		}
	}
	*/
	
	static class HardCode implements BBGConverterFunction<String, String, String> {
		private String value;
		public HardCode(String value) {
			this.value = value;
		}
		
		public String apply(String ignored, String ignored2, Map<String, String> ignored3) {
			return value;
		}
	}
	
	/*
	static class VRHardCode implements BBGConverterFunction<String, String, String> {
		private String value;
		private boolean forVR;
		
		public VRHardCode(String value, boolean forVR) {
			this.value = value;
			this.forVR = forVR;
		}
		
		public String apply(String couponType, String ignored, Map<String, String> ignored2) throws BloombergException {
			if ("vbus".equals(getSecTypeFromCouponType(couponType)) == forVR) {
				return value;
			} else {
				return null;
			}
		}
	}*/
	
	/*
	static class VROnly implements BBGConverterFunction<String, String, String> {
		
		private boolean forVR;
		private String defaultValue;
		
		public VROnly(boolean forVR) {
			this.forVR = forVR;
			this.defaultValue = null;
		}
		
		public VROnly(boolean forVR, String defaultValue) {
			this.forVR = forVR;
			this.defaultValue = defaultValue;
		}
		
		public String apply(String value, String couponType, Map<String, String> ignored2) throws BloombergException {
			if ("vbus".equals(getSecTypeFromCouponType(couponType)) == forVR) {
				return value;
			} else {
				return defaultValue;
			}
		}
	}
	*/
	
	/*
	static class VRBaseRate implements BBGConverterFunction<String, String, String> {
		public String apply(String baseRate, String couponType, Map<String, String> ignored2) throws BloombergException {
			if ("vbus".equals(getSecTypeFromCouponType(couponType))) {
				if ("US0003M".equals(baseRate) || "LIBOR 3MO".equals(baseRate)) {
					return "US0003M";
				} else if ("US0006M".equals(baseRate)) {
					return "US0006M";
				}	else {
					log.debug("Unknown variable base rate: '" + baseRate + "', throwing exception.");
					throw new BloombergException("Unknown variable base rate: '" + baseRate + "'");
				}
			} else {
				return null;
			}
		}
	}
	*/
	
	static class LowerCase implements BBGConverterFunction<String, String, String> {
		public String apply(String value, String ignored, Map<String, String> ignored2) {
			return (value == null) ? null : value.toLowerCase();
		}
	}
	
	static class IndustryGroupLookup implements BBGConverterFunction<String, String, String> {
		public String apply(String cusip, String bbgIndustryCode, Map<String, String> ignored2) {
			try {
				APXIndustryLookupSingleton indexLookup = APXIndustryLookupSingleton.getInstance();
				MLIndustryLookupSingleton mlIndLookup = MLIndustryLookupSingleton.getInstance();
				String industryGroup = mlIndLookup.getIndustryGroupCode(cusip);
				if (industryGroup == null) {
					industryGroup = indexLookup.getIndustryGroupCodeFromBBG(bbgIndustryCode);
					if (industryGroup == null) {
						return "-2";
					} else {
						return industryGroup;
					}
				} else {
					return industryGroup;
				}
			} catch (TradeTicketDBException e) {
				log.error("Error doing index lookup: " + e.getMessage(), e);
				return null;
			}
		}
	}
	
	static class IndustrySectorLookup implements BBGConverterFunction<String, String, String> {
		public String apply(String cusip, String bbgIndustryCode, Map<String, String> ignored2) {
			try {
				APXIndustryLookupSingleton indexLookup = APXIndustryLookupSingleton.getInstance();
				MLIndustryLookupSingleton mlIndLookup = MLIndustryLookupSingleton.getInstance();
				String industrySector = mlIndLookup.getIndustrySectorCode(cusip);
				if (industrySector == null) {
					industrySector = indexLookup.getIndustrySectorCodeFromBBG(bbgIndustryCode);
					if (industrySector == null) {
						return "-2";
					} else {
						return industrySector;
					}
				} else {
					return industrySector;
				}
			} catch (TradeTicketDBException e) {
				log.error("Error doing index lookup: " + e.getMessage(), e);
				return null;
			}
		}
	}
	
	static class IsInMasterII implements BBGConverterFunction<String, String, String> {
		public String apply(String cusip, String ignored, Map<String, String> ignored2) {
			try {
				MLIndustryLookupSingleton mlIndLookup = MLIndustryLookupSingleton.getInstance();
				return (mlIndLookup.inMaster2Index(cusip)) ? "Y" : "N";
			} catch (TradeTicketDBException e) {
				log.error("Error doing index lookup: " + e.getMessage(), e);
				return null;
			}
		}
	}
	
	private static interface BBGConverterFunction<T, E, F> {
		public T apply(F value, E value2, Map<String, String> secData) throws BloombergException;
	}
	
	/*public static APXSecurity convertBBGMapToAPXSecurity(String security, Map<String, String> securityData) throws BloombergException {
		if (securityData.get(SecurityRequester.SECURITY_ERROR) != null) {
			throw new BloombergException("Security '" + security + "' had an error with Bloomberg: " + securityData.get(SecurityRequester.SECURITY_ERROR));
		} else {
			Map<SecurityField, Object> fieldMap = new HashMap<SecurityField, Object>();
			for (BBGSecurityField converter : BBGSecurityField.values()) {
				fieldMap.put(converter.getField(), converter.convertField(securityData));
			}
			return new Security(fieldMap);
		}
	}*/
	
/*	public static Security convertBBGMapToAPXSecurity(String security, Map<String, String> securityData) throws BloombergException {
		if (securityData.get(SecurityRequester.SECURITY_ERROR) != null) {
			throw new BloombergException("Security '" + security + "' had an error with Bloomberg: " + securityData.get(SecurityRequester.SECURITY_ERROR));
		} else {
			Map<SecurityField, Object> fieldMap = new HashMap<SecurityField, Object>();
			for (BBGSecurityField converter : BBGSecurityField.values()) {
				fieldMap.put(converter.getSecurityField(), converter.convertField(securityData));
			}
			return new Security(fieldMap);
		}
	}*/
	
	public static Set<String> getBBGFieldList() {
		Set<String> values = new HashSet<String>();
		for (BBGSecurityField value : BBGSecurityField.values()) {
			if (value.getBBGField() != null) {
				values.add(value.getBBGField());
			}
			if (value.getBBGSecondaryField() != null) {
				values.add(value.getBBGSecondaryField());
			}
		}
		
		return values;
	}
	
	protected static String getSecTypeFromCouponType(String bloombergCouponType) throws BloombergException {
		if (bloombergCouponType == null) {
			return null;
		} else if (bloombergCouponType.equals("FIXED") || bloombergCouponType.equals("ZERO COUPON") || bloombergCouponType.equals("PAY-IN-KIND")
				|| bloombergCouponType.equals("STEP CPN") || bloombergCouponType.equals("VARIABLE") || bloombergCouponType.equals("EXCHANGED")
				|| bloombergCouponType.equals("WHEN ISSUED")) {
			return "cbus";
		} else if (bloombergCouponType.equals("FLOATING")) {
			return "vbus";
		} else {
			log.debug("Invalid coupon type: '" + bloombergCouponType + "', throwing exception.");
			throw new BloombergException("Invalid coupon type: '" + bloombergCouponType + "'");
		}
	}
	
	
}
