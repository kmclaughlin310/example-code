package com.sky.tt.security.ratingcalc;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton.RatingType;
import com.sky.util.ArraySort;

public class NAICRatingCalculator implements SecurityRatingCalculator {

	private static final Logger log = Logger.getLogger(NAICRatingCalculator.class);
	
	public double getSecurityRating(Security security, boolean includeEPURatings, boolean includeFitchRatings) throws TradeTicketDBException {
		
		
		RatingConverterSingleton converter = RatingConverterSingleton.getInstance();
		
		double NAICRating = 0;
		double spRating = 0;
		double mdyRating = 0;
		double fitchRating = 0;
		
		spRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_SP, includeEPURatings);
		mdyRating = converter.getNumericSecurityRating(security, RatingType.MOODY, SecurityField.RAW_MOODY, includeEPURatings);
		fitchRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_FITCH, includeEPURatings);
		
		//include fitch rating
		if (includeFitchRatings) {
			double[] ratingArray = {spRating, mdyRating, fitchRating}; //Java array index starts at 0
			
			ratingArray = ArraySort.InsertionSort(ratingArray);
			
			if (ratingArray[0] < 0) {
				if (ratingArray[2] < 0) {
					NAICRating = 25;
				} else {
					NAICRating = ratingArray[2];
				}
			} else {
				NAICRating = ratingArray[1];
			}
		} else { //exclude fitch rating
			if (spRating < 0 && mdyRating < 0) {
				NAICRating = 25;
			} else if (spRating > mdyRating) {
				NAICRating = spRating;
			} else {
				NAICRating = mdyRating;
			}
		}
		
		return NAICRating;
	}

	
	@Override
	public String getSecurityRatingText(Security security) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getSecurityRatingText(double value) {
		try {
			RatingConverterSingleton ratingConverter = RatingConverterSingleton.getInstance();
			return ratingConverter.getSPRatingText(value);
		} catch (TradeTicketDBException e) {
			log.error(e);
			return null;
		}
	}

}

