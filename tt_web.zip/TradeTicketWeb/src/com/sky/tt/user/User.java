package com.sky.tt.user;

public class User {
	
	private int userID;
	private String userName;
	private String fullName;
	private String MOXYUserID;
	
	public User() {}
	
	public User(int userID, String userName, String fullName, String MOXYUserID) {
		this.userID = userID;
		this.userName = userName;
		this.fullName = fullName;
		this.MOXYUserID = MOXYUserID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public void setMOXYUserID(String MOXYUserID) {
		this.MOXYUserID = MOXYUserID;
	}

	public String getMOXYUserID() {
		return MOXYUserID;
	}
}
