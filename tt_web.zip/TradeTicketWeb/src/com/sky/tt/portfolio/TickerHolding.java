package com.sky.tt.portfolio;

import java.util.Map;

public class TickerHolding {
	
	protected double quantity;
	protected String ticker;
	protected double marketValue;
	
	public TickerHolding(Map<String, Object> holdingData) {
		quantity = Double.parseDouble(holdingData.get("quantity").toString());
		ticker = holdingData.get("ticker").toString();
		marketValue = Double.parseDouble(holdingData.get("marketValue").toString()); //currently includes accrued interest and based on price in APX db
	}
	
	public double getQuantity() {
		return quantity;
	}
	
	public String getTicker() {
		return ticker;
	}
	
	public double getMarketValue() {
		return marketValue;
	}
	
	//for adding to holding - used in MarketValue singleton
	public TickerHolding updateTickerHolding(TickerHolding oldHolding, double quantity, double mktVal) {
		TickerHolding newTickerHolding = oldHolding;
		
		newTickerHolding.marketValue = oldHolding.getMarketValue() + mktVal;
		newTickerHolding.quantity = oldHolding.getQuantity() + quantity;
		
		return newTickerHolding;
	}

}
