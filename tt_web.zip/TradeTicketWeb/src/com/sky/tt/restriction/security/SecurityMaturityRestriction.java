package com.sky.tt.restriction.security;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityMaturityRestriction extends SecurityRestriction{
	private static final Logger log = Logger.getLogger(SecurityMaturityRestriction.class);
	private static final String SECURITY_MATURITY_RESTRICTION_VALUE = "MaturityRestrictionValue";
	private static final String INEQUALITY_PARAMETER_NAME = "InequalitySymbol";
	
	protected double restrictionValue;
	protected Inequality inequal;

	public SecurityMaturityRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		restrictionValue = Double.parseDouble(parameterMap.get(SECURITY_MATURITY_RESTRICTION_VALUE).toString());
		inequal = Inequality.getInequality(parameterMap.get(INEQUALITY_PARAMETER_NAME).toString());
	
		
	}

	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {		
			String maturityString = security.getValue(SecurityField.MATURITY_DATE).toString();
			
			DateFormat format = new SimpleDateFormat(SecurityField.SECURITY_DATE_FORMAT, Locale.ENGLISH);
			
			Date maturityDate = null;
			Date today = new Date();
			double dateDiff = 0;
			
			try {
				maturityDate = format.parse(maturityString);
			} catch (ParseException e) {
				log.error(e);
				e.printStackTrace();
				return true;
			}
			
			dateDiff = ((maturityDate.getTime() - today.getTime()) / (24 * 60 * 60 * 1000)) / 365.0;
			
			restrictionResultText = Double.toString(Math.round(dateDiff * 100.0) / 100.0) + " years";
			
			switch (inequal) {
			case LT:
				restrictionResult = (dateDiff >= restrictionValue);
				break;
			case GT:
				restrictionResult = (dateDiff <= restrictionValue);
				break;
			case LTE:
				restrictionResult = (dateDiff > restrictionValue);
				break;
			case GTE:
				restrictionResult = (dateDiff < restrictionValue);
				break;
			default:
				restrictionResult = true;		
				break;
			}
		} catch (Exception e) {
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 
		
		restrictionTested = true;
		return restrictionResult;
		
	}

}
