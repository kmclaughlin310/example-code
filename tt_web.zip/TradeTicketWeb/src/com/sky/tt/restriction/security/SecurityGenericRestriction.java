package com.sky.tt.restriction.security;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityGenericRestriction extends SecurityRestriction {
	
	private static final Logger log = Logger.getLogger(SecurityGenericRestriction.class);
	
	private static final String RESTRICTION_VALUE_PARAMETER_NAME = "RestrictionValue";
	private static final String INEQUALITY_PARAMETER_NAME = "InequalitySymbol";
	private static final String FIELD_PARAMETER_NAME = "FieldName";	
	private static final String NULLABLE_PARAMETER_NAME = "Nullable";

	protected Object restrictionValue;
	protected Inequality inequal;
	protected SecurityField field;
	protected boolean nullable = false;
	
	public SecurityGenericRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		
		restrictionValue = parameterMap.get(RESTRICTION_VALUE_PARAMETER_NAME);
		inequal = Inequality.getInequality(parameterMap.get(INEQUALITY_PARAMETER_NAME).toString());
		field = SecurityField.getSecurityField(parameterMap.get(FIELD_PARAMETER_NAME).toString()); //needs to exactly match field name in SecurityField enum	
		
		if (parameterMap.containsKey(NULLABLE_PARAMETER_NAME)) {
			nullable = (parameterMap.get(NULLABLE_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
	}

	public boolean checkRestriction(Security security, Portfolio portfolio) {

		try {
			Object fieldValue = null;
			//fieldValue = security.getValue(field);
			
			if (security.getValue(field) != null) {
				fieldValue = security.getValue(field);
				restrictionResultText = (fieldValue == null) ? "" : fieldValue.toString();
			} else if (nullable == true & security.getValue(field) == null) {
				restrictionTested = true;
				restrictionResult = false;
				return false;
			} else {   
				restrictionTested = true;
				restrictionResult = true;
				return true;
			}
			
			switch (field.getFieldType()) {
			case INTEGER:
				try {
					switch (inequal) {
					case LT:
						restrictionResult = (Integer.parseInt(fieldValue.toString()) >= Integer.parseInt(restrictionValue.toString()));
						break;
					case GT:
						restrictionResult = (Integer.parseInt(fieldValue.toString()) <= Integer.parseInt(restrictionValue.toString()));
						break;
					case LTE:
						restrictionResult = (Integer.parseInt(fieldValue.toString()) > Integer.parseInt(restrictionValue.toString()));
						break;
					case GTE:
						restrictionResult = (Integer.parseInt(fieldValue.toString()) < Integer.parseInt(restrictionValue.toString()));
						break;
					case EQ:
						restrictionResult = (Integer.parseInt(fieldValue.toString()) != Integer.parseInt(restrictionValue.toString()));
						break;
					case NE:
						restrictionResult = (Integer.parseInt(fieldValue.toString()) == Integer.parseInt(restrictionValue.toString()));
						break;
					default:
						restrictionResult = true;
						break;	
					}
				} catch (NumberFormatException e) {
					log.error(e);
					restrictionTested = false;
					restrictionResult = true;
					return true;
				}
				break;
			case STRING:
				switch (inequal) {
				case EQ:
					restrictionResult = (!fieldValue.toString().equalsIgnoreCase(restrictionValue.toString()));
					break;
				case NE:
					restrictionResult = (fieldValue.toString().equalsIgnoreCase(restrictionValue.toString()));
					break;
				default:
					restrictionResult = true;
					break;
				}
				break;
			case BOOLEAN:
				switch (inequal) {
				case EQ:
					restrictionResult = (Boolean.parseBoolean(fieldValue.toString()) != Boolean.parseBoolean(restrictionValue.toString()));
					break;
				case NE:
					restrictionResult = (Boolean.parseBoolean(fieldValue.toString()) == Boolean.parseBoolean(restrictionValue.toString()));
					break;
				default:
					restrictionResult = true;
					break;
				}
				break;
			case FLOAT:
				try {
					switch (inequal) {
					case LT:
						restrictionResult = (Float.parseFloat(fieldValue.toString()) >= Float.parseFloat(restrictionValue.toString()));
						break;
					case GT:
						restrictionResult = (Float.parseFloat(fieldValue.toString()) <= Float.parseFloat(restrictionValue.toString()));
						break;
					case LTE:
						restrictionResult = (Float.parseFloat(fieldValue.toString()) > Float.parseFloat(restrictionValue.toString()));
						break;
					case GTE:
						restrictionResult = (Float.parseFloat(fieldValue.toString()) < Float.parseFloat(restrictionValue.toString()));
						break;
					case EQ:
						restrictionResult = (Float.parseFloat(fieldValue.toString()) != Float.parseFloat(restrictionValue.toString()));
						break;
					case NE:
						restrictionResult = (Float.parseFloat(fieldValue.toString()) == Float.parseFloat(restrictionValue.toString()));
						break;
					default:
						restrictionResult = true;
						break;
					} 
					break;
				} catch (NumberFormatException e) {
					log.error(e);
					restrictionTested = false;
					restrictionResult = true;
					return true;
				}
			default:
				restrictionTested = false;
				restrictionResult = true;
				return true;
			}
		} catch (Exception e) {
			log.error(e);
			return true;
		} 
		
		restrictionTested = true;
		return restrictionResult;

	}

}
