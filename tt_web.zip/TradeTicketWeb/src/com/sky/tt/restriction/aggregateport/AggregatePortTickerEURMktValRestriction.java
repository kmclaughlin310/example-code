package com.sky.tt.restriction.aggregateport;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.logic.DashboardHoldings;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregatePortRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregatePortTickerEURMktValRestriction extends AggregatePortRestriction {
	
	private static final Logger log = Logger.getLogger(AggregatePortTickerEURMktValRestriction.class);
	
	public AggregatePortTickerEURMktValRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();	
	}

	public double restrictionApplies(Security security, String action, boolean exCash) {
		
		if (action.equalsIgnoreCase("sell")) {
			return 0;
		}
		
		return 1;		
		
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			double allocMktVal;
			double portTickerMV;
			
			if (restrictionApplies(security, action, exCash) == 0) {
				return 0;
			}
			
			MarketValueSingleton singleton = null;
			
			try {
				singleton = MarketValueSingleton.getInstance();
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				return 999;
			}
	
			allocMktVal = (quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor();
			portTickerMV = singleton.getSpecificIssuerHoldingsMktVal(portfolio.getPortfolioID(), security.getValue(SecurityField.TICKER).toString());
			//fx rate in USD/EUR
	
			return ((allocMktVal + portTickerMV) / singleton.getEURExRate()) / restrictionLimit * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}
}
