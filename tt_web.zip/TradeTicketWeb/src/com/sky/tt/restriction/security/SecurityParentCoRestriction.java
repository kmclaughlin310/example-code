package com.sky.tt.restriction.security;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityParentCoRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityParentCoRestriction.class);
	private static final String RESTRICTED_LIST_PARAMETER_NAME = "RestrictionList";
	protected String restrictionListString;
	protected String fullListString;

	public SecurityParentCoRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		
		restrictionListString = parameterMap.get(RESTRICTED_LIST_PARAMETER_NAME).toString();
		fullListString = "";
		StringBuffer buffer = new StringBuffer("");
		try {
			List<Map<String, Object>> restrictedParents = null;
			GenericFilter filter = new GenericFilter();
			
			filter.addFilterClause(new FilterClause("ListName", FilterClause.FieldComparator.EQ, restrictionListString));
			try {
				restrictedParents = TableQuery.getRows("CustomTradeTktRestriction.ParentCoRestrictionList", filter);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
			}
			
			int count = 1;
			for (Map<String, Object> row : restrictedParents) {
				buffer.append(row.get("RestrictedCoName").toString() + ((count++ % 3 == 0) ? "\n" : ", "));
			}
			
			fullListString = buffer.toString();
		} catch (Exception e) {
			log.error(e);
		}
		
	}


	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			restrictionResultText = security.getValue(SecurityField.BBG_PARENT_CO) == null ? "" : security.getValue(SecurityField.BBG_PARENT_CO).toString();
	
			List<Map<String, Object>> restrictedParents = null;
			GenericFilter filter = new GenericFilter();
			
			filter.addFilterClause(new FilterClause("ListName", FilterClause.FieldComparator.EQ, restrictionListString));
			try {
				restrictedParents = TableQuery.getRows("CustomTradeTktRestriction.ParentCoRestrictionList", filter);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				restrictionTested = false;
				restrictionResult = true;
				return true;
			}
			
			for (Map<String, Object> row : restrictedParents) {
				if (restrictionResultText.equalsIgnoreCase(row.get("RestrictedCoName").toString())) {
					restrictionTested = true;
					restrictionResult = true;
					return true;
				}
			}
			
			restrictionTested = true;
			restrictionResult = false;
			return false;
		} catch (Exception e) {
			restrictionTested = false;
			restrictionResult = true;
			log.error(e);
			return true;
		} 
	}
	
	public String getRestrictedListText() {
		return fullListString;
	}

}
