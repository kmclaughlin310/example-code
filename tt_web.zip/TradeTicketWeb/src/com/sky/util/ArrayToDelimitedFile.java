package com.sky.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

//import org.apache.commons.lang3.StringUtils;
import com.google.common.base.Joiner;

public class ArrayToDelimitedFile {

	public static void createFile(String filename, String delimiter, String[][] data) throws IOException {
		
		createFile(filename, delimiter, data, "\n");
		
	}
	
	public static void createFile(String filename, String delimiter, String[][] data, String newline) throws IOException {
		
		BufferedWriter out = new BufferedWriter(new FileWriter(filename));
		
		for (int row = 0; row < data.length; row++) {
			// Old Apache version: out.write(StringUtils.join(data[row], delimiter, 1, data[row].length) + "\n");
			Joiner joiner = Joiner.on("\t").useForNull("");
			out.write(joiner.join(data[row]) + newline);
		}
		
		out.close();
		
	}
	
}
