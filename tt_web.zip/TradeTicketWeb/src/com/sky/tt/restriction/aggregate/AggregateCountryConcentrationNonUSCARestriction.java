package com.sky.tt.restriction.aggregate;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregateCountryConcentrationNonUSCARestriction extends AggregateRestriction {
	//always excludes US and Canada for now; can pass a specific country list, i.e. AAA countries
	
	private static final Logger log = Logger.getLogger(AggregateCountryConcentrationNonUSCARestriction.class);
	
	private static final String CHECK_SECURITY_FIELD_PARAMETER_NAME = "CheckField"; //domicile vs. issue
	private static final String INCLUSIVE_COUNTRY_LIST_PARAMETER_NAME = "InclusiveCountryList";
	private static final String EXCLUSIVE_COUNTRY_LIST_PARAMETER_NAME = "ExclusiveCountryList";
	
	protected SecurityField field;
	protected String inclCountryListString;
	protected String exclCountryListString;

	public AggregateCountryConcentrationNonUSCARestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();	
		field = SecurityField.getSecurityField(parameterMap.get(CHECK_SECURITY_FIELD_PARAMETER_NAME).toString()); //needs to exactly match field name in SecurityField enum
	
		if (parameterMap.containsKey(INCLUSIVE_COUNTRY_LIST_PARAMETER_NAME) && parameterMap.get(INCLUSIVE_COUNTRY_LIST_PARAMETER_NAME) != null) {
			inclCountryListString = parameterMap.get(INCLUSIVE_COUNTRY_LIST_PARAMETER_NAME).toString();
		} else {
			inclCountryListString = null;
		}
		
		if (parameterMap.containsKey(EXCLUSIVE_COUNTRY_LIST_PARAMETER_NAME) && parameterMap.get(EXCLUSIVE_COUNTRY_LIST_PARAMETER_NAME) != null) {
			exclCountryListString = parameterMap.get(EXCLUSIVE_COUNTRY_LIST_PARAMETER_NAME).toString();
		} else {
			exclCountryListString = null;
		}
	}

	public Object restrictionApplies(Security security, Portfolio portfolio) {
		String country = null;		
		country = security.getValue(field).toString();
		
		if (inclCountryListString == null && exclCountryListString == null) {
			if (country.equalsIgnoreCase("us") || country.equalsIgnoreCase("ca")) {
				return "n/a";
			} else {
				return country;
			}
		} else if (inclCountryListString != null){
			List<String> countryList = new ArrayList<String>(Arrays.asList(inclCountryListString.split("\\s*,\\s*")));
			
			//to make list case insensitive
			Set<String> countryListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			countryListNoCase.addAll(countryList);
			
			if (countryListNoCase.contains(country)) {
				return country;
			} else {
				return "n/a";
			}
		} else if (exclCountryListString != null) {
			if (country.equalsIgnoreCase("us") || country.equalsIgnoreCase("ca")) {
				return "n/a";
			}
			List<String> countryList = new ArrayList<String>(Arrays.asList(exclCountryListString.split("\\s*,\\s*")));
			
			//to make list case insensitive
			Set<String> countryListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			countryListNoCase.addAll(countryList);
			
			if (!countryListNoCase.contains(country)) {
				return country;
			} else {
				return "n/a";
			}
		} else {
			return "n/a";
		}
	}

	@Override
	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			String checkCountry = restrictionApplies(security, portfolio).toString();
			
			if (action.equalsIgnoreCase("sell") || checkCountry.equals("n/a")) {
				return 0;
			}
			
			double restrictedPortionPortMktVal;
			double totalPortMktVal;
	
			//assuming buy since it's a max percent restriction i.e. wouldn't need to check restriction if it's a sell
			restrictedPortionPortMktVal = PortfolioMarketValue.getRestrictedPortionMktVal(portfolio, mktValueSQLFunctionName, Inequality.EQ, checkCountry, true);
			restrictedPortionPortMktVal = restrictedPortionPortMktVal + ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()); 
			
			//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy
			totalPortMktVal = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
	
			//returns % of limit of the restricted portion
			return (restrictedPortionPortMktVal / totalPortMktVal * 100) / restrictionLimit * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}

}
