package com.sky.tt.restriction.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.MLIndustryLookupSingleton;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityBarclaysIndustryRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityBarclaysIndustryRestriction.class);
	
	private static final String BARC_RESTRICTED_LIST_PARAMETER_NAME = "BarclaysIndustryList";
	private static final String ML_RESTRICTED_LIST_PARAMETER_NAME = "MLIndustryList";

	protected String barcIndustryString;
	protected String mlIndustryString;

	public SecurityBarclaysIndustryRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		
		barcIndustryString = parameterMap.get(BARC_RESTRICTED_LIST_PARAMETER_NAME).toString();
		mlIndustryString = parameterMap.get(ML_RESTRICTED_LIST_PARAMETER_NAME).toString();
	}


	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			List<String> barcRestrList = new ArrayList<String>(Arrays.asList(barcIndustryString.split("\\s*,\\s*")));
			List<String> mlRestrList = new ArrayList<String>(Arrays.asList(mlIndustryString.split("\\s*,\\s*")));
			
			//to make list case insensitive
			Set<String> barcListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			barcListNoCase.addAll(barcRestrList);
			
			Set<String> mlListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			mlListNoCase.addAll(mlRestrList);
			
			MLIndustryLookupSingleton indLookup = null;
			try {
				indLookup = MLIndustryLookupSingleton.getInstance();
			} catch (Exception e) {
				log.error(e);
				e.printStackTrace();
				return true;
			}
			
			//first check barclays industry
			String barclaysIndustry = indLookup.getBarclaysIndustry(security.getSymbol());
			String mlIndustryGroup = indLookup.getIndustryGroup(security.getSymbol());
	
			if (security.getSymbol().equalsIgnoreCase("ni") || (barclaysIndustry == null && mlIndustryGroup == null)) {//if it's a new issue, need to use security fields for ML industry if new issue set with overrides
				barclaysIndustry = null;
				mlIndustryGroup = security.getValue(SecurityField.INDUSTRY_GROUP).toString();
			} else {
				barclaysIndustry = indLookup.getBarclaysIndustry(security.getSymbol());
				mlIndustryGroup = indLookup.getIndustryGroupCode(security.getSymbol());
			}
			
			restrictionResultText = ((barclaysIndustry != null) ? "Barc: " + barclaysIndustry : "") + 
					((mlIndustryGroup != null) ? "ML: " + mlIndustryGroup : "");
				
			if (barclaysIndustry != null) {
				restrictionTested = true;
				restrictionResult = barcListNoCase.contains(barclaysIndustry);
				return restrictionResult;
			} else { //check ml industry
				restrictionTested = true;
				restrictionResult = mlListNoCase.contains(mlIndustryGroup);
				return restrictionResult;
			}
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 
		
	}
	
	@Override
	public String getRestrictedListText() {
		return "Barc: " + barcIndustryString + "\nML; " + mlIndustryString;
	}

}
