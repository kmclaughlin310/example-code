package com.sky.tt.db.query;

import java.sql.*;
import java.util.*;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.JDBCUtil;
import com.sky.tt.db.connection.TradeTicketDBConnection;
import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.*;
import com.sky.tt.handler.PreTradeSubmitServlet;


public class TableQuery {
	
	private static final Logger log = Logger.getLogger(TableQuery.class);
	
	public static Map<String, Object> getRowByID(String tableName, String columnName, int rowID) throws TradeTicketDBException, TradeTicketDBException {
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause(columnName, FilterClause.FieldComparator.EQ, new Integer(rowID)));
		List<Map<String, Object>> rows = getRows(tableName, filter);
		if (rows == null || rows.size() == 0) {
			return null;
		} else {
			return rows.get(0);
		}
	}
	
	public static Map<String, Object> getRowByID(String tableName, String columnName, int rowID, FilterClause additionalFilter) throws TradeTicketDBException, TradeTicketDBException {
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause(columnName, FilterClause.FieldComparator.EQ, new Integer(rowID)));
		filter.addFilterClause(additionalFilter);
		List<Map<String, Object>> rows = getRows(tableName, filter);
		if (rows == null || rows.size() == 0) {
			return null;
		} else {
			return rows.get(0);
		}
	}
	
	public static Map<String, Object> getRowByStringID(String tableName, String columnName, String identifier) throws TradeTicketDBException, TradeTicketDBException {
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause(columnName, FilterClause.FieldComparator.EQ, identifier));
		List<Map<String, Object>> rows = getRows(tableName, filter);
		if (rows == null || rows.size() == 0) {
			return null;
		} else {
			return rows.get(0);
		}
	}
	
	public static Map<String, Object> getRowByStringID(String tableName, String columnName, String identifier, FilterClause additionalFilter) throws TradeTicketDBException, TradeTicketDBException {
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause(columnName, FilterClause.FieldComparator.EQ, identifier));
		filter.addFilterClause(additionalFilter);
		List<Map<String, Object>> rows = getRows(tableName, filter);
		if (rows == null || rows.size() == 0) {
			return null;
		} else {
			return rows.get(0);
		}
	}
	
	public static List<Map<String, Object>> getRows(String tableName) throws TradeTicketDBException, TradeTicketDBException {
		return getRows(tableName, null);
	}
	
	
	//column name is the column you want to get i.e. select usergroupID from usergroupmembers <--usergroupID is column
	public static String getQuerySQL(String tableName, String columnName, Filter filter) {

		StringBuilder sql = new StringBuilder("SELECT " + columnName + " FROM " + tableName + " WHERE 1=1 ");
		if (filter != null) {
			sql.append(filter.getWhereClause());

			if (filter.getOrderByField() != null && !filter.getOrderByField().isEmpty()) {
				sql.append(filter.getOrderByClause());
			}
		}
		return sql.toString();
	}
	
	public static List<Map<String, Object>> getRows(String tableName, Filter filter) throws TradeTicketDBException, TradeTicketDBException {
		
		List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		StringBuilder sql = new StringBuilder("SELECT * FROM " + tableName + " WHERE 1=1 ");
		if (filter != null) {
			sql.append(filter.getWhereClause());
			if (filter.getOrderByField() != null && !filter.getOrderByField().isEmpty()) {
				sql.append(filter.getOrderByClause());
			}
		}
		
		connection = TradeTicketDBConnection.getConnection();
		
		try {
			statement = connection.prepareStatement(sql.toString());
			if (filter != null) {
				filter.setParameters(statement, 1);
			}

			rs = statement.executeQuery();
			
			while (rs.next()) {
				Map<String, Object> row = new HashMap<String, Object>();
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnCount = rsmd.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					row.put(rsmd.getColumnName(i), rs.getObject(i));
				}
				rows.add(row);
			}
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL Error querying data for " + tableName + ": " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(rs, statement, connection);
		}
		return rows;
		
	}
	
	public static double getSingleSum(String tableName, String columnName, Filter filter) throws TradeTicketDBException, TradeTicketDBException {
		
		List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
		Map<String, Object> resultRow = new HashMap<String, Object>();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		StringBuilder sql = new StringBuilder("SELECT SUM(" + columnName + ") as SumResult FROM " + tableName + " WHERE 1=1 ");
		if (filter != null) {
			sql.append(filter.getWhereClause());
			if (filter.getOrderByField() != null && !filter.getOrderByField().isEmpty()) {
				sql.append(filter.getOrderByClause());
			}
		}
		
		connection = TradeTicketDBConnection.getConnection();
		//System.out.println(sql.toString());
		try {
			statement = connection.prepareStatement(sql.toString());
			if (filter != null) {
				filter.setParameters(statement, 1);
			}

			rs = statement.executeQuery();
			
			while (rs.next()) {
				Map<String, Object> row = new HashMap<String, Object>();
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnCount = rsmd.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					row.put(rsmd.getColumnName(i), rs.getObject(i));
				}
				rows.add(row);
			}
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL Error querying data for " + tableName + ": " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(rs, statement, connection);
		}
		//return rows;
		if (rows == null || rows.size() == 0) {
			return 0;
		} else {
			resultRow = rows.get(0);
			if (resultRow.get("SumResult") == null) {
				return 0;
			} else {
				return Double.parseDouble(resultRow.get("SumResult").toString());
			}
		}
		
	}
	
	public static Object getScalarFunctionResult(String functionString) throws TradeTicketDBException, TradeTicketDBException {
		
		//List<Map<String, Object>> rows = new ArrayList<Map<String, Object>>();
		Object result;
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		StringBuilder sql = new StringBuilder("SELECT " + functionString);

		
		connection = TradeTicketDBConnection.getConnection();
		
		try {
			statement = connection.prepareStatement(sql.toString());
			rs = statement.executeQuery();
			
			if (rs.next()) {
				result = rs.getObject(1);
			} else {
				return null;
			}
			/*while (rs.next()) {
				Map<String, Object> row = new HashMap<String, Object>();
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnCount = rsmd.getColumnCount();
				for (int i = 1; i <= columnCount; i++) {
					row.put(rsmd.getColumnName(i), rs.getObject(i));
				}
				rows.add(row);
			}*/
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL Error querying data for " + functionString + ": " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(rs, statement, connection);
		}
		/*log.debug(result.toString());*/
		return result;
		
	}
	
}
