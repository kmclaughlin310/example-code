package com.sky.tt.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.jsonconvert.JSONStringConverter;

public class JSONHandlerDashAPXData extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1263375482035742521L;
	private static final Logger log = Logger.getLogger(JSONHandlerDashAPXData.class);


	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject jsonObj;
		Map<String, String> minorErrors = new HashMap<String, String>();
		
		String cusip = request.getParameter("CUSIP");
		
		List<Map<String, Object>> corpActionList = null;
		int corpActionCount = 0;
		Map<String, Object> idcPriceMap = null;
		Map<String, Object> results =  new HashMap<String, Object>();
		
		//corp actions
		try {
			corpActionList = TableQuery.getRows("CustomTradeTicket.fGetCorpActions('" + cusip + "')");
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			minorErrors.put("minorError", "Error occurred while retrieving corporate actions.");
		}
		for (Map<String, Object> ca : corpActionList) {
			corpActionCount++; //prevents corp action from being overwritten if there is more than 1 corp action
			results.put("CorpAction" + corpActionCount, ca.get("CorpActionTypeDesc"));
		}
		
		//idc price
		try {
			idcPriceMap = TableQuery.getRowByStringID("CustomTradeTicket.fGetIDCPrice('" + cusip + "')", "Symbol", cusip);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			minorErrors.put("minorError", !minorErrors.isEmpty() ? minorErrors.get("minorError") : "" + " Error occurred while retrieving IDC mark.");
		}
		if (idcPriceMap == null || idcPriceMap.isEmpty()) {
			results.put("IDCPrice", "Not Held");
		} else {
			results.put("IDCPrice", idcPriceMap.get("ClosePrice"));
		}
		
		
		String jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(results);
		jsonObj = new JSONObject(jsonStrOutput);
		
		if (! minorErrors.isEmpty()) {
			for (String e : minorErrors.keySet()) {
				jsonObj.put(e, minorErrors.get(e));
			}
		}
		
		return jsonObj;
	}

}
