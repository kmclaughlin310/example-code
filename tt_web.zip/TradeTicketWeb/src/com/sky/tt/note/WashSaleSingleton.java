package com.sky.tt.note;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;

public class WashSaleSingleton {

	private static final Logger log = Logger.getLogger(WashSaleSingleton.class);
	private static final long REFRESH_INTERVAL = 15;
	private Date timeAtRefresh = null;

	private static List<String> washSaleList; //map portid, cusip
	
	private static final String WASH_SALE_VIEW = "AdvApp.vCustWashSaleList";
	
	private static class SingletonHolder {
		private static final WashSaleSingleton INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new WashSaleSingleton();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	
	private WashSaleSingleton() throws TradeTicketDBException {
		createWashSaleList(); //populates marketValues and marketValuesExCash
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	private void createWashSaleList() throws TradeTicketDBException {
		List<Map<String, Object>> washSaleDBList = null;
		
		try {
			washSaleDBList = TableQuery.getRows(WASH_SALE_VIEW);
		} catch (TradeTicketDBException e) {
			log.error("Error setting up wash sale table: " + e.getMessage(), e);
			e.printStackTrace();
			throw e;
		}
		
		washSaleList = new ArrayList<String>();
		
		for (Map<String, Object> row : washSaleDBList) {
			washSaleList.add(row.get("PortfolioCode").toString() + row.get("CUSIP").toString());
		}
	}
	
	public boolean inWashSaleList(String portCode, String cusip) {
		checkStaleness();
		return washSaleList.contains(portCode + cusip);
		//return washSaleList.contains(cusip);
	}

	public static WashSaleSingleton getInstance() throws Exception { 
		return SingletonHolder.INSTANCE;		
	}
	
	public void checkStaleness() {
		if (timeAtRefresh != null) {
			Date now = Calendar.getInstance().getTime();
			long diff = (now.getTime() - timeAtRefresh.getTime()) / (60 * 1000);
			if (diff >= REFRESH_INTERVAL) {
				SingletonHolder.INSTANCE.forceRefresh();
			}
		}
	}

	private void forceRefresh() {
		log.debug("Wash sale singleton refreshed.");
		
		try {
			createWashSaleList();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
		}
		
		timeAtRefresh = Calendar.getInstance().getTime();
		
	}
	
	public static void forceWashSaleSingletonRefresh() {
		SingletonHolder.INSTANCE.forceRefresh();
	}
}
