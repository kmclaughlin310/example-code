package com.sky.tt.note;

import java.util.Map;

import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class PIKSecurity extends TradeTicketNote {

	public PIKSecurity(int noteId) {
		super(noteId);
	}

	public void init() throws Exception {
		super.init();
	}

	public String getNote(Security security, Map<String, Object> tradeTicketData) {			
		return security.getValue(SecurityField.COUPON_TYPE).toString().equalsIgnoreCase("PAY-IN-KIND") ? "POSSIBLE PIK" : "";
	}

}
