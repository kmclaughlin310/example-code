package com.sky.util;

public class ArraySort {
	
	public static double[] InsertionSort(double[] arrayToSort) {
		
		for (int i = 1; i < arrayToSort.length; i++) {
			double valueToSort = arrayToSort[i];
            int j = i;
            while (j > 0 && arrayToSort[j - 1] > valueToSort) {
            	arrayToSort[j] = arrayToSort[j - 1];
                j--;
            }
            arrayToSort[j] = valueToSort;
        }
		
		return arrayToSort;
	}
}
