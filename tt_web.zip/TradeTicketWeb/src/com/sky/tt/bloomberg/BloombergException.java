package com.sky.tt.bloomberg;

public class BloombergException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5263523603335066661L;	

	public BloombergException() {
	}

	public BloombergException(String arg0) {
		super(arg0);
	}

	public BloombergException(Throwable arg0) {
		super(arg0);
	}

	public BloombergException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
