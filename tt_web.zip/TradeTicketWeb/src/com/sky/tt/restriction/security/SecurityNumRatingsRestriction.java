package com.sky.tt.restriction.security;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.ratingcounter.SecurityRatingCounter;

public class SecurityNumRatingsRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityNumRatingsRestriction.class);
	
	private static final String NUM_RATINGS_PARAMETER_NAME = "MinNumRatings";
	private static final String SECURITY_RATING_COUNTER_PARAMETER_NAME = "SecurityRatingCounter";
	private static final String INCLUDE_EPU_RATINGS_PARAMETER_NAME = "IncludeEPURatings";	
	private static final String INCLUDE_FITCH_PARAMETER_NAME = "IncludeFitchRating";
	
	protected int minNumRatings;
	protected SecurityRatingCounter counter;
	protected boolean includeEPURatings = false;
	protected boolean includeFitch = true;

	public SecurityNumRatingsRestriction(int restrictionId) {
		super(restrictionId);
	}

	public void init() throws Exception { 
		
		super.init();
		
		minNumRatings = Integer.parseInt(parameterMap.get(NUM_RATINGS_PARAMETER_NAME).toString());
		counter = (SecurityRatingCounter) Class.forName(parameterMap.get(SECURITY_RATING_COUNTER_PARAMETER_NAME).toString()).newInstance();
		
		if (parameterMap.containsKey(INCLUDE_EPU_RATINGS_PARAMETER_NAME)) {
			includeEPURatings = (parameterMap.get(INCLUDE_EPU_RATINGS_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
		
		if (parameterMap.containsKey(INCLUDE_FITCH_PARAMETER_NAME)) {
			includeFitch = (parameterMap.get(INCLUDE_FITCH_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
	}

	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			int ratingsCount = 0;
			
			try {
				ratingsCount = counter.getSecurityRatingsCount(security, includeEPURatings, includeFitch);
				restrictionResultText = "Ratings: " + Integer.toString(ratingsCount);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				restrictionTested = false;
				restrictionResult = true;
				return true;
			}
				
			restrictionTested = true;
			restrictionResult = (ratingsCount < minNumRatings);
			return restrictionResult;
		} catch (Exception e) {
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 

	}
	
	
	
}
