package com.sky.tt.db.query;

import java.sql.*;
import java.util.*;

import com.sky.tt.db.connection.JDBCUtil;
import com.sky.tt.db.connection.TradeTicketDBConnection;
import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.Filter;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.user.User;

public class UserQuery {
	private static final String USER_TABLE_NAME = "CustomTradeTicket.Users";

	public static List<User> getUsers() throws TradeTicketDBException, FilterException {
		return getUsers(null);
	}
	
	public static List<User> getUsers(Filter filter) throws TradeTicketDBException, FilterException {
		
		List<User> users = new ArrayList<User>();
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		StringBuilder sql = new StringBuilder("SELECT * FROM " + USER_TABLE_NAME + " WHERE 1=1 ");
		if (filter != null) {
			sql.append(filter.getWhereClause());
		}
		
		connection = TradeTicketDBConnection.getConnection();
		
		try {
			statement = connection.prepareStatement(sql.toString());
			if (filter != null) {
				filter.setParameters(statement, 1);
			}
			
			rs = statement.executeQuery();
			
			while (rs.next()) {
				User user = new User(rs.getInt("userID"), rs.getString("UserName"), rs.getString("FullName"), rs.getString("MOXYUserID"));
				users.add(user);
			}
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL Error querying data for Users: " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(rs, statement, connection);
		}
		return users;
	}
	
	public static User getUser(String userName) throws TradeTicketDBException {
		List<User> users = null;
		Map<String, Object> filterData = new HashMap<String, Object>();
		filterData.put("UserName", userName);
		GenericFilter filter = new GenericFilter(filterData);
		try {
			users = getUsers(filter);
		} catch (FilterException e) {
			throw new TradeTicketDBException("Error building filter: " + e.getMessage(), e);
		}
		if (users != null && users.size() > 0) {
			return users.get(0);
		} else {
			return null;
		}
	}
	
	public static User getUser(int userID) throws TradeTicketDBException {
		List<User> users = null;
		Map<String, Object> filterData = new HashMap<String, Object>();
		filterData.put("UserID", new Integer(userID));
		GenericFilter filter = new GenericFilter(filterData);
		try {
			users = getUsers(filter);
		} catch (FilterException e) {
			throw new TradeTicketDBException("Error building filter: " + e.getMessage(), e);
		}
		if (users != null && users.size() > 0) {
			return users.get(0);
		} else {
			return null;
		}
	}
	
	public static int getUserID(String userName) throws TradeTicketDBException {
		Connection connection = TradeTicketDBConnection.getConnection();
		PreparedStatement statement = null;
		ResultSet rs = null;
		String sql = new String("SELECT UserID FROM " + USER_TABLE_NAME + " WHERE UserName = ?");
		
		try {
			statement = connection.prepareStatement(sql);	
			statement.setString(1, userName);
			rs = statement.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			} else {
				throw new TradeTicketDBException("Username '" + userName + "' not found.");
			}
		} catch (SQLException e) {
			throw new TradeTicketDBException("SQL Error querying data for Users: " + e.getMessage(), e);
		} finally {
			JDBCUtil.closeEverything(rs, statement, connection);
		}
		
	}

}
