package com.sky.tt.security;

import java.text.ParseException;
import java.text.SimpleDateFormat;


public enum SecurityField {
	//from existing security setup (com.sky.apx.security.APXSecurityField.java)
	//Booleans were changed to string ("Y" or "N")
	SECTYPE("Security Type", FieldType.STRING),
	SYMBOL("Symbol", FieldType.STRING),
	CUSIP("CUSIP", FieldType.STRING),
	DESCRIPTION("Description", FieldType.STRING),
	INDUSTRY_GROUP("Industry Group", FieldType.STRING),
	INDUSTRY_SECTOR("Industry Sector", FieldType.STRING),
	RISK_COUNTRY("Country of Risk", FieldType.STRING),
	ISSUE_COUNTRY("Country of Issue", FieldType.STRING),
	ISSUE_DATE("Issue Date", FieldType.DATE),
	//FIRST_COUPON_DATE("First Coupon Date", FieldType.DATE),
	//LAST_COUPON_DATE("Last Coupon Date", FieldType.DATE),
	MATURITY_DATE("Maturity Date", FieldType.DATE),
	DIVINT_RATE("Interest Rate", FieldType.FLOAT),
	//ACCRUAL_CALENDAR("Accrual Calendar Code", FieldType.STRING),
	//PAYMENT_FREQUENCY("Payment Frequency", FieldType.INTEGER),
	TICKER("Ticker", FieldType.STRING),
	SEDOL("SEDOL", FieldType.STRING),
	ISIN("ISIN", FieldType.STRING),
	BBID("BBID", FieldType.STRING),
	//PRIMARY_SYMBOL("Primary Symbol", FieldType.STRING),
	SP_RATING("S&P Rating", FieldType.STRING),
	MOODY_RATING("Moody Rating", FieldType.STRING),
	FITCH_RATING("Fitch Rating", FieldType.STRING),
	//RESET_FREQUENCY("Reset Frequency", FieldType.INTEGER),
	//COUPON_PAYMENT_RULE("Coupon Payment Rule", FieldType.INTEGER),
	//COUPON_PAYMENT_FREQUENCY("Coupon Payment Freqeuncy", FieldType.INTEGER),
	//COUPON_PAYMENT_HOLIDAY("Coupon Payment Holiday", FieldType.STRING),
	//RESET_METHOD("Reset Method", FieldType.INTEGER),
	//COUPON_PAYMENT_METHOD("Coupon Payment Method", FieldType.INTEGER),
	R144A("144A Flag", FieldType.STRING),
	REG_RIGHTS("Reg Rights Flag", FieldType.BOOLEAN),
	COUPON_TYPE("Coupon Type", FieldType.STRING),
	RAW_SP("Raw S&P Rating", FieldType.STRING),
	RAW_MOODY("Raw Moody Rating", FieldType.STRING),
	RAW_FITCH("Raw Fitch Rating", FieldType.STRING),
	BAML_MASTER_II("In BAML Master II Index", FieldType.STRING),
	ISSUER_OUT("Issuer Outstanding", FieldType.FLOAT),
	AMT_ISSUED("Issue Amount", FieldType.FLOAT),
	COUNTRY_INCORP("Country of Incorporation", FieldType.STRING),
	ACTUAL_ISSUE_DATE("Actual Issue Date", FieldType.DATETIME),
	//new fields
	MIN_PIECE("Minimum Piece", FieldType.FLOAT),
	INTEREST_ACCRUED("Interest Accrued", FieldType.FLOAT),
	SEC_DESC("Security Description", FieldType.STRING), 
	COLLAT_TYPE("Collateral Type", FieldType.STRING),
	IS_PERPETUAL("Is Perpetual", FieldType.STRING),
	BBG_PARENT_CO("Bloomberg Ultimate Parent Co Name", FieldType.STRING),
	LOAN_SPREAD("Loan Spread", FieldType.FLOAT),
	SECURITY_FACTORABLE("Security Factorable", FieldType.STRING),
	CAPITAL_CONTINGENT_SEC("Capital Contingent Security", FieldType.STRING),
	DRD_ELIGIBLE("DRD Eligible", FieldType.STRING),
	REAL_BBG_DEPT_DES("Bloomberg Sector Lookup", FieldType.STRING),
	IS_HYBRID("Is Hybrid", FieldType.STRING),
	IS_DEFAULTED("Is Defaulted", FieldType.STRING),
	SECTYPE_OVERRIDE("Sec Type Override", FieldType.STRING);
	
	public static final String SECURITY_DATE_FORMAT = "MM/dd/yyyy";	
	
	public enum FieldType {
		INTEGER,
		STRING,
		BOOLEAN,
		DATE,
		DATETIME,
		FLOAT
	}
	
	private final String name;
	private final FieldType fieldType;
	
	SecurityField(String name, FieldType fieldType) {
		this.name = name;
		this.fieldType = fieldType;
	}

	public FieldType getFieldType() {
		return fieldType;
	}

	public String getName() {
		return name;
	}
	
	public static SecurityField getSecurityField(String fieldName) {
		for (SecurityField secField : SecurityField.values()) {
			if (secField.getName().equalsIgnoreCase(fieldName)) {
				return secField;
			}
		}
		
		return null; //is this right?		
	}
	
	
	public boolean isFieldEqual(Object value1, Object value2) {
		
		if ((value1 == null || value1.equals("")) && (value2 == null || value2.equals(""))) {
			return true;
		}
		
		if ((value1 == null || value1.equals("")) && (value2 != null && !value2.equals(""))) {
			return false;
		}
		
		if ((value2 == null || value2.equals("")) && (value1 != null && !value1.equals(""))) {
			return false;
		}
		
		switch (fieldType) {
		
		case INTEGER:
			try {
				return Integer.parseInt(value1.toString()) == Integer.parseInt(value2.toString());
			} catch (NumberFormatException e) {
				return false;
			}
		case FLOAT:
			try {
				return Double.parseDouble(value1.toString()) == Double.parseDouble(value2.toString());
			} catch (NumberFormatException e) {
				return false;
			}
		case DATE:
			try {
				SimpleDateFormat dtFormat = new SimpleDateFormat(SECURITY_DATE_FORMAT);
				return dtFormat.parse(value1.toString()).equals(dtFormat.parseObject(value2.toString()));
			} catch (ParseException e) {
				return false;
			}
		/*case CUSTOM_SECURITY:
			switch (apxFile) {
			case ENM:
				try {
					return Double.parseDouble(value1.toString()) == Double.parseDouble(value2.toString());
				} catch (NumberFormatException e) {
					return false;
				}
			case EDT:
				try {
					SimpleDateFormat apxFormat = new SimpleDateFormat(APXSecurityFormatter.APX_DATE_FORMAT);
					return apxFormat.parse(value1.toString()).equals(apxFormat.parseObject(value2.toString()));
				} catch (ParseException e) {
					return false;
				}
			default:
				return value1.equals(value2);
			}*/
		default:
			return value1.equals(value2);
		}
	}
}
	