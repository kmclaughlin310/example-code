package com.sky.tt.restriction.aggregateval;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.logic.DashboardHoldings;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateValRestriction;
import com.sky.tt.security.Security;

public class AggregateValGenericRestriction extends AggregateValRestriction {
	
	private static final Logger log = Logger.getLogger(AggregateValGenericRestriction.class);
	
	public AggregateValGenericRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();		
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity) {		
		try {
			if (action.equalsIgnoreCase("sell")) {
				return 0;
			}
			
			//select sum(HoldingsSumColumn) from CustomTradeTicket.vCurrentHoldings where HoldingsFilterField = valueof(SecurityFilterField);
			
			double denominator = Double.parseDouble(security.getValue(denominatorField).toString()); //such as issue outstanding, issuer outstanding; all of which can come from the BBG fields
			String secFieldValue = security.getValue(secFilterField).toString(); //ticker, cusip, etc.
			double numerator = 0;
			
			GenericFilter filter = new GenericFilter();
			filter.addFilterClause(new FilterClause(holdingsFilterField, FilterClause.FieldComparator.EQ, secFieldValue));
			filter.addFilterClause(new FilterClause("PortfolioID", FilterClause.FieldComparator.EQ, portfolio.getPortfolioID()));
			
			try {
				numerator = TableQuery.getSingleSum("CustomTradeTicket.CurrentHoldings", holdingsSumColumn, filter);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				return 999;
			}
			
			numerator = numerator + (quantity * security.getQuantityFactor());
			
			return (numerator / denominator * 100) / restrictionLimitPct * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}

}
