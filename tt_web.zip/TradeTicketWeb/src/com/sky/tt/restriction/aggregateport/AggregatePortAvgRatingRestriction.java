package com.sky.tt.restriction.aggregateport;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregatePortRestriction;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.SecurityRatingCalculator;

public class AggregatePortAvgRatingRestriction extends AggregatePortRestriction {
	
	private static final String SECURITY_RATING_CALCULATOR_PARAMETER_NAME = "SecurityRatingCalculator"; // parameter to indicate which class to use as the rating calculator
	private static final String INCLUDE_EPU_RATINGS_PARAMETER_NAME = "IncludeEPURatings";
	private static final String INCLUDE_FITCH_RATING_PARAMETER_NAME = "IncludeFitchRating";
	private static final String SQL_RATING_COLUMN_PARAMETER_NAME = "SQLRatingFunction";
	
	protected SecurityRatingCalculator calculator;
	protected boolean includeEPURatings = false;
	protected boolean includeFitchRating = true;
	protected String sqlRatingColumn;
	
	private static final Logger log = Logger.getLogger(AggregatePortAvgRatingRestriction.class);
	
	public AggregatePortAvgRatingRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();	
		
		calculator = (SecurityRatingCalculator) Class.forName(parameterMap.get(SECURITY_RATING_CALCULATOR_PARAMETER_NAME).toString()).newInstance();
		sqlRatingColumn = parameterMap.get(SQL_RATING_COLUMN_PARAMETER_NAME).toString();
		
		if (parameterMap.containsKey(INCLUDE_EPU_RATINGS_PARAMETER_NAME)) {
			includeEPURatings = (parameterMap.get(INCLUDE_EPU_RATINGS_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
		
		if (parameterMap.containsKey(INCLUDE_FITCH_RATING_PARAMETER_NAME)) {
			includeFitchRating = (parameterMap.get(INCLUDE_FITCH_RATING_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
	}


	public double restrictionApplies(Security security, String action, boolean exCash) {
		
		if (!exCash && action.equalsIgnoreCase("sell")) {
			return 0;
		}
		
		double rating = 0;
		
		try {
			rating = calculator.getSecurityRating(security, includeEPURatings, includeFitchRating);  
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			return 999;
		}
		
		if (action.equalsIgnoreCase("buy")) {
			switch (inequal) {
			case LT:
				return (rating < restrictionLimit ? rating : 0);
			case GT:
				return (rating > restrictionLimit ? rating : 0);
			case LTE:
				return (rating <= restrictionLimit ? rating : 0);
			case GTE:
				return (rating >= restrictionLimit ? rating : 0);
			default:
				return 999;
			} 
		} else { //sell
			switch (inequal) {
			case LT:
				return (rating > restrictionLimit ? rating : 0);
			case GT:
				return (rating < restrictionLimit ? rating : 0);
			case LTE:
				return (rating >= restrictionLimit ? rating : 0);
			case GTE:
				return (rating <= restrictionLimit ? rating : 0);
			default:
				return 999;
			}
		}
		
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			//needs to be tested for ex cash restriction type, since there were none at time of creation
			double rating = restrictionApplies(security, action, exCash);
			
			if (rating == 0 || rating == 999) {
				return rating;
			}
			
			double numerator = 0;
			double denominator = 0;
			
			GenericFilter filter = new GenericFilter();
			filter.addFilterClause(new FilterClause("PortfolioID", FilterClause.FieldComparator.EQ, portfolio.getPortfolioID()));
			//account for excash
			if (exCash) {
				filter.addFilterClause(new FilterClause("SecurityID", FilterClause.FieldComparator.NE, 6));
			}
			
			try {
				numerator = TableQuery.getSingleSum("CustomTradeTicket.CurrentHoldings", "ISNULL(" + sqlRatingColumn + ",0) * (MarketVal + AccrInt)", filter);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.error(e);
				return 999;
			}
			
			//add new securities contribution to avg maturity numerator
			if (action.equalsIgnoreCase("buy")) {
				numerator = numerator + (rating * ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()));
			} else { //sell
				numerator = numerator - (rating * ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()));
			}
			
			denominator = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
			
			//add or subtract new securities market value to denominator if exCash
			if (exCash) {
				denominator = (action.equalsIgnoreCase("buy") ? denominator + (quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor() : denominator - (quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor());
			}
			
			return (numerator/denominator) / restrictionLimit * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}

}
