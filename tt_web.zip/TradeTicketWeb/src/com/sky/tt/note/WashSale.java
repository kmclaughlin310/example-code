package com.sky.tt.note;

import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class WashSale extends TradeTicketNote {
	private static final Logger log = Logger.getLogger(WashSale.class);
	
	public WashSale(int noteId) {
		super(noteId);
	}

	public void init() throws Exception {
		super.init();
	}

	public String getNote(Security security, Map<String, Object> tradeTicketData) {	
		if (tradeTicketData.get("action").toString().equalsIgnoreCase("sell")) {
			return "";
		}
		
		WashSaleSingleton singleton = null;
		
		try {
			singleton = WashSaleSingleton.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			return "ERROR CHECKING FORE WASH SALE.";
		}
		
		return singleton.inWashSaleList(portCode, security.getValue(SecurityField.CUSIP).toString()) ? "POTENTIAL WASH SALE" : "";
	}

}
