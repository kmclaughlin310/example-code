package com.sky.tt.note;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class BCBSPricePreApproval extends TradeTicketNote {
	private static final Logger log = Logger.getLogger(BCBSPricePreApproval.class);
	private DecimalFormat numTwoDec = new DecimalFormat("#,###.00");

	public BCBSPricePreApproval(int noteId) {
		super(noteId);
	}
	
	public void init() throws Exception {
		super.init();
	}

	public String getNote(Security security, Map<String, Object> tradeTicketData) {		
		if (tradeTicketData.get("action").toString().equalsIgnoreCase("buy")) {
			return "";
		}
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return "ERROR CHECKING PRICE APPROVAL NOTE";
		}

		double secUnitCost = singleton.getSecurityUnitCost(portId, security.getValue(SecurityField.CUSIP).toString()) ;  //purchase price of security
		if (Calendar.getInstance().get(Calendar.MONTH) <= 2) { //Calendar.MONTH is zero-indexed
			return "Pre-Approv < " + numTwoDec.format(Math.round(secUnitCost * 4) / 4f);
		} else {
			return "Pre-Approv < " + numTwoDec.format(secUnitCost * 0.9);
		}
	}

}
