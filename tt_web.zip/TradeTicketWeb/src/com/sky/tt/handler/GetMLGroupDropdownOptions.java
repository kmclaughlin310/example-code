package com.sky.tt.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.util.GetDropdownOptions;

public class GetMLGroupDropdownOptions extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7579072896525168233L;
	private static final Logger log = Logger.getLogger(GetMLGroupDropdownOptions.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		int sectorID = Integer.parseInt(request.getParameter("SectorID").toString());
		String options = null;
		JSONObject output = new JSONObject();
		
		try {
			options = GetDropdownOptions.getMLGroupOptions(sectorID);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			output.put("minorError", "Error occurred while retrieving ML industry group dropdown options.");
		}

		output.put("optionsString", options);
		
		return output;
	}

}
