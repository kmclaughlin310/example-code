package com.sky.tt.restriction.aggregateport;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregatePortRestriction;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregatePortAvgMaturityRestriction extends AggregatePortRestriction {
	
	private static final Logger log = Logger.getLogger(AggregatePortAvgMaturityRestriction.class);
	
	public AggregatePortAvgMaturityRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();	
	}


	public double restrictionApplies(Security security, String action, boolean exCash) {
		
		if (!exCash && action.equalsIgnoreCase("sell")) {
			return 0;
		}
		
		if (security.getValue(SecurityField.MATURITY_DATE) == null) {
			return 999;
		}
		String maturityString = security.getValue(SecurityField.MATURITY_DATE).toString();
		
		DateFormat format = new SimpleDateFormat(SecurityField.SECURITY_DATE_FORMAT, Locale.ENGLISH);
		
		Date maturityDate = null;
		Date today = new Date();
		double dateDiff = 0;
		
		try {
			maturityDate = format.parse(maturityString);
		} catch (ParseException e) {
			log.error(e);
			e.printStackTrace();
			return 999;
		}
		
		dateDiff = ((maturityDate.getTime() - today.getTime()) / (24 * 60 * 60 * 1000)) / 365.0;
		//System.out.println(dateDiff);
		
		if (action.equalsIgnoreCase("buy")) { //if buy, check restriction is maturity is outside of acceptable average
			switch (inequal) {
			case LT:
				return (dateDiff < restrictionLimit ? dateDiff : 0);
			case GT:
				return (dateDiff > restrictionLimit ? dateDiff : 0);
			case LTE:
				return (dateDiff <= restrictionLimit ? dateDiff : 0);
			case GTE:
				return (dateDiff >= restrictionLimit ? dateDiff : 0);
			default:
				return 999;
			}
		} else { //if sell, check restriction if maturity is within acceptable range
			switch (inequal) {
			case LT:
				return (dateDiff > restrictionLimit ? dateDiff : 0);
			case GT:
				return (dateDiff < restrictionLimit ? dateDiff : 0);
			case LTE:
				return (dateDiff >= restrictionLimit ? dateDiff : 0);
			case GTE:
				return (dateDiff <= restrictionLimit ? dateDiff : 0);
			default:
				return 999; 
			}
		}
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			double yearsToMaturity = restrictionApplies(security, action, exCash);
			
			if (yearsToMaturity == 0 || yearsToMaturity == -1 || yearsToMaturity == 999) {
				return yearsToMaturity;
			}
			
			//if include cash, just do over MVAI of whole portfolio; if ex cash, add MVAI of purchase to denominator
			//numerator = security maturity * MVAI of purchase + (sum of maturity * MVAI from database)
			//denominator = MVAI from db (+ MVAI of purchase if inclusive of cash)
			double numerator = 0;
			double denominator = 0;
			
			
			//for avg maturity, exCash doesn't matter for numerator because it adds zero
			GenericFilter filter = new GenericFilter();
			filter.addFilterClause(new FilterClause("PortfolioID", FilterClause.FieldComparator.EQ, portfolio.getPortfolioID()));
			try {
				numerator = TableQuery.getSingleSum("CustomTradeTicket.CurrentHoldings", "ISNULL((DATEDIFF(d,GETDATE(),MaturityDate) / 365.0),0) * (MarketVal + AccrInt)", filter);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.error(e);
				return 999;
			}
			
			//add new securities contribution to avg maturity numerator
			if (action.equalsIgnoreCase("buy")) {
				numerator = numerator + (yearsToMaturity * ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()));
			} else {
				numerator = numerator - (yearsToMaturity * ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()));
			}
			
			denominator = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
			
			//add or subtract new securities market value to denominator if exCash
			if (exCash) {
				denominator = (action.equalsIgnoreCase("buy") ? denominator + (quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor() : denominator - (quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor());
			}

			return (numerator/denominator) / restrictionLimit * 100;
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return 999;
		} 
	}
}
