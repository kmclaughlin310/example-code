package com.sky.tt.db.filter;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

import org.apache.log4j.Logger;

public class GenericFilter implements Filter {

	private static final Logger log = Logger.getLogger(Filter.class);
	
	protected List<FilterClause> filterClauses;
	
	protected OrderByClause orderByClause;
	
	public GenericFilter() {
		filterClauses = new ArrayList<FilterClause>();
	}
	
	public GenericFilter(List<FilterClause> filterClauses) {
		this.filterClauses = filterClauses;
	}
	
	public GenericFilter(Map<String, Object> filter) {
		filterClauses = new ArrayList<FilterClause>();
		for (String column : filter.keySet()) {
			FilterClause clause = new FilterClause(column, FilterClause.FieldComparator.EQ, filter.get(column));
			filterClauses.add(clause);
		}
	}
	
	public void addFilterClause(FilterClause filter) {
		filterClauses.add(filter);
	}
	
	public void addOrderByClause(OrderByClause orderBy) {
		orderByClause = orderBy;
	}
	
	public void insertFilterClause(int index, FilterClause filter) {
		filterClauses.add(index, filter);
	}
	
	public FilterClause deleteFilterClause(int index) {
		return filterClauses.remove(index);
	}
	
	public boolean deleteFilterClause(FilterClause filter) {
		return filterClauses.remove(filter);
	}
	
	public String toString() {
		StringBuilder output = new StringBuilder();
		for (FilterClause filter : filterClauses) {
			output.append(filter.toString());
		}
		return output.toString();
	}
	
	@Override
	public String getWhereClause() {
		StringBuilder sql = new StringBuilder();
		for (FilterClause filter : filterClauses) {
			sql.append(filter.getFilterSQL());
		}
		
		log.trace("SQL where clause generated: " + sql);
		
		return sql.toString();
	}
	
	@Override
	public String getOrderByClause() {
		StringBuilder sql = new StringBuilder();
		sql.append(orderByClause.getClauseSQL());
		
		log.trace("SQL order by clause generated: " + sql);
		
		return sql.toString();
	}
	
	public String getOrderByField() {
		if (orderByClause == null) {
			return null;
		}
		return orderByClause.getFieldName();
	}

	@Override
	public void setParameters(PreparedStatement stmt, int startParameterId) {
		for (FilterClause filter : filterClauses) {
			if (filter.needsValue()) {
				try {
					stmt.setObject(startParameterId++, filter.getValue());
				} catch (SQLException e) {
					try {
						throw new FilterException("Error setting parameters for filter: " + e.getMessage(), e);
					} catch (FilterException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		}
	}
}


