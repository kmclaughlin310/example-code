package com.sky.tt.handler;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.logic.DashboardHoldings;

public class GetGenericDashboardHoldings extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6627283904615471427L;
	private static final Logger log = Logger.getLogger(GetGenericDashboardHoldings.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {		
		Map<String, Map<String, Object>> holdings = DashboardHoldings.getGenericDashHoldings();
		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		
		for (String port : holdings.keySet()) {
			holdings.get(port).put("CashPct", numTwoDec.format(Double.parseDouble(holdings.get(port).get("CashPct").toString())));
			holdings.get(port).put("PreAllocatedCash", numTwoDec.format(Double.parseDouble(holdings.get(port).get("PreAllocatedCash").toString())));
			holdings.get(port).put("MarketValueAI", numTwoDec.format(Double.parseDouble(holdings.get(port).get("MarketValueAI").toString())));
		}
		
		String returnStr = JSONStringConverter.getJSONForTTHoldings(holdings);
		JSONObject returnObj = new JSONObject(returnStr);
		
		return returnObj;
	}

}
