package com.sky.tt.security.ratingcalc;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton.RatingType;

public class AverageRatingCalculator implements SecurityRatingCalculator {

	private static final Logger log = Logger.getLogger(AverageRatingCalculator.class);
	
	public double getSecurityRating(Security security, boolean includeEPURatings, boolean includeFitchRatings) throws TradeTicketDBException {
		//includeFitchRatings is not actually used

		double spRating = 0;
		double mdyRating = 0;
		double fitchRating = 0;
		double totalRatingVal = 0;
		double avgRating = 0;
		int numRatings = 0;
		
		RatingConverterSingleton converter = RatingConverterSingleton.getInstance();
		
		
		spRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_SP, includeEPURatings);
		mdyRating = converter.getNumericSecurityRating(security, RatingType.MOODY, SecurityField.RAW_MOODY, includeEPURatings);
		fitchRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_FITCH, includeEPURatings);

		
		if (spRating > 0) {
			totalRatingVal = totalRatingVal + spRating;
			numRatings = numRatings + 1;
		}
		if (mdyRating > 0) {
			totalRatingVal = totalRatingVal + mdyRating;
			numRatings = numRatings + 1;
		}
		if (fitchRating > 0) {
			totalRatingVal = totalRatingVal + fitchRating;
			numRatings = numRatings + 1;
		}
		
		
		if (numRatings > 0) {
			avgRating = totalRatingVal / numRatings + .5;
		} 
		
		return avgRating;
	}

	@Override
	public String getSecurityRatingText(Security security) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getSecurityRatingText(double value) {
		try {
			RatingConverterSingleton ratingConverter = RatingConverterSingleton.getInstance();
			return ratingConverter.getSPRatingText(value);
		} catch (TradeTicketDBException e) {
			log.error(e);
			return null;
		}
	}
}

