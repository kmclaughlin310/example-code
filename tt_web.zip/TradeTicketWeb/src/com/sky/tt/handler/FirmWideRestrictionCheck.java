package com.sky.tt.handler;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.jsonconvert.JSONStringConverter;

public class FirmWideRestrictionCheck extends JSONHandlerServlet {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7712995197924821002L;
	private static final Logger log = Logger.getLogger(JSONHandlerDashAPXData.class);


	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject jsonObj;
		Map<String, String> minorErrors = new HashMap<String, String>();
		
		String ticker = request.getParameter("ticker");
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date currDate = new Date();
		
		List<Map<String, Object>> tickerList = null;
		Map<String, Object> results = new HashMap<String, Object>();
		
		//corp actions
		try {
			tickerList = TableQuery.getRows("CustomTradeTktRestriction.FirmWideRestrictedTickerList");
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			minorErrors.put("minorError", "Error occurred while retrieving firm wide restricted ticker list.");
		}
		
		Date startDate = new Date();
		Date endDate = new Date();
		for (Map<String, Object> t : tickerList) {
			try {
				startDate = dateFormat.parse(t.get("StartDate").toString());
				if (t.get("EndDate") != null) {
					endDate = dateFormat.parse(t.get("EndDate").toString());
				}
			} catch (ParseException e) {
				log.error(e);
				e.printStackTrace();
				minorErrors.put("minorError", "Error occurred while retrieving firm wide restricted ticker list (date conversion).");
			}
			if (t.get("Ticker").toString().equalsIgnoreCase(ticker) && currDate.after(startDate)) {
				if (t.get("EndDate") == null) {
					results.put("result", true);
				} else {
					if (currDate.before(endDate)) {
						results.put("result", true);
					}
				}
			}
		}
		if (results.isEmpty()) {
			results.put("result", false);
		}
		
		
		String jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(results);
		jsonObj = new JSONObject(jsonStrOutput);
		
		if (! minorErrors.isEmpty()) {
			for (String e : minorErrors.keySet()) {
				jsonObj.put(e, minorErrors.get(e));
			}
		}
		
		return jsonObj;
	}
}
