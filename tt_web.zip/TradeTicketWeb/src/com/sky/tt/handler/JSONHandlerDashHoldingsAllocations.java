package com.sky.tt.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.logic.DashboardHoldings;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityConverter;
import com.sky.util.ErrorHandlingUtility;

public class JSONHandlerDashHoldingsAllocations extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8254054792833024557L;
	private static final Logger log = Logger.getLogger(DashboardHoldings.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		
		
		JSONObject jsonObj = new JSONObject();
		
		String jsonStrInput = request.getParameter("jsonString");
		
		//create security
		JSONObject jsonObjForSecurity;
		JSONArray jsonSecArray = new JSONArray();
		Security security = null;

		jsonObjForSecurity = new JSONObject(jsonStrInput);
		jsonSecArray = new JSONArray(jsonObjForSecurity.get("SecurityData").toString());
	
		JSONObject tempObj = new JSONObject();
		for (String k : jsonSecArray.getJSONObject(0).keySet()) {
			tempObj.put(k, jsonSecArray.getJSONObject(0).get(k));
		}

		if (!jsonObjForSecurity.getString("cusip").equalsIgnoreCase("ni")) {
			security = SecurityConverter.convertBBGMapToSecurity(tempObj.toString());
		} else { 
			security = SecurityConverter.convertNewIssueBBGMapToSecurity(tempObj.toString());
		}
		//end create security
		
		
		//create strategy list in case it's needed
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			jsonObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return jsonObj;
		}
		
		List<String> strategies = singleton.getStrategies();
		//end create strategy list
		
		Map<String, Object> parsedMap = new HashMap<String, Object>();		
		parsedMap = JSONStringConverter.getTTMapFromJSONString(jsonStrInput);
		
		Map<String, Map<String, Object>> dashHoldingsList = new HashMap<String, Map<String, Object>>();
		Map<String, Object> dashOverride = new HashMap<String, Object>(); //for single row update, i.e. allocation override or NAVOverride
				
		String jsonStrOutput = null;
		String updateType;
		updateType = jsonObjForSecurity.getString("UpdateType");

		if (updateType.equalsIgnoreCase("noAllocation")) {
			dashHoldingsList = DashboardHoldings.getDashHoldingsNoTargetAllocations(parsedMap, security, null);
		} else if (updateType.equalsIgnoreCase("allocateSingleStrategy")) {
			dashHoldingsList = DashboardHoldings.getDashAllocations(parsedMap, security, jsonObjForSecurity.getString("Strategy"));
		} else if (updateType.equalsIgnoreCase("NAVOverride")) {
			dashOverride = DashboardHoldings.getNAVAdjustmentResults(parsedMap, security);
		} else if (updateType.equalsIgnoreCase("allocToBlank")) {
			dashOverride = DashboardHoldings.getNAVAdjustmentResults(parsedMap, security);
			dashOverride.put("ActualAllocation", "0");
			//and need to get agg restriction results with zero allocation
			//need portCode for k
			String portCode = parsedMap.get("PortCode").toString();
			dashOverride.put("AggregateRestriction", DashboardHoldings.getAggRestrictionResult(parsedMap, portCode, 0, security)); //CHANGE HERE
			
			JSONObject obj = new JSONArray(parsedMap.get("DashTable")).getJSONObject(0);
			//add agg restriction for group members i.e. BBBANK
			if (singleton.isInRestrictionGroup(singleton.getPortID(portCode))) {
				for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(portCode)))) {
					dashOverride.put(singleton.getPortCode(member) + "AggregateRestriction", DashboardHoldings.getAggRestrictionResult(parsedMap, portCode, Double.parseDouble(obj.getString(singleton.getPortCode(member) + "ActualAlloction")), security)); //CHANGE HERE
				}
			}
			
		} else if (updateType.equalsIgnoreCase("allocationOverride")) {
			dashOverride = DashboardHoldings.getAllocationOverrideResults(parsedMap, security);
		} else if (updateType.equalsIgnoreCase("allocate")) { 
			for (String strat : strategies) {
				if (! jsonObjForSecurity.getString(strat + "TargetAllocation").isEmpty()) {
					dashHoldingsList.putAll(DashboardHoldings.getDashAllocations(parsedMap, security, strat));
				} else {
					dashHoldingsList.putAll(DashboardHoldings.getDashHoldingsNoTargetAllocations(parsedMap, security, strat));
				}
			}
		} else if (updateType.equalsIgnoreCase("noAllocationPriceChange")) { 
			JSONArray tempArray = new JSONArray(jsonObjForSecurity.get("IndividualAllocations").toString()); //only getting agg restriction
			for (String k: tempArray.getJSONObject(0).keySet()) {
				dashOverride.put(k + "AggregateRestriction", DashboardHoldings.getAggRestrictionResult(parsedMap, k, Double.parseDouble(tempArray.getJSONObject(0).get(k).toString()), security)); //CHANGE HERE
				
				//add agg restriction for group members i.e. BBBANK
				if (singleton.isInRestrictionGroup(singleton.getPortID(k))) {
					for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(k)))) {
						dashOverride.put(singleton.getPortCode(member) + "AggregateRestriction", DashboardHoldings.getAggRestrictionResult(parsedMap, k, Double.parseDouble(tempArray.getJSONObject(0).get(k).toString()), security)); //CHANGE HERE
					}
				}
			}
		} else if (updateType.equalsIgnoreCase("allocationMethodChange")) {
			if (jsonObjForSecurity.getString("Strategy").equalsIgnoreCase("SDHY") && ! jsonObjForSecurity.getString("SDHYTargetAllocation").isEmpty()) {
				dashHoldingsList = DashboardHoldings.getDashAllocations(parsedMap, security, "SDHY");
			} else { //change core methodology
				if (! jsonObjForSecurity.getString("CORECONTargetAllocation").isEmpty()) {
					dashHoldingsList.putAll(DashboardHoldings.getDashAllocations(parsedMap, security, "CORECON"));
				}
				if (! jsonObjForSecurity.getString("COREUNCTargetAllocation").isEmpty()) {
					dashHoldingsList.putAll(DashboardHoldings.getDashAllocations(parsedMap, security, "COREUNC"));				
				}
				if (! jsonObjForSecurity.getString("ENRGTargetAllocation").isEmpty()) {
					dashHoldingsList.putAll(DashboardHoldings.getDashAllocations(parsedMap, security, "ENRG"));
				}
			}
		}
		
		//DashboardHoldings will return null if an error occurred, therefore check for nulls		
		if (updateType.equalsIgnoreCase("NAVOVerride") || updateType.equalsIgnoreCase("allocationOverride") || updateType.equalsIgnoreCase("noAllocationPriceChange")) {
			if (dashOverride == null) {
				jsonObj.put("ERROR", "DashboardHoldings class returned null - check log for errors.");
				return jsonObj;
			} else {
				jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(dashOverride);
			}
		} else {
			if (dashHoldingsList == null) {
				jsonObj.put("ERROR", "DashboardHoldings class returned null - check log for errors.");
				return jsonObj;
			} else {
				jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(dashHoldingsList);
			}
		}

		jsonObj = new JSONObject(jsonStrOutput);

		return jsonObj;
	}

}
