package com.sky.util;


import java.util.*;

import org.json.*;

public class JSONArraySort {
	
	public static SortedMap<String, Object> sortArray(JSONArray toBeSorted) {
		
		JSONObject jsonObj = new JSONObject();
		SortedMap<String, Object> map = new TreeMap<String, Object>();
		
		for (String k : toBeSorted.getJSONObject(0).keySet()) {
			jsonObj.put(k, toBeSorted.getJSONObject(0).get(k));
		}

		for (String k : jsonObj.keySet()) {
			map.put(k, jsonObj.get(k));
		}
	    
	    return map;
	}

}
