package com.sky.tt.note;

import java.util.HashMap;
import java.util.Map;

import com.sky.tt.db.query.TableQuery;
import com.sky.tt.security.Security;


public abstract class TradeTicketNote {

	protected int noteId;
	protected Map<String, Object> parameterMap;
	protected int portId;
	protected String javaClassName;
	protected String portCode;
	
	public TradeTicketNote(int noteId) {
		this.noteId = noteId;
		this.parameterMap = new HashMap<String, Object>();
	}
	
	public void init() throws Exception {		
		parameterMap = TableQuery.getRowByID("CustomTradeTicket.vNotes", "NoteID", noteId);		
		portId = Integer.parseInt(parameterMap.get("PortfolioID").toString());
		javaClassName = parameterMap.get("JavaClassName").toString();
		portCode = parameterMap.get("PortfolioCode").toString();
	}
	
	public abstract String getNote(Security security, Map<String, Object> tradeTicketData);
}
