package com.sky.tt.handler;


import java.io.IOException;
import java.util.List;

import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.filter.OrderByClause;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.util.ErrorHandlingUtility;

public class GetSavedTrades extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2836804067418874314L;
	private static final Logger log = Logger.getLogger(GetSavedTrades.class);


	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		
		GenericFilter filter = new GenericFilter();
		filter.addOrderByClause(new OrderByClause("SaveDate","desc"));
		List<Map<String, Object>> savedTrades = null;
		
		JSONObject results = new JSONObject();
		
		try {
			savedTrades = TableQuery.getRows("CustomTradeTicket.vSavedTrades", filter);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			results.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return results;
		}
		
		for (Map<String, Object> trade : savedTrades) {
			for (String k : trade.keySet()) {
				if (k.equalsIgnoreCase("LimitComment") || k.equalsIgnoreCase("TimingComment") || k.equalsIgnoreCase("NotesComment") || k.equalsIgnoreCase("PMValuationComment") || k.equalsIgnoreCase("TraderComment")) {
					trade.put(k, StringEscapeUtils.escapeHtml4(trade.get(k).toString()).replace("'","&#39;"));
				}
			}
		}
		
		
		
		String jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(savedTrades);
		JSONArray resultArray = new JSONArray(jsonStrOutput);
		results.put("data", resultArray);
		
		return results;
	}

}
