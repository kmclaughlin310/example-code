package com.sky.tt.user;

public class UserNotLoggedInException extends Exception {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -6107693814563250372L;

	public UserNotLoggedInException() {
		super();
	}

	public UserNotLoggedInException(String message) {
		super(message);
	}

	public UserNotLoggedInException(Throwable cause) {
		super(cause);
	}

	public UserNotLoggedInException(String message, Throwable cause) {
		super(message, cause);
	}

}
