package com.sky.tt.restriction.aggregate;


import org.apache.log4j.Logger;

import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateRestriction;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregateNonUSCanadaConcentrationRestriction extends AggregateRestriction {
	
	private static final Logger log = Logger.getLogger(AggregateNonUSCanadaConcentrationRestriction.class);
	
	private static final String CHECK_SECURITY_FIELD_PARAMETER_NAME = "CheckField"; //domicile vs. issue
	
	protected SecurityField field;
	
	public AggregateNonUSCanadaConcentrationRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();	
		field = SecurityField.getSecurityField(parameterMap.get(CHECK_SECURITY_FIELD_PARAMETER_NAME).toString()); //needs to exactly match field name in SecurityField enum
	}

	public Object restrictionApplies(Security security, Portfolio portfolio) {
		
		String country = null;		
		country = security.getValue(field).toString();
		
		if (country.equalsIgnoreCase("us") || country.equalsIgnoreCase("ca")) {
			return false;
		} else {
			return true;
		}
		
		
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {	
			//restrictionApplies will return country if it's not US or CA
			if (action.equalsIgnoreCase("sell") || (Boolean) restrictionApplies(security, portfolio) == false) {
				return 0;
			}
			
			double restrictedPortionPortMktVal;
			double totalPortMktVal;
			
			GenericFilter filter = new GenericFilter();
			filter.addFilterClause(new FilterClause(mktValueSQLFunctionName, FilterClause.FieldComparator.NE, "us"));
			filter.addFilterClause(new FilterClause(mktValueSQLFunctionName, FilterClause.FieldComparator.NE, "ca"));
	
			//assuming buy since it's a max percent restriction i.e. wouldn't need to check restriction if it's a sell
			restrictedPortionPortMktVal = PortfolioMarketValue.getRestrictedPortionMktVal(portfolio, filter, true);
			restrictedPortionPortMktVal = restrictedPortionPortMktVal + ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()); 
			
			//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy
			totalPortMktVal = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
			
			//returns % of limit of the restricted portion
			return (restrictedPortionPortMktVal / totalPortMktVal * 100) / restrictionLimit * 100 ;	
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
		

	}

}
