package com.sky.tt.db.filter;

import java.util.ArrayList;
import java.util.List;

public class OrderByClause {
	private List<String> fieldNames;
	private List<Direction> directions;
	
	public enum Direction {
		
		ASC("asc"),
		DESC("desc");
		
		private String sql;
		
		private Direction(String sql) {
			this.sql = sql;
		}
		
		public String toString() {
			return sql;
		}
		
		public static Direction getDirection(String sql) {
			for (Direction dir : Direction.values()) {
				if (dir.toString().equalsIgnoreCase(sql)) {
					return dir;
				}
			}
			
			return Direction.ASC;
		}
		
		
	}

	public OrderByClause(String fieldName, String direction) {
		fieldNames = new ArrayList<String>();
		directions = new ArrayList<Direction>();
		fieldNames.add(fieldName);
		directions.add(Direction.getDirection(direction));
	}
	
	public OrderByClause(String fieldName, Direction direction) {
		fieldNames = new ArrayList<String>();
		directions = new ArrayList<Direction>();
		fieldNames.add(fieldName);
		directions.add(direction);
	}
	
	public OrderByClause(List<String> fieldNames, List<Direction> directions) {
		this.fieldNames = fieldNames;
		this.directions = directions;
	}
	
	public void addClause(String fieldName, String direction) {
		fieldNames.add(fieldName);
		directions.add(Direction.getDirection(direction));
	}
	
	public void addClause(String fieldName, Direction direction) {
		fieldNames.add(fieldName);
		directions.add(direction);
	}
		
	public String getClauseSQL() {
		StringBuilder sql = new StringBuilder(" ORDER BY ");
		String separator = " ";
		for (int i = 0; i < fieldNames.size() && i < directions.size(); i++) {
			sql.append(separator + fieldNames.get(i) + " " + directions.get(i).toString() + " ");
			separator = ", ";
		}
		return sql.toString();
	}
	
	public String getFieldName() {
		StringBuilder fieldName = new StringBuilder();
		String separator = "";
		for (String fields : fieldNames) {
			fieldName.append(separator).append(fields);
			separator = ", ";
		}
		return fieldName.toString();
		
	}
}
