package com.sky.tt.restriction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.Security;

public abstract class AggregatePortRestriction {
	private static final Logger log = Logger.getLogger(AggregatePortRestriction.class);
	
	protected int restrictionId;
	
	protected Map<String, Object> restrictionMap = new HashMap<String, Object>();
	
	protected int portfolioId;
	protected Inequality inequal;
	protected double restrictionLimit;
	protected boolean exCash = false;
	protected List<Map<String, Object>> parameterMapList;
	protected Map<String, Object> parameterMap;
	
	private String PORTFOLIO_COLUMN = "PortfolioID";
	private String INEQUALITY_COLUMN = "RestrictionInequality";
	private String LIMIT_COLUMN = "RestrictionLimit";
	private String EX_CASH_COLUMN = "ExCash";
	
	public abstract double restrictionApplies(Security security, String action, boolean exCash); //return 0 if it does not apply, else returns value of field; i.e. if looking at avg maturity restriction of < 4, will return maturity if > 4
	public abstract double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice); //returns % of the limit reached
	 
	public AggregatePortRestriction(int restrictionId) {
		this.restrictionId = restrictionId;
		this.parameterMap = new HashMap<String, Object>();
	}
	
	public void init() throws Exception {
		
		try {
			restrictionMap = TableQuery.getRowByID("CustomTradeTktRestriction.AggregatePortRestrictionList", "AggregateRestrictionID", restrictionId);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.debug(e);
		}
		
		portfolioId = Integer.parseInt(restrictionMap.get(PORTFOLIO_COLUMN).toString());
		inequal = Inequality.getInequality(restrictionMap.get(INEQUALITY_COLUMN).toString());
		restrictionLimit = Double.parseDouble(restrictionMap.get(LIMIT_COLUMN).toString());
		exCash = Boolean.parseBoolean(restrictionMap.get(EX_CASH_COLUMN).toString());
		
		//load parameter map from parameter table
		GenericFilter filter = new GenericFilter();
		filter.addFilterClause(new FilterClause("AggregateRestrictionID", FilterClause.FieldComparator.EQ, restrictionId));
		try {
			parameterMapList = TableQuery.getRows("CustomTradeTktRestriction.AggregatePortRestrictionParams", filter);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.debug(e);
		}
		
		for(Map<String, Object> map : parameterMapList) {
			parameterMap.put(map.get("ParameterName").toString(), map.get("ParameterValue"));
		}
		
		
	}
	
	public int getPortfolioID() {
		return portfolioId;
	}

	public int getRestrictionID() {
		return restrictionId;
	}
	
	public double getRestrictionLimit() {
		return restrictionLimit;
	}

}
