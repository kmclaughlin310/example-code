package com.sky.tt.restriction;

public class RestrictionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8007991204930930029L;

	public RestrictionException() {}

	public RestrictionException(String message) {
		super(message);
	}

	public RestrictionException(Throwable cause) {
		super(cause);
	}

	public RestrictionException(String message, Throwable cause) {
		super(message, cause);
	}
}
