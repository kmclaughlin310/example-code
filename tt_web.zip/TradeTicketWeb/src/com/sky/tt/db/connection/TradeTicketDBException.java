package com.sky.tt.db.connection;

public class TradeTicketDBException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8007991204930930029L;

	public TradeTicketDBException() {}

	public TradeTicketDBException(String message) {
		super(message);
	}

	public TradeTicketDBException(Throwable cause) {
		super(cause);
	}

	public TradeTicketDBException(String message, Throwable cause) {
		super(message, cause);
	}
}
