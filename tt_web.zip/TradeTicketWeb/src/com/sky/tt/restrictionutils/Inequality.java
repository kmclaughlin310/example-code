package com.sky.tt.restrictionutils;

public enum Inequality {
		
		EQ("="), //0
		LT("<"), //1
		GT(">"), //2
		LTE("<="), //3
		GTE(">="), //4
		NE("!=");  //5
		
		private String symbol;
		
		private Inequality(String symbol) {
			this.symbol = symbol;
		}
		
		public String getSymbol() {
			return symbol;
		}
		
		public static Inequality get(int index) {
			return Inequality.values()[index];
		}
		
		public static Inequality getInequality(String symbol) {
			for(Inequality inequality : Inequality.values()) {
				if (inequality.getSymbol().equals(symbol)) {
					return inequality;
				}
			}
			
			return null; //is this right?
		}
		
		public static String getSQL(Inequality inequality) {
			switch(inequality){
			case NE:
				return "<>";
			default:
				return inequality.getSymbol();
			}
			
					
		}
		
}
