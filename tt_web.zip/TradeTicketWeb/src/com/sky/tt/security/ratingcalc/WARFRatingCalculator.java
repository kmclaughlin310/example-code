package com.sky.tt.security.ratingcalc;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton.RatingType;
import com.sky.util.ArraySort;

public class WARFRatingCalculator implements SecurityRatingCalculator {

	private static final Logger log = Logger.getLogger(WARFRatingCalculator.class);
	
	public double getSecurityRating(Security security, boolean includeEPURatings, boolean includeFitchRatings) throws TradeTicketDBException {
		//includeFitchRatings is not used
		
		RatingConverterSingleton converter = RatingConverterSingleton.getInstance();
		
		double WARFRating = 0;
		double spRating = 0;
		double mdyRating = 0;
		double fitchRating = 0;
		
		spRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH_WARF, SecurityField.RAW_SP, includeEPURatings);
		mdyRating = converter.getNumericSecurityRating(security, RatingType.MOODY_WARF, SecurityField.RAW_MOODY, includeEPURatings);
		fitchRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH_WARF, SecurityField.RAW_FITCH, includeEPURatings);
		
		double[] ratingArray = {spRating, mdyRating, fitchRating}; //Java array index starts at 0
		
		ratingArray = ArraySort.InsertionSort(ratingArray);
		
		if (ratingArray[0] < 0) {
			if (ratingArray[2] < 0) {
				WARFRating = 10000;
			} else {
				WARFRating = ratingArray[2];
			}
		} else {
			WARFRating = ratingArray[1];
		}
		
		return WARFRating;
	}

	
	@Override
	public String getSecurityRatingText(Security security) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getSecurityRatingText(double value) {
		try {
			RatingConverterSingleton ratingConverter = RatingConverterSingleton.getInstance();
			return ratingConverter.getWARFRatingText(value);
		} catch (TradeTicketDBException e) {
			log.error(e);
			return null;
		}
	}
	
}
