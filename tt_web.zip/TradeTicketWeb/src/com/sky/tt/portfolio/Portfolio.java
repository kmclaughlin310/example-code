package com.sky.tt.portfolio;

public class Portfolio {
	
	protected int portfolioID;
	protected String portfolioCode = null;
	
	public Portfolio(int portfolioID) {
		this.portfolioID = portfolioID;
	}
	
	public Portfolio(int portfolioID, String portfolioCode) {
		this.portfolioID = portfolioID;
		this.portfolioCode = portfolioCode;
	}
	
	public int getPortfolioID() {
		return portfolioID;
	}
	
	public String getPortfolioCode() {
		return portfolioCode;
	}


}
