package com.sky.tt.db.connection;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class TradeTicketMoxyDBConnection {
	private static final Logger log = Logger.getLogger(TradeTicketDBConnection.class);
	
	private DataSource dataSource;
	//private static TradeTicketMoxyDBConnection singleton;

	private static class SingletonHolder {
		private static final TradeTicketMoxyDBConnection INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new TradeTicketMoxyDBConnection();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	
	private TradeTicketMoxyDBConnection() throws TradeTicketDBException {

		log.debug("Initiating connection to TradeTicket Moxy Database test");
		
		try {
			// Get DataSource
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/tradeticketmoxy"); 

		} catch (NamingException e) {
			log.error(e);
			throw new TradeTicketDBException("Error getting context/data source: " + e.getMessage(), e);
		}
		
		log.debug("Connection established to TradeTicket Moxy Database.");
		
	}

	public static Connection getConnection() throws TradeTicketDBException {

		try {
			return SingletonHolder.INSTANCE.dataSource.getConnection(); //use when running web application
			
			//return DriverManager.getConnection("jdbc:sqlserver://skyapxdb;integratedSecurity=true;database=APXFirm;");
		} catch (SQLException sqle) {
			log.error(sqle);
			throw new TradeTicketDBException("Error getting Moxy connection: " + sqle.getMessage(), sqle);
		}
	}

}
