package com.sky.tt.restrictionutils;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.portfolio.Portfolio;

public class PortfolioMarketValue {
	
	private static final Logger log = Logger.getLogger(PortfolioMarketValue.class);
	
	public static double getRestrictedPortionMktVal(Portfolio portfolio, String mktValueSQLFunctionName, Inequality checkInequality, Object checkValue, boolean excludeCashSecurity) {
		GenericFilter filter = new GenericFilter();
		
		//numerator: market value of restricted portion of market value
		filter.addFilterClause(new FilterClause(mktValueSQLFunctionName, FilterClause.FieldComparator.getFieldComparator(Inequality.getSQL(checkInequality)), checkValue)); //mktValueSQLFunctionName will be something like CustomTradeTktRestriction.fNAICRating, checkValue will be 17 for triple C
		filter.addFilterClause(new FilterClause("PortfolioID", FilterClause.FieldComparator.EQ, portfolio.getPortfolioID()));
		
		if (excludeCashSecurity == true) {
			filter.addFilterClause(new FilterClause("SecurityID", FilterClause.FieldComparator.NE, 6));
		}

		try {
			return TableQuery.getSingleSum("CustomTradeTicket.CurrentHoldings", "MarketVal + AccrInt", filter);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return -1;
		}

	}
	
	public static double getRestrictedPortionMktVal(Portfolio portfolio, GenericFilter filter, boolean excludeCashSecurity) {
		//GenericFilter filter = new GenericFilter();
		
		filter.addFilterClause(new FilterClause("PortfolioID", FilterClause.FieldComparator.EQ, portfolio.getPortfolioID()));
		
		if (excludeCashSecurity == true) {
			filter.addFilterClause(new FilterClause("SecurityID", FilterClause.FieldComparator.NE, 6));
		}

		try {
			return TableQuery.getSingleSum("CustomTradeTicket.CurrentHoldings", "MarketVal + AccrInt", filter);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return -1;
		}
		
		
	}
	
	public static double getTotalMarketValue(Portfolio portfolio, boolean exCash) {
		MarketValueSingleton mktValCalc = null;
		try {
			mktValCalc = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return -1;
		}
		
		//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy
		return mktValCalc.getMarketValue(portfolio.getPortfolioID(), exCash);
	}
	
}
