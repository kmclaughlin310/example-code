package com.sky.tt.db.filter;

public class FilterException extends Exception {
	
	
	private static final long serialVersionUID = 4345505413372796802L;


	public FilterException() {
		// TODO Auto-generated constructor stub
	}

	public FilterException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FilterException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public FilterException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}




