package com.sky.tt.security;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;

public class MLIndustryLookupSingleton {
	private static final Logger log = Logger.getLogger(MLIndustryLookupSingleton.class);
	
	private static Map<String, String> industryGroupLookup;
	private static Map<String, String> industrySectorLookup;
	private static Map<String, String> industryGroupCodeLookup;
	private static Map<String, String> industrySectorCodeLookup;
	private static Map<String, String> barclaysIndustryLookup; //uses 8 character symbol as opposed to full 9-digit cusip
	
	private static final long REFRESH_INTERVAL = 1440;
	private Date timeAtRefresh = null;
	
	private static final int MAP_SIZE = (int) (2500 * 1.2);
	
	private static class SingletonHolder {
		private static final MLIndustryLookupSingleton INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new MLIndustryLookupSingleton();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	private MLIndustryLookupSingleton() throws TradeTicketDBException {
		createIndustryLookups();
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	private void createIndustryLookups() throws TradeTicketDBException {
		List<Map<String, Object>> mlIndustryMapList = null; 
		List<Map<String, Object>> barclaysIndustryMapList = null;
		
		industryGroupLookup = new HashMap<String, String>(MAP_SIZE);
		industrySectorLookup = new HashMap<String, String>(MAP_SIZE);
		industryGroupCodeLookup = new HashMap<String, String>(MAP_SIZE);
		industrySectorCodeLookup = new HashMap<String, String>(MAP_SIZE);
		barclaysIndustryLookup = new HashMap<String, String>(MAP_SIZE);
		
		try {
			mlIndustryMapList = TableQuery.getRows("CustomTradeTicket.vH0A0IndustryLookup");
		} catch (TradeTicketDBException e) {
			log.error("Error getting H0A0 Industry Lookup", e);
			throw e;
		}
		
		for (Map<String, Object> row : mlIndustryMapList) {
			String cusip = row.get("CUSIP").toString();
			industryGroupLookup.put(cusip, row.get("Level3Ind").toString());
			industrySectorLookup.put(cusip, row.get("Level4Ind").toString());
			industryGroupCodeLookup.put(cusip, row.get("IndustryCode").toString());
			industrySectorCodeLookup.put(cusip, row.get("SectorCode").toString());
		}	
		
		try {
			barclaysIndustryMapList = TableQuery.getRows("CustomTradeTktRestriction.BarclaysIndCrossRef");
		} catch (TradeTicketDBException e) {
			log.error("Error getting Barclay's Industry Lookup", e);
			throw e;
		}
		
		for (Map<String, Object> row : barclaysIndustryMapList) {
			barclaysIndustryLookup.put(row.get("Symbol").toString(), row.get("BarclaysClass4Industry").toString());			
		}
		
	}
	
	public String getIndustryGroup(String cusip) {
		checkStaleness();
		return industryGroupLookup.containsKey(cusip) ? industryGroupLookup.get(cusip) : null;
	}
	
	public String getIndustrySector(String cusip) {
		checkStaleness();
		return industrySectorLookup.containsKey(cusip) ? industrySectorLookup.get(cusip) : null;
	}
	
	public String getBarclaysIndustry(String cusip) {
		checkStaleness();
		if (cusip.length() < 8) {
			return null;
		}
		String cusipLookup = cusip.substring(0, 8);
		return barclaysIndustryLookup.containsKey(cusipLookup) ? barclaysIndustryLookup.get(cusipLookup) : null;
	}
	
	public String getIndustryGroupCode(String cusip) {
		checkStaleness();
		return industryGroupCodeLookup.containsKey(cusip) ? industryGroupCodeLookup.get(cusip) : null;
	}
	
	public String getIndustrySectorCode(String cusip) {
		checkStaleness();
		return industrySectorCodeLookup.containsKey(cusip) ? industrySectorCodeLookup.get(cusip) : null;
	}
	
	public boolean inMaster2Index(String cusip) {
		checkStaleness();
		return industrySectorLookup.containsKey(cusip);
	}

	public static MLIndustryLookupSingleton getInstance() throws TradeTicketDBException { 
		return SingletonHolder.INSTANCE;
	}
	
	public void checkStaleness() {
		if (timeAtRefresh != null) {
			Date now = Calendar.getInstance().getTime();
			long diff = (now.getTime() - timeAtRefresh.getTime()) / (60 * 1000);
			if (diff >= REFRESH_INTERVAL) {
				SingletonHolder.INSTANCE.forceRefresh();
			}
		}
	}

	private void forceRefresh() {
		log.debug("ML industry lookup singleton refreshed.");
		
		try {
			createIndustryLookups();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
		}

		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	public static void forceSingletonRefresh() {
		SingletonHolder.INSTANCE.forceRefresh();
	}
}
