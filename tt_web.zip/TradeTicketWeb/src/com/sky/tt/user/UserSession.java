package com.sky.tt.user;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.UserQuery;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;



/*import com.sky.skyaudit.db.query.UserQuery;*/

public class UserSession {

	public static final String USER_SESSION_ATTRIBUTE = "SKYTradeTicketUserSession";
	private static final Logger log = Logger.getLogger(UserSession.class);

	private User user;
	
	public UserSession(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return user;
	}
	
	
	private static UserSession getUserSessionByUserName(String userName) throws TradeTicketDBException {
		User user = UserQuery.getUser(userName);
		return (user == null) ? null : new UserSession(user);
	}
		
	public static UserSession getUserSessionFromRequest(HttpServletRequest req) throws UserNotFoundException, UserNotLoggedInException, UserSessionException {
		UserSession userSession = (UserSession) req.getSession().getAttribute(USER_SESSION_ATTRIBUTE);
		if (userSession != null) {
			return userSession;
		}
		
		String userName = null;
		try {
			 userName = req.getUserPrincipal().getName();
		} catch (Exception e) {
			log.error(e);
			throw new UserSessionException("Unable to get UserName from session: " + e.getMessage(), e);
		}
		if (userName != null && !userName.equals("")) {
			try {
				userSession = getUserSessionByUserName(userName);
			} catch (TradeTicketDBException e) {
				log.error(e);
				throw new UserSessionException("Error retrieving User: " + e.getMessage(), e);
			}
		} else {
			throw new UserNotLoggedInException("No user currently logged in.");
		}
		
		if (userSession == null) {
			throw new UserNotFoundException("Username '" + userName + "' is not found in the database.");
		}
		
		req.getSession().setAttribute(USER_SESSION_ATTRIBUTE, userSession);
		
		return userSession;
	}
}
