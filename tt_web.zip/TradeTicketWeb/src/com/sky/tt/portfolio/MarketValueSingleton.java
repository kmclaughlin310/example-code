package com.sky.tt.portfolio;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.filter.OrderByClause;
import com.sky.tt.db.query.TableQuery;

public class MarketValueSingleton {
	
	private static final Logger log = Logger.getLogger(MarketValueSingleton.class);
	private static final long REFRESH_INTERVAL = 15;
		
	private Map<Integer, Double> marketValues;  //maps a portfolio id (integer) to market value
	private Map<Integer, Double> marketValuesExCash;
	private Map<Integer, Map<String, Object>> allPortfolioDetails; //returns a list of all portfolios each with map including current mv, current cash, pre-allocated cash, ticker, account name
	private Map<Integer, Map<String, SecurityHolding>> allPortfolioSecHoldings; //returns a list of all portfolios' security holdings
	private Map<Integer, Map<String, TickerHolding>> allPortfolioIssuerHoldings; //returns a list of all portfolio each with a map of ticker to aggregate holdings
	private Map<Integer, Map<String, Object>> allHoldingsUnitCosts;
	private Map<Integer, List<Integer>> portfolioGroups;
	private List<String> allStrategies;
	private Map<Integer, String> portfolios; //maps portfolio ID to portfolio Code
	private double EURExRate;
	
	private Date timeAtRefresh = null;
	
	private static class SingletonHolder {
		private static final MarketValueSingleton INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new MarketValueSingleton();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	private MarketValueSingleton() throws TradeTicketDBException {
		createMarketValueMaps(); //populates marketValues and marketValuesExCash
		createHoldingsMaps(); //populates allPortSecHoldings, allPortfolioIssuerHoldings, allHoldingsUnitCosts
		createPortDetailsMap();
		createStrategyList();
		createPortfolioGroups();
		createPortfolios();
		setEURExRate();
		
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	private void forceRefresh() throws TradeTicketDBException {
		log.debug("Market value singleton refreshed.");
		
		createMarketValueMaps(); //populates marketValues and marketValuesExCash
		createHoldingsMaps(); //populates allPortSecHoldings, allPortfolioIssuerHoldings, allHoldingsUnitCosts
		createPortDetailsMap();
		createStrategyList();
		createPortfolioGroups();
		createPortfolios();
		setEURExRate();
		
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	public Map<Integer, Double> getMarketValues() {
		checkStaleness();
		return marketValues;
	}
	
	public double getEURExRate() {
		checkStaleness();
		return EURExRate;
	}
	
	public Map<Integer, Double> getMarketValuesExCash() {
		checkStaleness();
		return marketValuesExCash;
	}
	
	public Map<Integer, Map<String, Object>> getAllPortfolioDetails() {
		checkStaleness();
		return allPortfolioDetails;
	}
	
	public Map<Integer, List<Integer>> getPortfolioGroups() {
		checkStaleness();
		return portfolioGroups;
	}
	
	public List<Integer> getPortfolioGroupMembers(int portfolioGroupID) {
		checkStaleness();
		return portfolioGroups.get(portfolioGroupID);
	}
	
	
	public Map<Integer, Map<String, Object>> getStrategyPortfolioDetails(String strategy) { 
		checkStaleness();
		Map<Integer, Map<String, Object>> results = new HashMap<Integer, Map<String, Object>>();
		
		for (Integer portID : allPortfolioDetails.keySet()) {
			if (allPortfolioDetails.get(portID).get("Strategy").toString().equalsIgnoreCase(strategy)) {
				results.put(portID, allPortfolioDetails.get(portID));
			}
		}
		
		return results;
	}
	
	public Map<String, Object> getSinglePortfolioDetails(String portCode) { 
		checkStaleness();
		Map<String, Object> results = new HashMap<String, Object>();
		
		for (Integer portID : allPortfolioDetails.keySet()) {
			if (allPortfolioDetails.get(portID).get("PortfolioCode").toString().equalsIgnoreCase(portCode)) {
				results = allPortfolioDetails.get(portID);
			}
		}
		
		return results;
	}
	
	public double getSpecificSecurityHoldingsQuant(int portId, String cusip) {
		checkStaleness();
		if (allPortfolioSecHoldings.get(portId).containsKey(cusip)) {
			return allPortfolioSecHoldings.get(portId).get(cusip).getQuantity(); 
		} else {
			return 0;
		}
	}
	
	public double getSecurityUnitCost(int portId, String cusip) {
		checkStaleness();
		if (allHoldingsUnitCosts.get(portId).containsKey(cusip)) {
			return Double.parseDouble(allHoldingsUnitCosts.get(portId).get(cusip).toString()); 
		} else {
			return 0;
		}
	}
	
	public double getSpecificIssuerHoldingsMktVal(int portId, String ticker) {
		checkStaleness();
		if (allPortfolioIssuerHoldings.get(portId).containsKey(ticker)) {
			return allPortfolioIssuerHoldings.get(portId).get(ticker).getMarketValue();
		} else {
			return 0;
		}
	}
	
	public double getSpecificIssuerHoldingsQuantity(int portId, String ticker) {
		checkStaleness();
		if (allPortfolioIssuerHoldings.get(portId).containsKey(ticker)) {
			return allPortfolioIssuerHoldings.get(portId).get(ticker).getQuantity();
		} else {
			return 0;
		}
	}
	
	public Map<Integer, Map<String, SecurityHolding>> getAllPortfolioSecHoldings() {
		checkStaleness();
		return allPortfolioSecHoldings;
	}
	
	
	public Map<Integer, Map<String, TickerHolding>> getAllPortfolioIssuerHoldings() {
		checkStaleness();
		return allPortfolioIssuerHoldings;
	}
	
	public List<String> getStrategies() {
		checkStaleness();
		return allStrategies;
	}
	
	public static void forceMarketValueSingletonRefresh() throws TradeTicketDBException {
		SingletonHolder.INSTANCE.forceRefresh();
	}
	
	public static MarketValueSingleton getInstance() throws TradeTicketDBException { //*check if static field is null, if so create an instance, otherwise return what is already there
		
		return SingletonHolder.INSTANCE;	
		
	}
	
	public void checkStaleness() {
		if (timeAtRefresh != null) {
			Date now = Calendar.getInstance().getTime();
			long diff = (now.getTime() - timeAtRefresh.getTime()) / (60 * 1000);
			if (diff >= REFRESH_INTERVAL) {
				try {
					SingletonHolder.INSTANCE.forceRefresh();
				} catch (TradeTicketDBException e) {
					log.error(e);
					e.printStackTrace();
				}
			}
		}
	}
	
	private void createMarketValueMaps() throws TradeTicketDBException {
		//List<Map<String, Object>> ratingsTable = TableQuery.getRows("CustomTradeTktRestriction.RatingCrossRef");
		List<Map<String, Object>> marketValTable = TableQuery.getRows("CustomTradeTicket.vCurrentMarketValue");
		Map<Integer, Double> mktValues = new HashMap<Integer, Double>();
		Map<Integer, Double> mktValuesExCash = new HashMap<Integer, Double>();
		
		for(Map<String, Object> mktVal : marketValTable) {
			if (mktVal.get("MarketValueAI") != null) {
				mktValues.put(Integer.parseInt(mktVal.get("PortfolioID").toString()), Double.parseDouble(mktVal.get("MarketValueAI").toString()));
			}
			if (mktVal.get("MarketValueAIExCash") != null) {
				mktValuesExCash.put(Integer.parseInt(mktVal.get("PortfolioID").toString()), Double.parseDouble(mktVal.get("MarketValueAIExCash").toString()));
			}
		}
		
		marketValues = mktValues;
		marketValuesExCash = mktValuesExCash;
		
	}
	
	public double getMarketValue(int portfolioID, boolean exCash) {
		checkStaleness();
		if (exCash) {
			return marketValuesExCash.get(portfolioID);
		}
		else {
			return marketValues.get(portfolioID);
		}
	}

	private void createHoldingsMaps() throws TradeTicketDBException {
		
		List<Map<String, Object>> holdingsTable =  new ArrayList<Map<String, Object>>();
		Map<String, Object> secHoldingData = new HashMap<String, Object>(); //data to pass to SecurityHolding
		Map<String, Object> tickerHoldingData = new HashMap<String, Object>(); //data to pass to TickerHolding
		SecurityHolding secHolding = null;
		TickerHolding tickerHolding = null;
		Map<String, SecurityHolding> secMap = new HashMap<String, SecurityHolding>(); //map cusip to Holding
		Map<String, TickerHolding> tickerMap = new HashMap<String, TickerHolding>();
		Map<String, Object> originalCostMap = new HashMap<String, Object>();
		int currentPortID = 0;
		int newPortID = 0;
		String ticker = null;
		
		allPortfolioSecHoldings = new HashMap<Integer, Map<String, SecurityHolding>>();
		allPortfolioIssuerHoldings = new HashMap<Integer, Map<String, TickerHolding>>();
		allHoldingsUnitCosts = new HashMap<Integer, Map<String, Object>>();
		
		//order by portfolioID to add all securities at once to a portfolio; by ticker for allPortfolioIssuerHoldings
		GenericFilter filter = new GenericFilter();
		filter.addOrderByClause(new OrderByClause("PortfolioID,Ticker","asc"));
		
		holdingsTable = TableQuery.getRows("CustomTradeTicket.CurrentHoldings", filter);

		for (Map<String, Object> row : holdingsTable) {
			
			newPortID = Integer.parseInt(row.get("PortfolioID").toString());
			ticker = row.get("Ticker").toString();
			
			//create holding				
			secHoldingData.clear();			
			secHoldingData.put("cusip", row.get("Symbol").toString());
			secHoldingData.put("ticker", ticker);
			secHoldingData.put("quantity", Double.parseDouble(row.get("Quantity").toString()));
			secHoldingData.put("marketValue", Double.parseDouble(row.get("MarketVal").toString()) + Double.parseDouble(row.get("AccrInt").toString()));
			secHolding = new SecurityHolding(secHoldingData);
			
			
			//if it's a new portfolio and not the first, add current portfolio id and secMap to list of all portfolio holdings; add current ticker map; clear secmap, tickermap; update current portfolio id 
			if (newPortID != currentPortID && currentPortID != 0) {
				allPortfolioSecHoldings.put(currentPortID, secMap);
				allPortfolioIssuerHoldings.put(currentPortID, tickerMap);
				allHoldingsUnitCosts.put(currentPortID, originalCostMap);
				secMap = new HashMap<String, SecurityHolding>();
				tickerMap = new HashMap<String, TickerHolding>();
				originalCostMap = new HashMap<String, Object>();
				currentPortID = newPortID;
			} else if (currentPortID == 0 ) {
				currentPortID = newPortID;
			}
			
			//update ticker value or add ticker to map
			//public TickerHolding updateTickerHolding(TickerHolding oldHolding, double quantity, double mktVal) {
			if (ticker != null && ! ticker.equals("")) {
				if (tickerMap.containsKey(ticker)) { //update existing entry
					tickerHolding = tickerHolding.updateTickerHolding(tickerHolding, Double.parseDouble(row.get("Quantity").toString()), Double.parseDouble(row.get("MarketVal").toString()) + Double.parseDouble(row.get("AccrInt").toString()));
					tickerMap.put(ticker, tickerHolding);
				} else { //create new entry
					tickerHoldingData.clear();
					tickerHoldingData.put("ticker", ticker);
					tickerHoldingData.put("quantity", Double.parseDouble(row.get("Quantity").toString()));
					tickerHoldingData.put("marketValue", Double.parseDouble(row.get("MarketVal").toString()) + Double.parseDouble(row.get("AccrInt").toString()));
					tickerHolding = new TickerHolding(tickerHoldingData);

					tickerMap.put(ticker, tickerHolding);
				}
			}
			
			secMap.put(secHolding.getCusip(), secHolding);	
			originalCostMap.put(secHolding.getCusip(), Double.parseDouble(row.get("UnitCost").toString()));
		}
		
		allPortfolioSecHoldings.put(currentPortID, secMap);
		allPortfolioIssuerHoldings.put(currentPortID, tickerMap);
		allHoldingsUnitCosts.put(currentPortID, originalCostMap);
	}
	
	private void createPortDetailsMap() throws TradeTicketDBException {
		allPortfolioDetails = new LinkedHashMap<Integer, Map<String, Object>>();
		
		List<Map<String, Object>> detailsTable = new ArrayList<Map<String, Object>>();
		GenericFilter filter = new GenericFilter(); //for order by
		
		OrderByClause orderBy = new OrderByClause("SortOrder", OrderByClause.Direction.ASC);
		orderBy.addClause("PortfolioCode", OrderByClause.Direction.ASC);
		filter.addOrderByClause(orderBy);

		detailsTable = TableQuery.getRows("CustomTradeTicket.vCurrentPortfolioDetails", filter);
		
		for (Map<String, Object> port : detailsTable) {
			allPortfolioDetails.put(Integer.parseInt(port.get("PortfolioID").toString()), port);
		}	
	}
	
	public String toString() {
		
		StringBuffer buffer = new StringBuffer();
		
		Map<String, Object> portDetails = new HashMap<String, Object>();
		for (Integer portID : allPortfolioDetails.keySet()) {
			buffer.append("PORTFOLIO ID: " + portID + "\n");
			portDetails = allPortfolioDetails.get(portID);
			buffer.append(portDetails.get("PortfolioCode") + ", " + portDetails.get("ShortName") + ", " + portDetails.get("Strategy") + ", " + portDetails.get("MarketValueAI") + ", " + portDetails.get("CashPct") + ", " + portDetails.get("PreAllocatedCash"));
		}
		return buffer.toString();
	}
	
	private void createStrategyList() {
		
		List<String> strategyList = new ArrayList<String>();
		List<Map<String, Object>> dbStrategyList = null;
		
		try {
			dbStrategyList = TableQuery.getRows("CustomTradeTicket.Strategies");
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.debug(e);
		}
		
		for (Map<String, Object> strat : dbStrategyList) {
			strategyList.add(strat.get("StrategyShortCode").toString());
		}
		
		allStrategies = strategyList;
	}
	
	private void createPortfolios() {
		portfolios = new HashMap<Integer, String>();
		List<Map<String, Object>> dbPortfolios = null;
		
		try {
			dbPortfolios = TableQuery.getRows("CustomTradeTktRestriction.vActivePortfolios");
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.debug(e);
		}
		
		for (Map<String, Object> port : dbPortfolios) {
			portfolios.put(Integer.parseInt(port.get("PortfolioID").toString()), port.get("PortfolioCode").toString());
		}
	}
	
	private void setEURExRate() throws TradeTicketDBException {
		//fx rate is USD/EUR
		//first get prev bus day
		Date today = new Date();
		DateFormat sqlDt = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		String todayStr = sqlDt.format(today).toString();
		String prevBusDay;

		prevBusDay = TableQuery.getScalarFunctionResult("CustomTradeTicket.fGetPrevFXDate('" + todayStr + "')").toString();

		GenericFilter filter = new GenericFilter();		
		filter.addFilterClause(new FilterClause("FromCurrencyCode", FilterClause.FieldComparator.EQ, "eu"));
		filter.addFilterClause(new FilterClause("ToCurrencyCode", FilterClause.FieldComparator.EQ, "us"));
		filter.addFilterClause(new FilterClause("AsOfDate", FilterClause.FieldComparator.EQ, prevBusDay));

		EURExRate = 1.0 / Double.parseDouble(TableQuery.getRows("AdvApp.vFXRate", filter).get(0).get("SpotRate").toString());
	}
	
	public String getPortCode(int portID) {
		return portfolios.get(portID);
	}
	
	public int getPortID(String portCode) {
		for (int id : portfolios.keySet()) {
			if (portfolios.get(id).equalsIgnoreCase(portCode)) {
				return id;
			}
		}
		return 0;
	}
	
	private void createPortfolioGroups() {
		portfolioGroups = new HashMap<Integer, List<Integer>>();
		
		List<Map<String, Object>> dbPortGroups = null;
		List<Map<String, Object>> dbPortGroupMembers = null;
		GenericFilter filter = new GenericFilter();
		List<Integer> portIDs = new ArrayList<Integer>();
		
		try {
			dbPortGroups = TableQuery.getRows("CustomTradeTktRestriction.PortfolioGroups");
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.debug(e);
		}

		for (Map<String, Object> group : dbPortGroups) {
			filter = new GenericFilter();
			filter.addFilterClause(new FilterClause("PortfolioGroupID", FilterClause.FieldComparator.EQ, group.get("PortfolioGroupID")));
			try {
				dbPortGroupMembers = TableQuery.getRows("CustomTradeTktRestriction.PortfolioGroupMembers", filter);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.debug(e);
			}
			
			portIDs = new ArrayList<Integer>();			
			for (Map<String, Object> member : dbPortGroupMembers) {
				portIDs.add(Integer.parseInt(member.get("PortfolioID").toString()));
			}

			portfolioGroups.put(Integer.parseInt(group.get("PortfolioGroupID").toString()), portIDs);
		}
	}
	
	public boolean isRestrictionGroup(int portfolioID) { //see if portfolio id is a restriction group i.e. 603 for BBBANK
		for (Integer group : portfolioGroups.keySet()) {
			if (group == portfolioID) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean isInRestrictionGroup(int portfolioID) {
		for (Integer group : portfolioGroups.keySet()) {
			for (Integer member : portfolioGroups.get(group)) {
				if (member == portfolioID) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	public int getParentPortfolioGroup(int portfolioID) { //i.e. would return 603 for any port id passed in in BBBANK
		for (Integer group : portfolioGroups.keySet()) {
			for (Integer member : portfolioGroups.get(group)) {
				if (member == portfolioID) {
					return group;
				}
			}
		}
		
		return 0;
	}
	
}








