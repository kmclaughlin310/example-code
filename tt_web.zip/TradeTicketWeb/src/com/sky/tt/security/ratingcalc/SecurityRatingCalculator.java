package com.sky.tt.security.ratingcalc;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.security.Security;

public interface SecurityRatingCalculator {

	 public double getSecurityRating(Security security, boolean includeEPURatings, boolean includeFitchRating) throws TradeTicketDBException;
	 
	 public String getSecurityRatingText(Security security);
	 
	 public String getSecurityRatingText(double value);
	
}