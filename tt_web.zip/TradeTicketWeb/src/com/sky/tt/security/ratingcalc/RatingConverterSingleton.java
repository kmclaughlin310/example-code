package com.sky.tt.security.ratingcalc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import com.sky.tt.restrictionutils.CleanRating;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;

import org.apache.log4j.Logger;

public class RatingConverterSingleton {
	
	private static final Logger log = Logger.getLogger(RatingConverterSingleton.class);
	
	private static class SingletonHolder {
		private static final RatingConverterSingleton INSTANCE;
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new RatingConverterSingleton();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}
		
	}
	
	//private static RatingConverterSingleton ratingConverterSingleton; //**
	
	private static final int SP_FITCH_SQL_RATING_TYPE_ID = 1;
	private static final int SP_FITCH_WARF_SQL_RATING_TYPE_ID = 2;
	private static final int MOODY_SQL_RATING_TYPE_ID = 3;
	private static final int MOODY_WARF_SQL_RATING_TYPE_ID = 4;
	
	private static final int NO_OR_UNACCEPTED_RATING = -1;
	
	private static final String SP_RATING_MAP_VIEW = "CustomTradeTktRestriction.vSPRatingMap";
	private static final String MOODY_RATING_MAP_VIEW = "CustomTradeTktRestriction.vMoodyRatingMap";
	private static final String WARF_RATING_MAP_VIEW = "CustomTradeTktRestriction.vWARFRatingMap";
	
	private static Map<RatingType, Map<String, Integer>> ratingsCrossRefMaps;
	private static NavigableMap<Double, String> spRatingMap;
	private static NavigableMap<Double, String> moodyRatingMap;
	private static NavigableMap<Double, String> warfRatingMap;
	
	//** empty here, but can also call some initiation; call init method or just do initialization itself
	private RatingConverterSingleton() throws TradeTicketDBException {
		ratingsCrossRefMaps = createRatingsCrossReference();
		updateRatingsMaps();
	} 
	
	public Map<RatingType, Map<String, Integer>> getRatingsCrossReference() {
		return ratingsCrossRefMaps;
	}
	
	public static RatingConverterSingleton getInstance() throws TradeTicketDBException { //*check if static field is null, if so create an instance, otherwise return what is already there
				
		return SingletonHolder.INSTANCE;		
	}
	
	public enum RatingType {
		SP_FITCH(SP_FITCH_SQL_RATING_TYPE_ID), //1
		SP_FITCH_WARF(SP_FITCH_WARF_SQL_RATING_TYPE_ID), //2
		MOODY(MOODY_SQL_RATING_TYPE_ID), //3
		MOODY_WARF(MOODY_WARF_SQL_RATING_TYPE_ID); //4
	
		private final int sqlID;
		
		RatingType(int sqlID) {
			this.sqlID = sqlID;
		}

		
		public int getSqlID() {
			return sqlID;
		}
		
		public static RatingType getRatingType(int typeID) {
			for(RatingType type : RatingType.values()) {
				if (type.getSqlID() == typeID) {
					return type;
				}
			}
			
			return null; //is this right??
		}
		
	}
	
	private void updateRatingsMaps() throws TradeTicketDBException {
		
		spRatingMap = new TreeMap<Double, String>();
		moodyRatingMap = new TreeMap<Double, String>();
		warfRatingMap = new TreeMap<Double, String>();
		
		
		List<Map<String, Object>> spRatingData = TableQuery.getRows(SP_RATING_MAP_VIEW);
		for(Map<String, Object> rating : spRatingData) {
			spRatingMap.put(Double.parseDouble(rating.get("numericRating").toString()), rating.get("ratingText").toString());
		}
		
		List<Map<String, Object>> moodyRatingData = TableQuery.getRows(MOODY_RATING_MAP_VIEW);
		for(Map<String, Object> rating : moodyRatingData) {
			moodyRatingMap.put(Double.parseDouble(rating.get("numericRating").toString()), rating.get("ratingText").toString());
		}
		
		List<Map<String, Object>> warfRatingsData = TableQuery.getRows(WARF_RATING_MAP_VIEW);
		for(Map<String, Object> rating : warfRatingsData) {
			warfRatingMap.put(Double.parseDouble(rating.get("numericRating").toString()), rating.get("ratingText").toString());
		}
		
	}
	
	public Map<RatingType, Map<String, Integer>> createRatingsCrossReference() throws TradeTicketDBException {
		
		//list map string object
		List<Map<String, Object>> ratingsTable = TableQuery.getRows("CustomTradeTktRestriction.RatingCrossRef");
		Map<RatingType, Map<String, Integer>> ratingsCrossRef = new HashMap<RatingType, Map<String, Integer>>();
		Map<String, Integer> tempMap = new HashMap<String, Integer>(); //used for map of text rating to numeric rating
		
		for(Map<String, Object> rating : ratingsTable) {
			
			if (ratingsCrossRef.containsKey(RatingType.getRatingType(Integer.parseInt(rating.get("RatingAgencyID").toString())))) {
				//get current map for rating type
				tempMap = ratingsCrossRef.get(RatingType.getRatingType(Integer.parseInt(rating.get("RatingAgencyID").toString())));
				//add new rating to that map
				tempMap.put(rating.get("TextRating").toString(), Integer.parseInt(rating.get("NumericRating").toString()));
				//remove current map w/o the new rating
				ratingsCrossRef.remove(RatingType.getRatingType(Integer.parseInt(rating.get("RatingAgencyID").toString())));				
			} else {
				//create tempMap with new rating
				tempMap.put(rating.get("TextRating").toString(), Integer.parseInt(rating.get("NumericRating").toString()));
			}
			
			ratingsCrossRef.put(RatingType.getRatingType(Integer.parseInt(rating.get("RatingAgencyID").toString())), tempMap);
			tempMap = new HashMap<String, Integer>();
			
		}
		//System.out.println(ratingsCrossRef.toString());	
		return ratingsCrossRef;
		
	}
	
	public double getNumericSecurityRating(Security security, RatingType ratingType, SecurityField secField, Boolean includeEPURatings) {
		//ratingsCrossRefMaps
		
		String textRating = null; //security.getValue(secField).toString();
		Map<String, Integer> lookupMap;
		double numericRating = 0;
		
		if (includeEPURatings) {
			textRating = ((security.getValue(secField) == null) ? "NR" : CleanRating.getCleanRating(security.getValue(secField).toString()));
		} else { //if includeEPURatings is false, lookups will fail below when converting from EPU text rating to integer from SQL table
			textRating = ((security.getValue(secField) == null) ? "NR" : security.getValue(secField).toString());
		}

		if (ratingsCrossRefMaps.containsKey(ratingType)) {
			lookupMap = ratingsCrossRefMaps.get(ratingType);
			
			if (lookupMap.containsKey(textRating)){
				numericRating = Double.parseDouble(lookupMap.get(textRating).toString());
			} else {
				numericRating = NO_OR_UNACCEPTED_RATING;
			}
		} else {
			log.error(ratingType.toString() + " not found in ratings cross ref map.");
			return -100;
		}
		//what to do for else statement??
		//double vs int??
		
		return numericRating;
		
	}

	public String getSPRatingText(double value) {
		Map.Entry<Double, String> low = spRatingMap.floorEntry(Double.valueOf(value));
		Map.Entry<Double, String> high = spRatingMap.ceilingEntry(Double.valueOf(value));
		
		if (low == null) {
			return spRatingMap.firstEntry().getValue();
		} else if (high == null) {
			return spRatingMap.lastEntry().getValue();
		} else {
			return (value - low.getKey().doubleValue() < high.getKey().doubleValue() - value) ? low.getValue() : high.getValue();
		}
				
	}
	
	public String getMoodyRatingText(double value) {
		Map.Entry<Double, String> low = moodyRatingMap.floorEntry(Double.valueOf(value));
		Map.Entry<Double, String> high = moodyRatingMap.ceilingEntry(Double.valueOf(value));
		
		if (low == null) {
			return moodyRatingMap.firstEntry().getValue();
		} else if (high == null) {
			return moodyRatingMap.lastEntry().getValue();
		} else {
			return (value - low.getKey().doubleValue() < high.getKey().doubleValue() - value) ? low.getValue() : high.getValue();
		}
				
	}
	
	public String getWARFRatingText(double value) {
		Map.Entry<Double, String> low = warfRatingMap.floorEntry(Double.valueOf(value));
		Map.Entry<Double, String> high = warfRatingMap.ceilingEntry(Double.valueOf(value));
		
		if (low == null) {
			return warfRatingMap.firstEntry().getValue();
		} else if (high == null) {
			return warfRatingMap.lastEntry().getValue();
		} else {
			return (value - low.getKey().doubleValue() < high.getKey().doubleValue() - value) ? low.getValue() : high.getValue();
		}
				
	}
	
}
