package com.sky.tt.logic;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.portfolio.SecurityHolding;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.restriction.AggregateRestrictionChecker;
import com.sky.tt.restriction.SecurityRestrictionChecker;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class DashboardHoldings {
	
	//PortfolioID, PortfolioCode, ShortName, Strategy, MarketValueAI, CashPct, PreAllocatedCashPct - from CustomTradeTicket.vCurrentPortfolioDetails
	private static final String DETAILS_PORTID_COL_NAME = "PortfolioID";
	private static final String DETAILS_PORTCODE_COL_NAME = "PortfolioCode";
	private static final String DETAILS_PORTNAME_COL_NAME = "ShortName";
	private static final String DETAILS_STRATEGY_COL_NAME = "Strategy";
	private static final String DETAILS_MV_COL_NAME = "MarketValueAI";
	private static final String DETAILS_CASH_COL_NAME = "CashPct";
	private static final String DETAILS_PREALLOCATED_CASH_COL_NAME = "PreAllocatedCash";
	
	//strings in the keyset of tradeTicketData
	private static final String TT_ACTION = "action";  //buy or sell
	private static final String TT_PRICE = "price";
	private static final String TT_NAV_ADJUST = "NAVAdjustment";
	private static final String TT_ALLOCATION_OVERRIDE = "AllocationOverride";
	private static final String TT_PORT_CODE = "PortCode"; //for changing one allocation
	//used when doing one NAV adjustment
	private static final String TT_TARGET_ALLOCATION = "TargetAllocation"; //quantity
	private static final String TT_ALLOC_METHOD = "AllocationMethod"; 
	private static final String TT_STRATEGY = "Strategy";

	
	//strings in the map for dash that aren't covered in details
	private static final String DASH_SEC_HOLDING = "SecHoldings";
	private static final String DASH_SEC_HOLDING_PCT = "SecHoldingsPct";
	private static final String DASH_PF_SEC_HOLDING_PCT = "ProFormaSecHoldingsPct";
	private static final String DASH_ALLOC_MKT_VAL = "AllocationMktVal";
	private static final String DASH_TICKER_HOLDING_PCT = "TickerHoldingsPct";
	private static final String DASH_PF_TICKER_HOLDING_PCT = "ProFormaTickerHoldingsPct";
	private static final String DASH_ALLOC_QUANTITY = "ActualAllocation";
	private static final String DASH_SEC_RESTRICTION = "SecurityRestriction";
	private static final String DASH_PCT_TO_TARGET = "PctRelativeToTarget";
	private static final String DASH_MIN_PIECE = "MinPiece";
	private static final String DASH_NOTES = "Notes";
	
	private static final Logger log = Logger.getLogger(DashboardHoldings.class);
	
	public static Map<String, Map<String, Object>> getGenericDashHoldings() { 
		//when trade ticket initializes (no cusip) or no cusip provided...
		//map of portCode to map of stuff
			
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		Map<Integer, Map<String, Object>> portDetails = new LinkedHashMap<Integer, Map<String, Object>>();			
		portDetails = singleton.getAllPortfolioDetails();	
		
		Map<String, Object> dashHoldingsMap = new HashMap<String, Object>();
		Map<String, Map<String, Object>> dashHoldingsList = new LinkedHashMap<String, Map<String, Object>>();
		
		String portCode = null;
		String portName = null;
		String strategy = null;
		double portMktVal = 0;
		double cashPct = 0;
		double preAllocCashPct = 0;
		
		for (Integer portId : portDetails.keySet()) {
			portCode = portDetails.get(portId).get(DETAILS_PORTCODE_COL_NAME).toString();

			portName = portDetails.get(portId).get(DETAILS_PORTNAME_COL_NAME).toString();
			strategy = portDetails.get(portId).get(DETAILS_STRATEGY_COL_NAME).toString();
			portMktVal = Double.parseDouble(portDetails.get(portId).get(DETAILS_MV_COL_NAME).toString());
			cashPct = Double.parseDouble(portDetails.get(portId).get(DETAILS_CASH_COL_NAME).toString());
			preAllocCashPct = Double.parseDouble(portDetails.get(portId).get(DETAILS_PREALLOCATED_CASH_COL_NAME).toString());

			dashHoldingsMap.put(DETAILS_PORTID_COL_NAME, portId);
			dashHoldingsMap.put(DETAILS_PORTCODE_COL_NAME, portCode);
			dashHoldingsMap.put(DETAILS_PORTNAME_COL_NAME, portName);
			dashHoldingsMap.put(DETAILS_STRATEGY_COL_NAME, strategy);
			dashHoldingsMap.put(DETAILS_MV_COL_NAME, portMktVal);
			dashHoldingsMap.put(DETAILS_CASH_COL_NAME, cashPct);
			dashHoldingsMap.put(DETAILS_PREALLOCATED_CASH_COL_NAME, preAllocCashPct);
			
			dashHoldingsList.put(portCode, dashHoldingsMap);

			dashHoldingsMap = new HashMap<String, Object>();			
		}

		return dashHoldingsList;	
	}
	
	//DONE
	public static Map<String, Map<String, Object>> getDashHoldingsNoTargetAllocations(Map<String, Object> tradeTicketData, Security security, String strategy) {
		//strategy is optional - this is for when only some target allocations; non-allocated still need to be updated for sec restrictions etc.
		//check restrictions and get current holdings without any allocations
		
		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		DecimalFormat num = new DecimalFormat("#,###");
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		Map<Integer, Map<String, Object>> portDetails = new HashMap<Integer, Map<String, Object>>();
		Map<Integer, Map<String, SecurityHolding>> portSecHoldings = new HashMap<Integer, Map<String, SecurityHolding>>();
		
		if (strategy == null) {
			portDetails = singleton.getAllPortfolioDetails();
		} else {
			portDetails = singleton.getStrategyPortfolioDetails(strategy);
		}
		portSecHoldings = singleton.getAllPortfolioSecHoldings();
		
		//get from security
		String cusip = null;
		String ticker = null;
		String action = null;
		double price = 0;
		double accrInt = 0;
		double minPiece = 0;
		

		Map<String, Object> secRestResults = new HashMap<String, Object>();
		//SecurityRestrictionChecker secRestChecker = new SecurityRestrictionChecker(); 
		if (strategy == null) { 
			secRestResults = SecurityRestrictionChecker.checkRestrictions(security, null);
		} else {
			secRestResults = SecurityRestrictionChecker.checkStrategyRestrictions(security, strategy);
		}
		
		Map<String, Double> aggRestResults = new HashMap<String, Double>();
		AggregateRestrictionChecker aggRestChecker = new AggregateRestrictionChecker();
		//done at the end once allocations are complete
		
		cusip = security.getValue(SecurityField.SYMBOL).toString();
		ticker = security.getValue(SecurityField.TICKER).toString();
		accrInt = Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString());
		action = tradeTicketData.get(TT_ACTION).toString().toLowerCase();
		price = Double.parseDouble(tradeTicketData.get(TT_PRICE).toString());
		minPiece = Double.parseDouble(security.getValue(SecurityField.MIN_PIECE).toString());
		
		Map<String, Object> dashHoldingsMap = new HashMap<String, Object>();
		Map<String, Map<String, Object>> dashHoldingsList = new HashMap<String, Map<String, Object>>();
		
		String portCode = null;
		boolean secRestriction = false;
		double portMktVal = 0;
		double adjPortMktVal = 0;
		double secHoldingQuant = 0;
		double secHoldingMktVal = 0;
		double issuerHoldingMktVal = 0;
		
		//will be used for any individual allocations, despite being no strategy target allocations
		double allocQuantity = 0;
		double allocMktVal = 0;
		Map<String, Double> allocations = new HashMap<String, Double>();
		Allocator allocator = new Allocator();

		
		for (Integer portId : portDetails.keySet()) {		
			portCode = portDetails.get(portId).get(DETAILS_PORTCODE_COL_NAME).toString();
			portMktVal = Double.parseDouble(portDetails.get(portId).get(DETAILS_MV_COL_NAME).toString());
			
			//adjust portMktVal for NAV adjustment
			if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
				adjPortMktVal = portMktVal + Double.parseDouble(tradeTicketData.get(portCode + TT_NAV_ADJUST).toString());
			} else {
				adjPortMktVal = portMktVal;
			}
			
			//current security holding
			secHoldingQuant = singleton.getSpecificSecurityHoldingsQuant(portId, cusip);
			secHoldingMktVal = secHoldingQuant * (price + accrInt) / security.getValuationFactor();
			
			//current ticker holding - uses market value from DB, except for the security from the trade ticket, which uses estimated price and accrued interest passed in 
			issuerHoldingMktVal = singleton.getSpecificIssuerHoldingsMktVal(portId, ticker);
			//adjust for estimated price of trade ticket security passed in if there is a security holding
			if (secHoldingQuant != 0) { 
				issuerHoldingMktVal = issuerHoldingMktVal - portSecHoldings.get(portId).get(cusip).getMarketValue() + secHoldingMktVal;
			}
			
			//get security restriction
			if (secRestResults.containsKey(portCode + "SecurityRestriction") && secRestResults.get(portCode + "SecurityRestriction").toString().equalsIgnoreCase("true")) {
				secRestriction = true;
			} else {
				secRestriction = false;
			}

			dashHoldingsMap.put(DETAILS_PORTCODE_COL_NAME, portCode);
			dashHoldingsMap.put(DASH_SEC_HOLDING, (secHoldingQuant == 0 ? "-" : num.format(secHoldingQuant / security.getQuantityFactor())));
			dashHoldingsMap.put(DASH_SEC_HOLDING_PCT, (secHoldingMktVal == 0 ? "-" : numTwoDec.format(secHoldingMktVal / adjPortMktVal * 100)));
			dashHoldingsMap.put(DASH_TICKER_HOLDING_PCT , (issuerHoldingMktVal == 0 ? "-" : numTwoDec.format(issuerHoldingMktVal / adjPortMktVal * 100)));
			dashHoldingsMap.put(DASH_SEC_RESTRICTION, (secRestriction == true ? "true" : "false"));
			
			//check for an allocation override since no target allocations for strategies, but could be individuals
			if (tradeTicketData.containsKey(portCode + TT_ALLOCATION_OVERRIDE) && ! tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString().equals("")) {
				if (action.equals("buy")) {
					allocQuantity = (secRestriction == true ? 0 : Double.parseDouble(tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString()) * security.getQuantityFactor());
				} else { //if it's a sell, allocation amount cannot be greater than amount held
					allocQuantity = (Double.parseDouble(tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString()) <= secHoldingQuant ? Double.parseDouble(tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString()) * security.getQuantityFactor() : secHoldingQuant);
				}

				//allocQuantity = Math.round(allocQuantity / 5000.0) * 5000.0;
				allocQuantity = allocator.roundAllocation(security, allocQuantity, action, secHoldingQuant, true);
				allocMktVal = allocQuantity * (price + accrInt) / security.getValuationFactor();

				dashHoldingsMap.put(DASH_ALLOC_MKT_VAL, numTwoDec.format(allocMktVal / adjPortMktVal * security.getValuationFactor()));
				dashHoldingsMap.put(DASH_ALLOC_QUANTITY, num.format(allocQuantity / security.getQuantityFactor()));
				
				if (action.equals("sell")) {
					dashHoldingsMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
					dashHoldingsMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
					if (allocQuantity > 0) {
						dashHoldingsMap.put(DASH_MIN_PIECE, (secHoldingQuant - allocQuantity) < minPiece && secHoldingQuant != allocQuantity ? "REMAINDER" : "");
						if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
							dashHoldingsMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
						} else {
							dashHoldingsMap.put(DASH_NOTES, "");
						}
					} else {
						dashHoldingsMap.put(DASH_MIN_PIECE, "");
						dashHoldingsMap.put(DASH_NOTES ,"");
					}
				} else { //buy
					dashHoldingsMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
					dashHoldingsMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
					if (allocQuantity > 0) {
						dashHoldingsMap.put(DASH_MIN_PIECE, allocQuantity + secHoldingQuant < minPiece ? "MIN PIECE" : "");
						if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
							dashHoldingsMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
						} else {
							dashHoldingsMap.put(DASH_NOTES, "");
						}
					} else {
						dashHoldingsMap.put(DASH_MIN_PIECE, "");
						dashHoldingsMap.put(DASH_NOTES ,"");
					}
				}
				allocations.put(portCode, allocQuantity / security.getQuantityFactor());
			} else {
				dashHoldingsMap.put(DASH_PF_SEC_HOLDING_PCT, (secHoldingMktVal == 0 ? "-" : numTwoDec.format(secHoldingMktVal / adjPortMktVal * 100)));
				dashHoldingsMap.put(DASH_PF_TICKER_HOLDING_PCT, (issuerHoldingMktVal == 0 ? "-" : numTwoDec.format(issuerHoldingMktVal / adjPortMktVal * 100)));
				allocations.put(portCode, 0.0);
			}			
			
			dashHoldingsList.put(portCode, dashHoldingsMap);
			
			dashHoldingsMap = new HashMap<String, Object>();
		
		}
		
		try {
			if (strategy == null) {
				aggRestResults = aggRestChecker.checkAllRestrictions(security, action, price, allocations); //check
			} else { 
				//adjust allocations for restriction groups
				JSONArray jsonAllocArray = new JSONArray(tradeTicketData.get("DashTable").toString()); //add other member port code to group if not there already
				Map<String, Double> additionalAllocs = new HashMap<String, Double>();
				for (String port : allocations.keySet()) {
					if (singleton.isInRestrictionGroup(singleton.getPortID(port))) { //adjust allocation quantity for group restrictions, i.e. BBBANK
						for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(port)))) {
							if (!allocations.containsKey(singleton.getPortCode(member))) {
								additionalAllocs.put(singleton.getPortCode(member), Double.parseDouble(jsonAllocArray.getJSONObject(0).get(singleton.getPortCode(member) + "ActualAllocation").toString().replaceAll(",", "")));
							}					
						}
					} 
				}
				if (!additionalAllocs.isEmpty()) {allocations.putAll(additionalAllocs);}

				aggRestResults = AggregateRestrictionChecker.checkAllRestrictions(security, action, price, allocations, strategy);
			}
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}

		for (String port : dashHoldingsList.keySet()) {
			if (aggRestResults.get(port + "AggregateRestriction") == null || aggRestResults.get(port + "AggregateRestriction") == 0) {
				dashHoldingsList.get(port).put("AggregateRestriction", "0");
			} else {
				dashHoldingsList.get(port).put("AggregateRestriction", numTwoDec.format(aggRestResults.get(port + "AggregateRestriction")));
			}
		}
		
		return dashHoldingsList;
	}
	
	//for only one strategy - DONE
	public static Map<String, Map<String, Object>> getDashAllocations(Map<String, Object> tradeTicketData, Security security, String strategy) {
		//pass in all security info and trade info 
		
		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		DecimalFormat num = new DecimalFormat("#,###");
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		Map<Integer, Map<String, Object>> portDetails = new HashMap<Integer, Map<String, Object>>();
		Map<Integer, Map<String, SecurityHolding>> portSecHoldings = new HashMap<Integer, Map<String, SecurityHolding>>();
		
		portDetails = singleton.getStrategyPortfolioDetails(strategy);
		portSecHoldings = singleton.getAllPortfolioSecHoldings();
		
		//get from security
		String cusip = null;
		String ticker = null;
		String action = null;
		double price = 0;
		double accrInt = 0;
		double targetAlloc = 0;
		String allocMethod = null;
		boolean allocationOverride = false;
		double minPiece = 0;
		
		Map<String, Object> secRestResults = new HashMap<String, Object>();
		//SecurityRestrictionChecker secRestChecker = new SecurityRestrictionChecker(); 
		secRestResults = SecurityRestrictionChecker.checkStrategyRestrictions(security, strategy);
		
		Map<String, Double> aggRestResults = new HashMap<String, Double>();
		//AggregateRestrictionChecker aggRestChecker = new AggregateRestrictionChecker();
		//done at the end once allocations are complete
		
		cusip = security.getValue(SecurityField.SYMBOL).toString();
		ticker = security.getValue(SecurityField.TICKER).toString();
		accrInt = Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString());
		action = tradeTicketData.get(TT_ACTION).toString().toLowerCase();
		price = Double.parseDouble(tradeTicketData.get(TT_PRICE).toString());
		minPiece = Double.parseDouble(security.getValue(SecurityField.MIN_PIECE).toString());
		allocMethod = tradeTicketData.get((strategy.equalsIgnoreCase("SDHY") ? "SDHY" : "CORE") + TT_ALLOC_METHOD).toString();
		targetAlloc = (tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty() ? 0 : Double.parseDouble(tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString()));
		
		Map<String, Object> dashHoldingsMap = new HashMap<String, Object>();
		Map<String, Map<String, Object>> dashHoldingsList = new HashMap<String, Map<String, Object>>();
		
		String portCode = null;
		boolean secRestriction = false;
		double portMktVal = 0;
		double adjPortMktVal = 0;
		double secHoldingQuant = 0;
		double secHoldingMktVal = 0;
		double issuerHoldingMktVal = 0;
		double allocQuantity = 0;
		Map<String, Double> allocations = new HashMap<String, Double>(); //used only for sending to aggregate restriction checker
		double allocMktVal = 0; //this is the percentage the allocation is of the portfolio market value as a whole
		double pctRelToTarget = 0;
		
		
		for (Integer portId : portDetails.keySet()) { //only getting port details for the specified strategy, so no longer need to check
			portCode = portDetails.get(portId).get(DETAILS_PORTCODE_COL_NAME).toString();
			portMktVal = Double.parseDouble(portDetails.get(portId).get(DETAILS_MV_COL_NAME).toString());
			
			//adjust portMktVal for NAV adjustment
			if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
				adjPortMktVal = portMktVal + Double.parseDouble(tradeTicketData.get(portCode + TT_NAV_ADJUST).toString());
			} else {
				adjPortMktVal = portMktVal;
			}
			
			//current security holding
			secHoldingQuant = singleton.getSpecificSecurityHoldingsQuant(portId, cusip);
			secHoldingMktVal = secHoldingQuant * (price + accrInt) / security.getValuationFactor();
			
			//current ticker holding - uses market value from DB, except for the security from the trade ticket, which uses estimated price and accrued interest passed in 
			issuerHoldingMktVal = singleton.getSpecificIssuerHoldingsMktVal(portId, ticker);
			//adjust for estimated price of trade ticket security passed in if there is a security holding
			if (secHoldingQuant != 0) { 
				issuerHoldingMktVal = issuerHoldingMktVal - portSecHoldings.get(portId).get(cusip).getMarketValue() + secHoldingMktVal;
			}
			
			//get security restriction
			if (secRestResults.containsKey(portCode + "SecurityRestriction") && secRestResults.get(portCode + "SecurityRestriction").toString().equalsIgnoreCase("true")) {
				secRestriction = true;
			} else {
				secRestriction = false;
			}
			
			//ALLOCATE
			Allocator allocator = new Allocator();
			allocationOverride = (tradeTicketData.containsKey(portCode + TT_ALLOCATION_OVERRIDE) && ! tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString().equals(""));
			if (!allocationOverride && tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty() && action.equalsIgnoreCase("sell")) {
				allocQuantity = 0;
			} else {
				allocQuantity = allocator.allocatePortfolio(portCode, tradeTicketData, secHoldingMktVal, secHoldingQuant, adjPortMktVal, secRestriction, action, allocMethod, issuerHoldingMktVal, targetAlloc, price, accrInt, security);
			}
			
			pctRelToTarget = (allocMethod.equalsIgnoreCase("security") ? targetAlloc - (secHoldingMktVal / adjPortMktVal * 100) : targetAlloc - (issuerHoldingMktVal / adjPortMktVal * 100));

			//allocQuantity = Math.round(allocQuantity / 5000.0) * 5000.0;
			//allocationOverride = (tradeTicketData.containsKey(portCode + TT_ALLOCATION_OVERRIDE) && ! tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString().equals(""));
			allocQuantity = allocator.roundAllocation(security, allocQuantity, action, secHoldingQuant, allocationOverride);
			allocations.put(portCode, allocQuantity / security.getQuantityFactor());
			
			allocMktVal = allocQuantity * (price + accrInt) / security.getValuationFactor();
			
			if (!tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty()) {
				dashHoldingsMap.put(DASH_PCT_TO_TARGET, numTwoDec.format(pctRelToTarget));
			} 
			
			dashHoldingsMap.put(DETAILS_PORTID_COL_NAME, portId);
			dashHoldingsMap.put(DETAILS_PORTCODE_COL_NAME, portCode);
			dashHoldingsMap.put(DETAILS_STRATEGY_COL_NAME, strategy);
			dashHoldingsMap.put(DASH_SEC_HOLDING, num.format(secHoldingQuant / security.getQuantityFactor()));
			dashHoldingsMap.put(DASH_SEC_HOLDING_PCT, numTwoDec.format(secHoldingMktVal / adjPortMktVal * 100));
			dashHoldingsMap.put(DASH_ALLOC_MKT_VAL, numTwoDec.format(allocMktVal / adjPortMktVal * security.getValuationFactor()));
			dashHoldingsMap.put(DASH_TICKER_HOLDING_PCT , numTwoDec.format(issuerHoldingMktVal / adjPortMktVal * 100));
			dashHoldingsMap.put(DASH_ALLOC_QUANTITY, num.format(allocQuantity / security.getQuantityFactor()));
			dashHoldingsMap.put(DASH_SEC_RESTRICTION, (secRestriction == true ? "true" : "false"));
			//dashHoldingsMap.put(DASH_PCT_TO_TARGET, numTwoDec.format(pctRelToTarget));
			
			//if (!tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty()) {
			if (action.equals("sell")) {
				dashHoldingsMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
				dashHoldingsMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
				if (allocQuantity > 0) {
					dashHoldingsMap.put(DASH_MIN_PIECE, (secHoldingQuant - allocQuantity) < minPiece && secHoldingQuant != allocQuantity  ? "REMAINDER" : "");
					if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
						dashHoldingsMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
					} else {
						dashHoldingsMap.put(DASH_NOTES, "");
					}
				} else {
					dashHoldingsMap.put(DASH_MIN_PIECE, "");
					dashHoldingsMap.put(DASH_NOTES ,"");
				}
			} else { //buy
				dashHoldingsMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
				dashHoldingsMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
				if (allocQuantity > 0) {
					dashHoldingsMap.put(DASH_MIN_PIECE, allocQuantity + secHoldingQuant < minPiece  ? "MIN PIECE" : "");
					if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
						dashHoldingsMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
					} else {
						dashHoldingsMap.put(DASH_NOTES, "");
					}
				} else {
					dashHoldingsMap.put(DASH_MIN_PIECE, "");
					dashHoldingsMap.put(DASH_NOTES ,"");
				}
			}

			dashHoldingsList.put(portCode, dashHoldingsMap);
			
			dashHoldingsMap = new HashMap<String, Object>();
		}
		
		try {
			//adjust allocations for restriction groups
			JSONArray jsonAllocArray = new JSONArray(tradeTicketData.get("DashTable").toString()); //add other member port code to group if not there already
			Map<String, Double> additionalAllocs = new HashMap<String, Double>();
			for (String port : allocations.keySet()) {
				if (singleton.isInRestrictionGroup(singleton.getPortID(port))) { //adjust allocation quantity for group restrictions, i.e. BBBANK
					for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(port)))) {
						if (!allocations.containsKey(singleton.getPortCode(member))) {
							additionalAllocs.put(singleton.getPortCode(member), Double.parseDouble(jsonAllocArray.getJSONObject(0).get(singleton.getPortCode(member) + "ActualAllocation").toString().replaceAll(",", "")));
						}					
					}
				} 
			}
			if (!additionalAllocs.isEmpty()) {allocations.putAll(additionalAllocs);}
			
			aggRestResults = AggregateRestrictionChecker.checkAllRestrictions(security, action, price, allocations, strategy);
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
	
		for (String port : dashHoldingsList.keySet()) {
			if (aggRestResults.get(port + "AggregateRestriction") == null || aggRestResults.get(port + "AggregateRestriction") == 0) {
				dashHoldingsList.get(port).put("AggregateRestriction", "0");
				
				if (singleton.isInRestrictionGroup(singleton.getPortID(port))) {
					for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(port)))) {
						if (member != singleton.getPortID(port)) {dashHoldingsList.get(port).put(singleton.getPortCode(member) + "AggregateRestriction", "0");}
					}
				}
			} else {
				dashHoldingsList.get(port).put("AggregateRestriction", numTwoDec.format(aggRestResults.get(port + "AggregateRestriction")));
				
				if (singleton.isInRestrictionGroup(singleton.getPortID(port))) {
					for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(port)))) {
						if (member != singleton.getPortID(port)) {dashHoldingsList.get(port).put(singleton.getPortCode(member) + "AggregateRestriction", numTwoDec.format(aggRestResults.get(port + "AggregateRestriction")));}
					}
				}
			}
		}

		return dashHoldingsList;
	}
	
	public static Map<String, Object> getAllocationOverrideResults(Map<String, Object> tradeTicketData, Security security) {
		//pass in all security info and trade info 
		
		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		DecimalFormat num = new DecimalFormat("#,###");
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		
		String portCode = null;
		int portId = 0;
		double allocQuantity = 0;
		Map<String, Object> portDetails = new HashMap<String, Object>();
		
		portCode = tradeTicketData.get(TT_PORT_CODE).toString();
		portDetails = singleton.getSinglePortfolioDetails(portCode);
		portId = Integer.valueOf(portDetails.get(DETAILS_PORTID_COL_NAME).toString());
		
		if (tradeTicketData.get(TT_ALLOCATION_OVERRIDE) == null || tradeTicketData.get(TT_ALLOCATION_OVERRIDE).toString().isEmpty()) {
			allocQuantity = 0;
		} else {
			allocQuantity = Double.parseDouble(tradeTicketData.get(TT_ALLOCATION_OVERRIDE).toString()) * security.getQuantityFactor();
		}
		
		Map<Integer, Map<String, SecurityHolding>> portSecHoldings = new HashMap<Integer, Map<String, SecurityHolding>>();
		portSecHoldings = singleton.getAllPortfolioSecHoldings();
		
		//get from security
		String cusip = null;
		String ticker = null;
		String action = null;
		double price = 0;
		double accrInt = 0;
		double minPiece = 0;		
		
		cusip = security.getValue(SecurityField.SYMBOL).toString();
		ticker = security.getValue(SecurityField.TICKER).toString();
		accrInt = Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString());
		action = tradeTicketData.get(TT_ACTION).toString().toLowerCase();
		price = Double.parseDouble(tradeTicketData.get(TT_PRICE).toString());
		minPiece = Double.parseDouble(security.getValue(SecurityField.MIN_PIECE).toString());
	
		//map to hold results
		Map<String, Object> newAllocationMap = new HashMap<String, Object>();

		double portMktVal = 0;
		double adjPortMktVal = 0;
		double secHoldingQuant = 0;
		double secHoldingMktVal = 0;
		double issuerHoldingMktVal = 0;
		double allocMktVal = 0; //this is the percentage the allocation is of the portfolio market value as a whole
			
		//adjust portMktVal for NAV adjustment
		portMktVal = Double.parseDouble(portDetails.get(DETAILS_MV_COL_NAME).toString());
		if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
			adjPortMktVal = portMktVal + Double.parseDouble(tradeTicketData.get(portCode + TT_NAV_ADJUST).toString());
		} else {
			adjPortMktVal = portMktVal;
		}
				
		//current security holding
		secHoldingQuant = singleton.getSpecificSecurityHoldingsQuant(portId, cusip);
		secHoldingMktVal = secHoldingQuant * (price + accrInt) / security.getValuationFactor();
				
		//current ticker holding - uses market value from DB, except for the security from the trade ticket, which uses estimated price and accrued interest passed in 
		issuerHoldingMktVal = singleton.getSpecificIssuerHoldingsMktVal(portId, ticker);
		//adjust for estimated price of trade ticket security passed in if there is a security holding
		if (secHoldingQuant != 0) { 
			issuerHoldingMktVal = issuerHoldingMktVal - portSecHoldings.get(portId).get(cusip).getMarketValue() + secHoldingMktVal;
		}
	
				
		//allocQuantity = Math.round(allocQuantity / 5000.0) * 5000.0;
		Allocator allocator = new Allocator();
		allocQuantity = allocator.roundAllocation(security, allocQuantity, action, secHoldingQuant, true); //still need to use function to verify not selling more than holdings
		allocMktVal = allocQuantity * (price + accrInt) / security.getValuationFactor();
				
		if (action.equals("sell")) {
			newAllocationMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
			newAllocationMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
			if (allocQuantity > 0) {
				newAllocationMap.put(DASH_MIN_PIECE, (secHoldingQuant - allocQuantity) < minPiece && secHoldingQuant != allocQuantity  ? "REMAINDER" : "");
				if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
					newAllocationMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
				} else {
					newAllocationMap.put(DASH_NOTES, "");
				}
			} else {
				newAllocationMap.put(DASH_MIN_PIECE, "");
				newAllocationMap.put(DASH_NOTES ,"");
			}
		} else { //buy
			newAllocationMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
			newAllocationMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
			if (allocQuantity > 0) {
				newAllocationMap.put(DASH_MIN_PIECE, allocQuantity + secHoldingQuant < minPiece  && allocQuantity > 0 ? "MIN PIECE" : "");
				if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
					newAllocationMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
				} else {
					newAllocationMap.put(DASH_NOTES, "");
				}
			} else {
				newAllocationMap.put(DASH_MIN_PIECE, "");
				newAllocationMap.put(DASH_NOTES ,"");
			}
		}
		newAllocationMap.put(DASH_ALLOC_MKT_VAL, numTwoDec.format(allocMktVal / adjPortMktVal * security.getValuationFactor()));
		newAllocationMap.put(DASH_ALLOC_QUANTITY, num.format(allocQuantity / security.getQuantityFactor()));
		
		double aggRestResult = 0;
		double allocation = 0;
		//AggregateRestrictionChecker aggRestChecker = new AggregateRestrictionChecker();
		
		try {
			allocation = allocQuantity / security.getQuantityFactor();
			if (singleton.isInRestrictionGroup(portId)) { //adjust allocation quantity for group restrictions, i.e. BBBANK
				JSONArray jsonAllocArray = new JSONArray(tradeTicketData.get("DashTable").toString());

				for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(portId))) {
					if (member != portId) {
						allocation = allocation + Double.parseDouble(jsonAllocArray.getJSONObject(0).get(singleton.getPortCode(member) + "ActualAllocation").toString().replaceAll(",", ""));
					}					
				}
			} 
			aggRestResult = AggregateRestrictionChecker.checkPortfolioRestrictions(security, action, price, allocation, portId);
			//aggRestResult = AggregateRestrictionChecker.checkPortfolioRestrictions(security, action, price, allocation, singleton.getParentPortfolioGroup(portId));
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		newAllocationMap.put("AggregateRestriction", (aggRestResult == 0 ? "0" : numTwoDec.format(aggRestResult)));
		if (singleton.isInRestrictionGroup(portId)) {
			for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(portId))) {
				if (member != portId) {
					newAllocationMap.put(singleton.getPortCode(member) + "AggregateRestriction", (aggRestResult == 0 ? "0" : numTwoDec.format(aggRestResult)));
				}					
			}
		}
		
		return newAllocationMap;
	}
	
	
	public static Map<String, Object> getNAVAdjustmentResults(Map<String, Object> tradeTicketData, Security security) {
		//pass in all security info and trade info 
		
		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		DecimalFormat num = new DecimalFormat("#,###");
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		String portCode = null;
		int portId = 0;
		Map<String, Object> portDetails = new HashMap<String, Object>();
		
		portCode = tradeTicketData.get(TT_PORT_CODE).toString();
		portDetails = singleton.getSinglePortfolioDetails(portCode);
		portId = Integer.valueOf(portDetails.get(DETAILS_PORTID_COL_NAME).toString());
		
		Map<Integer, Map<String, SecurityHolding>> portSecHoldings = new HashMap<Integer, Map<String, SecurityHolding>>();
		portSecHoldings = singleton.getAllPortfolioSecHoldings();

		//get from security
		String cusip = null;
		String ticker = null;
		String action = null;
		double price = 0;
		double accrInt = 0;
		String allocMethod = null;
		double targetAlloc = 0;
		String strategy = null;
		double minPiece = 0;
		
		cusip = security.getValue(SecurityField.SYMBOL).toString();
		ticker = security.getValue(SecurityField.TICKER).toString();
		accrInt = Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString());
		action = tradeTicketData.get(TT_ACTION).toString().toLowerCase();
		price = Double.parseDouble(tradeTicketData.get(TT_PRICE).toString());
		minPiece = Double.parseDouble(security.getValue(SecurityField.MIN_PIECE).toString());
		strategy = tradeTicketData.get(TT_STRATEGY).toString();
		allocMethod = tradeTicketData.get((strategy.equalsIgnoreCase("SDHY") ? "SDHY" : "CORE") + TT_ALLOC_METHOD).toString().toLowerCase();
		targetAlloc = (tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty() ? 0 :Double.parseDouble(tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString()));
	
		//map to hold results
		Map<String, Object> newAllocationMap = new HashMap<String, Object>();

		double portMktVal = 0;
		double adjPortMktVal = 0;
		double secHoldingQuant = 0;
		double secHoldingMktVal = 0;
		double issuerHoldingMktVal = 0;
		double allocQuantity = 0;
		double allocMktVal = 0; //this is the percentage the allocation is of the portfolio market value as a whole
		double pctRelToTarget = 0;
		boolean allocationOverride = false;
			
		portMktVal = Double.parseDouble(portDetails.get(DETAILS_MV_COL_NAME).toString());
		
		if (!tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) || tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().isEmpty()) {
			adjPortMktVal = portMktVal;
		} else {
			adjPortMktVal = portMktVal + Double.parseDouble(tradeTicketData.get(portCode + TT_NAV_ADJUST).toString());
		}

				
		//current security holding
		secHoldingQuant = singleton.getSpecificSecurityHoldingsQuant(portId, cusip);
		secHoldingMktVal = secHoldingQuant * (price + accrInt) / security.getValuationFactor();
				
		//current ticker holding - uses market value from DB, except for the security from the trade ticket, which uses estimated price and accrued interest passed in 
		issuerHoldingMktVal = singleton.getSpecificIssuerHoldingsMktVal(portId, ticker);
		//adjust for estimated price of trade ticket security passed in if there is a security holding
		if (secHoldingQuant != 0) { 
			issuerHoldingMktVal = issuerHoldingMktVal - portSecHoldings.get(portId).get(cusip).getMarketValue() + secHoldingMktVal;
		}
		
		//check sec restrictions
		//SecurityRestrictionChecker secRestChecker = new SecurityRestrictionChecker();
		boolean secRestriction;
		if (SecurityRestrictionChecker.checkRestrictions(security, portId).containsKey(portCode + "SecurityRestriction")) {
			secRestriction = (SecurityRestrictionChecker.checkRestrictions(security, portId).get(portCode + "SecurityRestriction").toString().equalsIgnoreCase("true") ? true : false);
		} else {
			secRestriction = false;
		}
		
		//allocate here
		Allocator allocator = new Allocator();
		allocQuantity = allocator.allocatePortfolio(portCode, tradeTicketData, secHoldingMktVal, secHoldingQuant, adjPortMktVal, secRestriction, action, allocMethod, issuerHoldingMktVal, targetAlloc, price, accrInt, security);
		pctRelToTarget = (allocMethod.equalsIgnoreCase("security") ? targetAlloc - (secHoldingMktVal / adjPortMktVal * 100) : targetAlloc - (issuerHoldingMktVal / adjPortMktVal * 100));
			
		//allocQuantity = Math.round(allocQuantity / 5000.0) * 5000.0;
		allocationOverride = (tradeTicketData.containsKey(portCode + TT_ALLOCATION_OVERRIDE) && ! tradeTicketData.get(portCode + TT_ALLOCATION_OVERRIDE).toString().equals(""));
		if (!allocationOverride && tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty()) {
			allocQuantity = 0;
			allocMktVal = 0;
		} else {
			allocQuantity = allocator.roundAllocation(security, allocQuantity, action, secHoldingQuant, allocationOverride);
			allocMktVal = allocQuantity * (price + accrInt) / security.getValuationFactor();
		}
	

		if (action.equals("sell")) {
			newAllocationMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
			newAllocationMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal - allocMktVal) / adjPortMktVal * 100));
			if (allocQuantity > 0) {
				newAllocationMap.put(DASH_MIN_PIECE, (secHoldingQuant - allocQuantity) < minPiece && allocQuantity > 0 && secHoldingQuant != allocQuantity ? "REMAINDER" : "");
				if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
					newAllocationMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
				} else {
					newAllocationMap.put(DASH_NOTES, "");
				}
			} else {
				newAllocationMap.put(DASH_MIN_PIECE, "");
				newAllocationMap.put(DASH_NOTES ,"");
			}
		} else { //buy
			newAllocationMap.put(DASH_PF_SEC_HOLDING_PCT, numTwoDec.format((secHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
			newAllocationMap.put(DASH_PF_TICKER_HOLDING_PCT, numTwoDec.format((issuerHoldingMktVal + allocMktVal) / adjPortMktVal * 100));
			if (allocQuantity > 0) {
				newAllocationMap.put(DASH_MIN_PIECE, allocQuantity + secHoldingQuant < minPiece && allocQuantity > 0 ? "MIN PIECE" : "");
				if (tradeTicketData.containsKey(portCode + TT_NAV_ADJUST) && ! tradeTicketData.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
					newAllocationMap.put(DASH_NOTES, "Allocation: " + numTwoDec.format(allocMktVal / portMktVal * 100) + "%");
				} else {
					newAllocationMap.put(DASH_NOTES, "");
				}
			} else {
				newAllocationMap.put(DASH_MIN_PIECE, "");
				newAllocationMap.put(DASH_NOTES ,"");
			}
		}
		
		newAllocationMap.put(DASH_ALLOC_MKT_VAL, numTwoDec.format(allocMktVal / adjPortMktVal * security.getValuationFactor()));
		newAllocationMap.put(DASH_ALLOC_QUANTITY, num.format(allocQuantity / security.getQuantityFactor()));
		newAllocationMap.put(DASH_SEC_HOLDING_PCT, numTwoDec.format(secHoldingMktVal / adjPortMktVal * 100));
		newAllocationMap.put(DASH_TICKER_HOLDING_PCT , numTwoDec.format(issuerHoldingMktVal / adjPortMktVal * 100));
		
		if (!tradeTicketData.get(strategy + TT_TARGET_ALLOCATION).toString().isEmpty()) {
			newAllocationMap.put(DASH_PCT_TO_TARGET, numTwoDec.format(pctRelToTarget));
		}
		
		double aggRestResult = 0;
		double allocation = 0;
		
		try {
			allocation = allocQuantity / security.getQuantityFactor();
			if (singleton.isInRestrictionGroup(portId)) { //adjust allocation quantity for group restrictions, i.e. BBBANK
				JSONArray jsonAllocArray = new JSONArray(tradeTicketData.get("DashTable").toString());
				
				for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(portId))) {
					if (member != portId) {
						allocation = allocation + Double.parseDouble(jsonAllocArray.getJSONObject(0).get(singleton.getPortCode(member) + "ActualAllocation").toString().replaceAll(",", ""));
					}
				}
			} 
			
			aggRestResult = AggregateRestrictionChecker.checkPortfolioRestrictions(security, action, price, allocation, portId);
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		newAllocationMap.put("AggregateRestriction", (aggRestResult == 0 ? "0" : numTwoDec.format(aggRestResult)));
		if (singleton.isInRestrictionGroup(portId)) {
			for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(portId))) {
				if (member != portId) {
					newAllocationMap.put(singleton.getPortCode(member) + "AggregateRestriction", (aggRestResult == 0 ? "0" : numTwoDec.format(aggRestResult)));
				}					
			}
		}

		return newAllocationMap;
	}
	
	//used for a price change when there are only individual allocations, not target allocations
	public static double getAggRestrictionResult(Map<String, Object> tradeTicketData, String portCode, double allocQuantity, Security security) {

		DecimalFormat numTwoDec = new DecimalFormat("#,###.00");
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return 999;
		}
		
		int portId = 0;
		Map<String, Object> portDetails = new HashMap<String, Object>();		
		portDetails = singleton.getSinglePortfolioDetails(portCode);
		portId = Integer.valueOf(portDetails.get(DETAILS_PORTID_COL_NAME).toString());
		
		String action = null;
		double price = 0;		
		action = tradeTicketData.get(TT_ACTION).toString().toLowerCase();
		price = Double.parseDouble(tradeTicketData.get(TT_PRICE).toString());
			
		double aggRestResult = 0;
		double adjustedAllocation;
		
		try {
			adjustedAllocation = allocQuantity;
			if (singleton.isInRestrictionGroup(portId)) { //adjust allocation quantity for group restrictions, i.e. BBBANK
				JSONArray jsonAllocArray = new JSONArray(tradeTicketData.get("DashTable").toString());
				
				for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(portId))) {
					if (member != portId) {
						adjustedAllocation = adjustedAllocation + Double.parseDouble(jsonAllocArray.getJSONObject(0).get(singleton.getPortCode(member) + "ActualAllocation").toString().replaceAll(",", ""));
					}
				}
			} 
			
			aggRestResult = AggregateRestrictionChecker.checkPortfolioRestrictions(security, action, price, adjustedAllocation, portId);
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			return 999;
		}
		
		
		return Double.parseDouble(numTwoDec.format(aggRestResult));
	}
	
	
	
}
