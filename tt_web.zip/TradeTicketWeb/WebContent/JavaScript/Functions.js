document.writeln('<script src="/javascripts/jquery.js" type="text/javascript"></script>');

function getJSONFormData($form){
    var unindexed_array = $form.serializeArray();
    var indexed_array = {};
    $.map(unindexed_array, function(n, i){
    	if (n['value'].indexOf(",") >= 0) {
	    	var element = $("[name=" + n['name'] + "]", $form);
	    	if (element.hasClass("thousandFormat")) {
	    		indexed_array[n['name']] = n['value'].replace(/,/g, "");
	    	} else {
	    		indexed_array[n['name']] = n['value'];
	    	}
    	} else {
    		indexed_array[n['name']] = n['value'];
    	}
    });
        
    return indexed_array;
}

function getJSONFormDataPreSubmit($form){
	//exclude navadjust and allocationoverride since it is include in dashtable in converDashForArchive
    var unindexed_array = $form.serializeArray();
    var indexed_array = {};

    $.map(unindexed_array, function(n, i){ //13,18
    	if (String(n['name']).substr(String(n['name']).length - 13, 13) != "NAVAdjustment" && String(n['name']).substr(String(n['name']).length - 18, 18) != "AllocationOverride") {
    		indexed_array[n['name']] = n['value'];
    	}
    });
    
    return indexed_array;
}

function convertDashForArchive(){
	var result = {};

	
	$("#tradeTicketDashSDHY tr").each(function() { 		
		$(this).find("td").each(function() {
			result[$(this).attr("id")] = $(this).text();
		});
	});	


	$("#tradeTicketDashCORE tr").each(function() {		
		$(this).find("td").each(function() {
			result[$(this).attr("id")] = $(this).text();
		});
	});

	return result;
	
}

function isNumberNegKey(evt) {
   var charCode = (evt.which) ? evt.which : event.keyCode;
   if (charCode != 45 && charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
	   return false;
   }
   else 
   {
	   return true;
	}
}

function isNumberKey(evt) {
   var charCode = (evt.which) ? evt.which : event.keyCode;
   if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
	   return false;
   }
   else 
   {
	   return true;
	}
}

function isWholeNumberKey(evt) {
   var charCode = (evt.which) ? evt.which : event.keyCode;
   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
	   return false;
   }
   else 
   {
	   return true;
	}
}

function isNumeric(evt) {
	return !jQuery.isArray( evt ) && (evt - parseFloat( evt ) + 1) >= 0;
}

function addCommas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}

function markInvalid(elementId) {
	var element = document.getElementById(elementId);
	element.innerHTML("&#10008;"); //for td
	element.value = "&#10008;"; //textarea
}


function isValidDate(dateString) { //for mm-dd-yyyy
	  var regEx = /^\d{2}-\d{2}-\d{4}$/;

	  if (dateString.match(regEx) == null) {
		  return false;
	  }
	  /*return dateString.match(regEx) != null;*/
	  
	  
	  //Parse the date parts to integers
	    var parts = dateString.split("-");
	    var day = parseInt(parts[1], 10);
	    var month = parseInt(parts[0], 10);
	    var year = parseInt(parts[2], 10);

	    // Check the ranges of month and year
	    if(year < 1000 || year > 3000 || month == 0 || month > 12)
	        return false;

	    var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

	    // Adjust for leap years
	    if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
	        monthLength[1] = 29;

	    // Check the range of the day
	    return day > 0 && day <= monthLength[month - 1];
	}

function isValidUSDate(dateString) { //for mm/dd/yyyy
	  var regEx = /^\d{2}\/\d{2}\/\d{4}$/;

	  if (dateString.match(regEx) == null) {
		  return false;
	  }
	  /*return dateString.match(regEx) != null;*/
	  
	  
	  //Parse the date parts to integers
	    var parts = dateString.split("/");
	    var day = parseInt(parts[1], 10);
	    var month = parseInt(parts[0], 10);
	    var year = parseInt(parts[2], 10);

	    // Check the ranges of month and year
	    if(year < 1000 || year > 3000 || month == 0 || month > 12)
	        return false;

	    var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

	    // Adjust for leap years
	    if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
	        monthLength[1] = 29;

	    // Check the range of the day
	    return day > 0 && day <= monthLength[month - 1];
	}

function isUSDateKey(evt) { //numbers and / only
	   var charCode = (evt.which) ? evt.which : event.keyCode;
	   if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 47) {
		   return false;
	   }
	   else {
		   return true;
		}
	}


function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function isDateKey(evt) { //numbers and dashes only
   var charCode = (evt.which) ? evt.which : event.keyCode;
   if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 45) {
	   return false;
   }
   else {
	   return true;
	}
}

function escapeHTML (unsafe_str) {
    return unsafe_str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\"/g, '&#34;')
      .replace(/\\/g, '&#92') // backslash
      .replace(/\//g, '&#47') // backslash
      .replace(/\'/g, '&#39;'); // '&apos;' is not valid HTML 4
}

function validNewIssueInputs () {
	var fieldList = ["overrideTicker", "overrideIssueSize", "overrideMaturity", "overrideIssuerOut","overrideCntryRisk",
	                 "overrideCntryDmcle", "overrideCntryIncorp", "overrideMinPiece", "overrideGroup", "overrideSector", "overrideCouponType"];
	
	/*remove ratings from check list for no rating option*/
	
	if ($("#SECTYPE_OVERRIDE").val() == "cbus") {
		fieldList.push("overrideSecFactorable");
	}
	
	for (var i = 0; i < fieldList.length; i++) {
		if (!$("#" + fieldList[i]).val()) {
			alert("Missing field: " + String(fieldList[i]).substr(8, fieldList[i].length - 8));
			return false;
		}
	}
	
	if (!isValidUSDate(String($("#overrideMaturity").val()))) {
		alert("Invalid maturity date.");
		return false;
	}
	
	if (String($("#overrideCntryRisk").val()).length < 2) {
		alert("Country of risk must be 2 characters in length.");
		return false;
	} else if (String($("#overrideCntryDmcle").val()).length < 2) {
		alert("Country of domicile must be 2 characters in length.");
		return false;
	} else if (String($("#overrideCntryIncorp").val()).length < 2) {
		alert("Country of incorporation must be 2 characters in length.");
		return false;
	}
	
	return true;
}

function clearBBGTable() {
	var cellList = ["ticker", "desc", "masterII", "coupon", "sector", "maturity", "maturityYears", "group", "YTW", "barclays", "spRating", "moodyRating",
	                "fitchRating", "144A", "regRights", "secFactorable", "minPiece", "issueSize", "issueOut", "accInt", "countryRisk", "countryDomicile", "countryIncorp"];
	
	for (var i = 0; i < cellList.length; i++) {
		$("#" + cellList[i]).html("");
	}
	
}

function clearNewIssueTable() {
	var fieldList = ["overrideTicker", "overrideIssueSize", "overrideMaturity", "overrideIssuerOut", "overrideSPRating", "overrideCntryRisk",
	                 "overrideMoodyRating", "overrideSecFactorable", "overrideCntryDmcle", "overrideFitchRating", "overrideCntryIncorp", "overrideMinPiece", "overrideGroup", "overrideSector", "overrideCouponType"];
	
	for (var i = 0; i < fieldList.length; i++) {
		$("#" + fieldList[i]).val("");
	}
}

function clearComments() {
	$("#tradeLimit").val("");
	$("#tradeTiming").val("");
	$("#tradeComments").val("");
}

function isNewIssue() {
	return String($("#cusip").val()).toLowerCase() == "ni" || String($("#cusip").val()).toLowerCase() == "nl";
}

function newIssueTableToJSON() {
	//var jsonString;	
	//return JSON.stringify($("#newIssueInputTable").each("input","select").serialize());
	var jsonString = "{";
	var maturity;
	
	//remove commas from numbers
	/*switch ($("#SECTYPE_OVERRIDE").val()) {
	case "cbus":
	case "vbus":
	case "blus":
		return "corp";
	case "csus":
		return "equity";
	default:
		return "";
}*/
	
	$("#newIssueInputTable input, #newIssueInputTable select").each(function() { 
		if (String($(this).attr("name")).length > 8 && String($(this).attr("name")).substr(0, 8).toLowerCase() == "override") {
			switch ($(this).attr("name")) {
			case "overrideMATURITY":
				maturity = String($(this).val()).substr(6, 4) + "-" + String($(this).val()).substr(0, 2) + "-" + String($(this).val()).substr(3, 2);
				jsonString = jsonString + "\"" + String($(this).attr("name")).substr(8, String($(this).attr("name")).length - 8) + "\":\"" + maturity + "\",";
				break;
			case "overrideMIN_PIECE":
			case "overrideAMT_OUTSTANDING":
			case "overrideDDIS_AMT_OUTSTANDING_ISSUER_SUBS":
				jsonString = jsonString + "\"" + String($(this).attr("name")).substr(8, String($(this).attr("name")).length - 8) + "\":\"" + $(this).val().replace(/,/g, "") + "\",";
				break;
			default:
				jsonString = jsonString + "\"" + String($(this).attr("name")).substr(8, String($(this).attr("name")).length - 8) + "\":\"" + $(this).val() + "\",";
			}
		}
	});

	jsonString = String(jsonString).substr(0, String(jsonString).length -1) + "}";

	return jsonString;
	
}

function newIssueTableToJSONObj() {
	var jsonObj = {};
	
	var maturity;
	
	$("#newIssueInputTable input, #newIssueInputTable select").each(function() { 
		if (String($(this).attr("name")).length > 8 && String($(this).attr("name")).substr(0, 8).toLowerCase() == "override") {
			switch ($(this).attr("name")) {
			case "overrideMATURITY":
				maturity = String($(this).val()).substr(6, 4) + "-" + String($(this).val()).substr(0, 2) + "-" + String($(this).val()).substr(3, 2);
				jsonObj[String($(this).attr("name")).substr(8, String($(this).attr("name")).length - 8)] = maturity;
				break;
			case "overrideMIN_PIECE":
			case "overrideAMT_OUTSTANDING":
			case "overrideDDIS_AMT_OUTSTANDING_ISSUER_SUBS":
				jsonObj[String($(this).attr("name")).substr(8, String($(this).attr("name")).length - 8)] = $(this).val().replace(/,/g, "");
				break;
			default:
				jsonObj[String($(this).attr("name")).substr(8, String($(this).attr("name")).length - 8)] = $(this).val();
			}
		}
	});

	return jsonObj;
}

function basicPreTradeCheck() {
	//returns false if errors, true if no errors
	var result = true;
	
	//check valid action	
	if (!(String($("#action").val()).toLowerCase() == "sell" || String($("#action").val()).toLowerCase() == "buy")) {
		alert("Invalid action - must be 'buy' or 'sell'.  Cannot submit trade.");
		return false;
	}
	
	//check that quantity > 0 
	if (($("#totalAllocation").text()*1 + $("#totalAllocation").text()*1) <= 0) {
		alert("Total allocation is not greater than zero.  Cannot submit trade.");
		return false;
	}
	
	//check for agg restriction > 100%, check for minpiece and do warning
	$("#tradeTicketDashSDHY tr").each(function() { 
		portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
		if ($("#" + portCode + "AggregateRestriction").text()*1 > 100 && $("#" + portCode + "ActualAllocation").text()*1 > 0) {
			alert("The aggregate restriction level for " + portCode + " is greater than 100%.  Cannot submit trade.");
			result = false;
			return false;
		}
		if (String($("#" + portCode + "MinPiece").text()).toLowerCase() == "min piece" || String($("#" + portCode + "MinPiece").text()).toLowerCase() == "remainder") {
			if (!confirm(portCode + " will have holdings less than the minimum piece.  Would you still like to submit the trade?")) {
				result = false;
				return false;
			}
		}
	});
	if (!result) { return false; }
	
	$("#tradeTicketDashCORE tr").each(function() {
		portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
		if ($("#" + portCode + "AggregateRestriction").text()*1 > 100 && $("#" + portCode + "ActualAllocation").text()*1 > 0) {
			alert("The aggregate restriction level for " + portCode + " is greater than 100%.  Cannot submit trade.");
			result = false;
			return false;
		}
		if (String($("#" + portCode + "MinPiece").text()).toLowerCase() == "min piece" || String($("#" + portCode + "MinPiece").text()).toLowerCase() == "remainder") {
			if (!confirm(portCode + " will have holdings less than the minimum piece.  Would you still like to submit the trade?")) {
				results = false;
				return false;
			}
		}
	});
	if (!result) { return false; }
	
	//new issue warning
	if (isNewIssue()) {
		if (!confirm("You are using the new issue capabilities.  Click OK to confirm you have verified that all data is correct.")) {
			return false;
		}
	}
	
	//security factorable warning
	if (String($("#secFactorable").val()).toLowerCase() == "y") {
		if (!confirm("This security may be factorable.  Click OK to confirm you have discussed with operations and trading to ensure this trade can be executed and settled properly.")) {
			return false;
		}
	}

	return true;
}



function clearBottomHalf() {
	//background color
	//clears dash tables and inputs
	$("#tradeTicketDashSDHY tr").each(function() {
		portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
		$("#" + portCode + "SecurityRestriction").html("-");
		$("#" + portCode + "AggregateRestriction").html("0");
		$("#" + portCode + "SecurityRestriction").css("background-color", $("#" + portCode + "PortfolioCode").css("background-color"));
		$("#" + portCode + "AggregateRestriction").css("background-color", $("#" + portCode + "PortfolioCode").css("background-color"));
		$("#" + portCode + "PctRelativeToTarget").html("-");
		$("#" + portCode + "SecHoldings").html("0");
		$("#" + portCode + "ActualAllocation").html("0");
		$("[name='" + portCode + "AllocationOverride']").val("");
		$("#" + portCode + "ActualAllocation").html("0");
		$("#" + portCode + "SecHoldingsPct").html("-");
		$("#" + portCode + "TickerHoldingsPct").html("-");
		$("#" + portCode + "ProFormaSecHoldingsPct").html("-");
		$("#" + portCode + "ProFormaTickerHoldingsPct").html("-");
		$("#" + portCode + "MinPiece").html("");
		$("#" + portCode + "Notes").html("");
		$("#" + portCode + "SecSpecificNotes").html("");
	});
	$("#tradeTicketDashCORE tr").each(function() {
		portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
		$("#" + portCode + "SecurityRestriction").html("-");
		$("#" + portCode + "AggregateRestriction").html("0");
		$("#" + portCode + "SecurityRestriction").css("background-color", $("#" + portCode + "PortfolioCode").css("background-color"));
		$("#" + portCode + "AggregateRestriction").css("background-color", $("#" + portCode + "PortfolioCode").css("background-color"));
		$("#" + portCode + "PctRelativeToTarget").html("-");
		$("#" + portCode + "SecHoldings").html("0");
		$("#" + portCode + "ActualAllocation").html("0");
		$("[name='" + portCode + "AllocationOverride']").val("");
		$("#" + portCode + "ActualAllocation").html("0");
		$("#" + portCode + "SecHoldingsPct").html("-");
		$("#" + portCode + "TickerHoldingsPct").html("-");
		$("#" + portCode + "ProFormaSecHoldingsPct").html("-");
		$("#" + portCode + "ProFormaTickerHoldingsPct").html("-");
		$("#" + portCode + "MinPiece").html("");
		$("#" + portCode + "Notes").html("");
		$("#" + portCode + "SecSpecificNotes").html("");
	});
	
	$("#SDHYTotalAllocation").html("0");
	$("#CORETotalAllocation").html("0");
	$("#SDHYTargetAllocation").val("");
	$("#CORECONTargetAllocation").val("");
	$("#COREUNCTargetAllocation").val("");
	$("#ENRGTargetAllocation").val("");
	$("#SDHYAllocationMethod").val("security");
	$("#COREAllocationMethod").val("security");
}

function updateSecTypeDenominations() {
	var secType = $("#SECTYPE_OVERRIDE").val();
	var denomination = "";
	
	if (secType == "cbus" || secType == "vbus" || secType == "blus") {
		denomination = " (thousands)";
	} //for csus, denomination is as is
	
	$("span.denomination").each(function() {
		$(this).html(denomination);
	});
}

function formatDate(dateString) { //formats date from yyyy-mm-dd to mm/dd/yyyy
	var date = new Date(String(dateString).replace( /(\d{4})-(\d{2})-(\d{2})/, "$2/$3/$1"));
	return (date.getMonth() + 1) + '/' + date.getDate() + '/' +  date.getFullYear();
	/*2015-06-15
	var maturityDate = new Date(String(dateString).replace( /(\d{4})-(\d{2})-(\d{2})/, "$2/$3/$1"));*/
}

function normalizeUSDate(dateString) { //add missing zeroes to get to mm/dd/yyyy from (ie) m/d/yyyy
	var date = dateString.split("/");
	var day = date[0].length==1 ? "0" + date[0] : date[0];
	var month = date[1].length==1 ? "0" + date[1] : date[1];
	
	return day + "/" + month + "/" + date[2];
	
}

function clearTicketInputs() {
	$("#cusip").data("priorCusip", "");
	$("#cusip").addClass("invalid");
	$("#jsonString").html("");
	$("#priorCusip").html("");
	$("#cusip").data("securityMap", "");
	$("#cusipCheckmark").html("");
	//alert($("#cusip").data("priorCusip"));
	
	$(".clearable").each(function() {
		$(this).val("");
	});
	
	$("#SECTYPE_OVERRIDE").val("cbus");
	$("#action").val("buy");
	$("#price").val("100");
	$("#SDHYAllocationMethod").val("security");
	$("#COREAllocationMethod").val("security");
	$("#IDCPrice").html("");
	
	$(".secRestriction, .currHoldings, .secPctHoldings, .tickerPctHoldings").each(function() {
		$(this).html("-");
	});
	$(".aggRestriction").each(function() {
		$(this).html("0");
	});
	$(".minPc, .noteCell").each(function() {
		$(this).html("");
	});
	
	
	clearBBGTable();
	clearNewIssueTable();
	clearCUSIP(null);
	
	//total allocations and holdings
	$("#SDHYTotalAllocation").html("0");
	$("#SDHYTotalSecHoldings").html("0");
	$("#CORETotalAllocation").html("0");
	$("#CORETotalSecHoldings").html("0");
	$("#totalAllocation").html("0");
	$("#totalSecHoldings").html("0");
	
	//clear yield analysis table...or just hide
	/*$("#yieldAnalysis").css("display","none");
	$("#displayYieldAnaysis").css("display","block");*/
	$("#hideLink").click();
	
	//REMOVE RESTRICTION HIGHLIGHTING
	$(".secRestriction, .aggRestriction").each(function() {
		$(this).css("background-color", $("td:first", $(this).parent()).css("background-color"));
	});
}

function clearCUSIP(strategy) {
	
	if (strategy == null) {
		$("#tradeTicketDashSDHY tr, #tradeTicketDashCORE tr").each(function() {			
			portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
			$("#" + portCode + "PctRelativeToTarget").html("-");
			$("#" + portCode + "ActualAllocation").html($("#" + portCode + "AllocationOverride").text() == "" ? 0 : $("#" + portCode + "AllocationOverride").text());
			$("#" + portCode + "ProFormaSecHoldingsPct").html("-");
			$("#" + portCode + "ProFormaTickerHoldingsPct").html("-");
		});
	} else if (strategy == "SDHY") {
		$("#tradeTicketDashSDHY tr").each(function() {
			portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
			$("#" + portCode + "PctRelativeToTarget").html("-");
			$("#" + portCode + "ActualAllocation").html($("#" + portCode + "AllocationOverride").text() == "" ? 0 : $("#" + portCode + "AllocationOverride").text());
			$("#" + portCode + "ProFormaSecHoldingsPct").html("-");
			$("#" + portCode + "ProFormaTickerHoldingsPct").html("-");
		});		
	} else { //any core strategy
		//check strategy first
		$("#tradeTicketDashCORE tr").each(function() {
			portCode = String($(this).attr("id")).substr(0, String($(this).attr("id")).length - 3); //3 for "row"
			if ($("#" + portCode + "Strategy").text() == strategy) {
				$("#" + portCode + "PctRelativeToTarget").html("-");
				$("#" + portCode + "ActualAllocation").html($("#" + portCode + "AllocationOverride").text() == "" ? 0 : $("#" + portCode + "AllocationOverride").text());
				$("#" + portCode + "ProFormaSecHoldingsPct").html("-");
				$("#" + portCode + "ProFormaTickerHoldingsPct").html("-");
			}
		});
	}
	
}



function openErrorDetails(errorMsg) {
	window.open("/TradeTicketWeb/errorMessage.jsp?errorMessage=" + errorMsg);
}

function openUnexpectedErrorDetails(html) {
	window.open("/TradeTicketWeb/unexpectedError.jsp","_blank").document.write(html);
}









