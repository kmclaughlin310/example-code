package com.sky.tt.restriction.aggregate;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.restrictionutils.PortfolioMarketValue;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.SecurityRatingCalculator;

public class AggregateRatingConcentrationRestriction extends AggregateRestriction {
	
	private static final Logger log = Logger.getLogger(AggregateRatingConcentrationRestriction.class);
	
	private static final String SECURITY_RATING_CALCULATOR_PARAMETER_NAME = "SecurityRatingCalculator"; // parameter to indicate which class to use as the rating calculator
	private static final String INCLUDE_EPU_RATINGS_PARAMETER_NAME = "IncludeEPURatings";
	private static final String INCLUDE_FITCH_RATING_PARAMETER_NAME = "IncludeFitchRating";
	private static final String CHECK_VALUE_PARAMETER_NAME = "CheckValue";
	private static final String CHECK_INEQUALITY_PARAMETER_NAME = "CheckInequality";
	
	protected SecurityRatingCalculator calculator;
	protected double checkValue;
	protected Inequality checkInequality;
	protected boolean includeEPURatings = false;
	protected boolean includeFitchRating = true;
	
	//private static final Logger log = Logger.getLogger(AggregateRatingConcentrationRestriction.class);

	public AggregateRatingConcentrationRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		
		super.init();	
		
		calculator = (SecurityRatingCalculator) Class.forName(parameterMap.get(SECURITY_RATING_CALCULATOR_PARAMETER_NAME).toString()).newInstance();
		checkValue = Double.parseDouble(parameterMap.get(CHECK_VALUE_PARAMETER_NAME).toString());
		checkInequality = Inequality.getInequality(parameterMap.get(CHECK_INEQUALITY_PARAMETER_NAME).toString());
		
		if (parameterMap.containsKey(INCLUDE_EPU_RATINGS_PARAMETER_NAME)) {
			includeEPURatings = (parameterMap.get(INCLUDE_EPU_RATINGS_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
		
		if (parameterMap.containsKey(INCLUDE_FITCH_RATING_PARAMETER_NAME)) {
			includeFitchRating = (parameterMap.get(INCLUDE_FITCH_RATING_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
	
	}

	public String restrictionApplies(Security security, Portfolio portfolio) {
		//return arbitrary string if applies to security;  i.e. if checking CCC concentration, returns true if average rating >= 17 (NAIC example)
		//returning null implies the restriction does not apply to the security
		
		
		double rating = 0;
		try {
			rating = calculator.getSecurityRating(security, includeEPURatings, includeFitchRating);  
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return "continue check";
		}
		
		switch (checkInequality) {
		case LT:
			return (rating < checkValue ? "continue check" : null);
		case GT:
			return (rating > checkValue ? "continue check" : null);
		case LTE:
			return (rating <= checkValue ? "continue check" : null);
		case GTE:
			return (rating >= checkValue ? "continue check" : null);
		case EQ:
			return (rating == checkValue ? "continue check" : null);
		case NE:
			return (rating != checkValue ? "continue check" : null);
		default:
			return "continue check";	
		} 
		
	}

	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity, double estimatedPrice) {
		try {
			//returns % of % limit, i.e. if max allowed percentage is 5% and the current concentration is 4%, the result of this method is 80%
			//tradeMktVal is simply market value of buy or sell
			
			//IMPORTANT: currently assuming all restrictions are inclusive of cash; if a restriction was ex-cash, it would need to be checked either way 
			//^example for triple C max restriction: selling a higher quality security would increase the concentration of CCC if the portfolio was viewed ex-cash, so would need to check the restriction either way 
					
			
			//only buys apply since it's a max percent restriction i.e. wouldn't need to check restriction if it's a sell
			if (action.equalsIgnoreCase("sell") || restrictionApplies(security, portfolio) == null) {
				return 0;
			}
			
			//public static double getRestrictedPortionMktVal(Portfolio portfolio, String mktValueSQLFunctionName, Inequality checkInequality, Object checkValue)
			double restrictedPortionPortMktVal;
			double totalPortMktVal;
			
			//log.debug("get restricted portion start");
			restrictedPortionPortMktVal = PortfolioMarketValue.getRestrictedPortionMktVal(portfolio, mktValueSQLFunctionName, checkInequality, checkValue, true);
			//log.debug("get restricted portion end");
			restrictedPortionPortMktVal = restrictedPortionPortMktVal + ((quantity * security.getQuantityFactor()) * (estimatedPrice + Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString())) / security.getValuationFactor()); 
			
			//if excash, would need to subtract market value of trade for a sell and add market value of trade for a buy; always a buy for this restriction
			totalPortMktVal = PortfolioMarketValue.getTotalMarketValue(portfolio, exCash);
			
			//returns % of limit of the restricted portion
			return (restrictedPortionPortMktVal / totalPortMktVal * 100) / restrictionLimit * 100 ;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}

}
