package com.sky.tt.restriction.aggregateval;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.AggregateValRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class AggregateValIssuerOutRestriction extends AggregateValRestriction {
	private static final Logger log = Logger.getLogger(AggregateValIssuerOutRestriction.class);
	public AggregateValIssuerOutRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception { 
		super.init();		
	}

	@Override
	public double checkRestriction(Security security, Portfolio portfolio, String action, double quantity) {		
		try {
			if (action.equalsIgnoreCase("sell")) {
				return 0;
			}
			
			//select sum(HoldingsSumColumn) from CustomTradeTicket.vCurrentHoldings where HoldingsFilterField = valueof(SecurityFilterField);
			
			double denominator = Double.parseDouble(security.getValue(denominatorField).toString()); //such as issue outstanding, issuer outstanding; all of which can come from the BBG fields
			double numerator = 0;		
			
			GenericFilter filter = new GenericFilter();
			filter.addFilterClause(new FilterClause("PortfolioID", FilterClause.FieldComparator.EQ, portfolio.getPortfolioID()));
			
			//check if issue size = issuer amount outstanding; if it does, numerator should only include holdings in this specific issue and not any other issues with the same ticker (more conservative)
			//see ticker ACASPO for example (as of 1/30/15)
			//this check is why new restriction type was created and not considered generic
			if (Math.round(Double.parseDouble(security.getValue(SecurityField.AMT_ISSUED).toString()) / 1000.0) * 1000.0 == Math.round(Double.parseDouble(security.getValue(SecurityField.ISSUER_OUT).toString()) / 1000.0) * 1000.0) {
				filter.addFilterClause(new FilterClause("Symbol", FilterClause.FieldComparator.EQ, security.getValue(SecurityField.CUSIP).toString()));
			} else {
				filter.addFilterClause(new FilterClause("Ticker", FilterClause.FieldComparator.EQ, security.getValue(SecurityField.TICKER).toString()));
			}
			
			try {
				numerator = TableQuery.getSingleSum("CustomTradeTicket.CurrentHoldings", holdingsSumColumn, filter);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				return 999;
			}
			
			numerator = numerator + (quantity * security.getQuantityFactor());
	
			return (numerator / denominator * 100) / restrictionLimitPct * 100;
		} catch (Exception e) {
			log.error(e);
			return 999;
		} 
	}

}
