package com.sky.tt.security.ratingcounter;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton.RatingType;

public class ARORatingsCounter implements SecurityRatingCounter{

	public int getSecurityRatingsCount(Security security, boolean includeEPURatings, boolean includeFitch) throws TradeTicketDBException {
		
		int ratingsCount = 0;
		double spRating = 0;
		double mdyRating = 0;
		double fitchRating = 0;
		
		RatingConverterSingleton converter = RatingConverterSingleton.getInstance();
		
		spRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_SP, includeEPURatings);
		mdyRating = converter.getNumericSecurityRating(security, RatingType.MOODY, SecurityField.RAW_MOODY, includeEPURatings);
		fitchRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_FITCH, includeEPURatings);
		
		//System.out.println(spRating + " " + mdyRating + " " + fitchRating);
		
		if (includeFitch) {
			ratingsCount = (fitchRating > 0 ? 1 : 0);
		}
		
		ratingsCount = ratingsCount + (spRating > 0 ? 1 : 0) + (mdyRating > 0 ? 1 : 0);

		return ratingsCount;
	}

}
