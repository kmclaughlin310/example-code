package com.sky.tt.db.connection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCUtil {

	
	public static final void closeEverything(ResultSet rs, Statement stmt, Connection conn) {
		
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException ignored) {}
		}
		
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException ignored) {}
		}
		
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException ignored) {}
		}
		
	}
	
}