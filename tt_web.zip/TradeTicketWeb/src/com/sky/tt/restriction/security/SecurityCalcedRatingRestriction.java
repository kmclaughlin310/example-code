package com.sky.tt.restriction.security;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.ratingcalc.SecurityRatingCalculator;
import com.sky.tt.security.Security;

public class SecurityCalcedRatingRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityCalcedRatingRestriction.class);
	private static final String SECURITY_RATING_CALCULATOR_PARAMETER_NAME = "SecurityRatingCalculator"; // parameter to indicate which class to use as the rating calculator
	private static final String LIMIT_VALUE_PARAMETER_NAME = "LimitValue";
	private static final String INEQUALITY_PARAMETER_NAME = "InequalitySymbol";
	private static final String INCLUDE_EPU_RATINGS_PARAMETER_NAME = "IncludeEPURatings";
	private static final String INCLUDE_FITCH_RATING_PARAMETER_NAME = "IncludeFitchRating";
	
	protected SecurityRatingCalculator calculator;
	protected double limitValue;
	protected Inequality inequal;
	protected boolean includeEPURatings = false;
	protected boolean includeFitchRating = true;
	
	public SecurityCalcedRatingRestriction(int restrictionId) {
		super(restrictionId);	
	}
	
	
	@Override
	public void init() throws Exception { 		
		super.init();	
		
		calculator = (SecurityRatingCalculator) Class.forName(parameterMap.get(SECURITY_RATING_CALCULATOR_PARAMETER_NAME).toString()).newInstance();
		limitValue = Double.parseDouble(parameterMap.get(LIMIT_VALUE_PARAMETER_NAME).toString());
		inequal = Inequality.getInequality((parameterMap.get(INEQUALITY_PARAMETER_NAME).toString()));
		
		if (parameterMap.containsKey(INCLUDE_EPU_RATINGS_PARAMETER_NAME)) {
			includeEPURatings = (parameterMap.get(INCLUDE_EPU_RATINGS_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
		
		if (parameterMap.containsKey(INCLUDE_FITCH_RATING_PARAMETER_NAME)) {
			includeFitchRating = (parameterMap.get(INCLUDE_FITCH_RATING_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}

	}

	public boolean checkRestriction(Security security, Portfolio portfolio) { //portfolio is not used
		try {
			//RETURN TRUE IF THERE IS A VIOLATION		
			//numeric value
			double rating = 0;
			try {
				rating = calculator.getSecurityRating(security, includeEPURatings, includeFitchRating);
				restrictionResultText = calculator.getSecurityRatingText(rating);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.error(e);
				restrictionTested = false;
				restrictionResult = true;
				return true;
			}
			

			switch (inequal) {
				case LT:
					restrictionResult = (rating >= limitValue);
					break;
				case GT:
					restrictionResult = ( rating <= limitValue);
					break;
				case LTE:
					restrictionResult = (rating > limitValue);
					break;
				case GTE:
					restrictionResult = (rating < limitValue);
					break;
				default:
					restrictionResult = true;
			}
			
			restrictionTested = true;
			return restrictionResult;
			
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 
		
	}


}

