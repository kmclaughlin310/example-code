package com.sky.tt.handler;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.restriction.SecurityRestrictionChecker;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityConverter;
import com.sky.tt.security.SecurityField;
import com.sky.util.ErrorHandlingUtility;

public class GoalSeekFunctionality extends JSONHandlerServlet {

	/**
	 * 	
	 */
	private static final long serialVersionUID = -663257960356994323L;
	
	private static final String DETAILS_PORTCODE_COL_NAME = "PortfolioCode";
	private static final String DETAILS_MV_COL_NAME = "MarketValueAI";
	private static final String TT_ACTION = "action";  //buy or sell
	private static final String TT_PRICE = "price";
	private static final String TT_NAV_ADJUST = "NAVAdjustment";
	private static final String TT_ALLOCATION_OVERRIDE = "AllocationOverride";
	
	private static final Logger log = Logger.getLogger(GoalSeekFunctionality.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject results = new JSONObject();
		
		String jsonStrInput = request.getParameter("jsonString");
		JSONObject inputObj = new JSONObject(jsonStrInput);		
		
		//create security and get security data
		JSONArray secArray = new JSONArray(inputObj.get("SecurityData").toString());
		JSONObject tempObj = new JSONObject();
		for (String k : secArray.getJSONObject(0).keySet()) {
			tempObj.put(k, secArray.getJSONObject(0).get(k));
		}
		
		SecurityConverter converter = new SecurityConverter();
		Security security = converter.convertBBGMapToSecurity(tempObj.toString());
		String cusip = security.getValue(SecurityField.CUSIP).toString();
		String ticker = security.getValue(SecurityField.TICKER).toString();
		double accrInt = Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString());
		
		//get other necessary fields
		String action = inputObj.getString(TT_ACTION);
		double price = inputObj.getDouble(TT_PRICE);
		
		//put strategies/allocation method into map
		JSONArray goalSeekArray = new JSONArray(inputObj.get("GoalSeekData").toString());
		Map<String, String> strategies = new HashMap<String, String>(); //map strategy, method i.e. SDHY, Security
		double targetAllocationQuant = 0;
		for (String k : goalSeekArray.getJSONObject(0).keySet()) {
			if (k.equalsIgnoreCase("adjustedTotalAllocationInput")) {
				targetAllocationQuant = Double.parseDouble(goalSeekArray.getJSONObject(0).get(k).toString());
			} else {
				if (goalSeekArray.getJSONObject(0).get(k).toString().equalsIgnoreCase("SDHY")) {
					strategies.put(goalSeekArray.getJSONObject(0).get(k).toString(), inputObj.getString("SDHYAllocationMethod"));
				} else {
					strategies.put(goalSeekArray.getJSONObject(0).get(k).toString(), inputObj.getString("COREAllocationMethod"));
				}
			}
		}
		
		Map<String, Map<String, Double>> portsToBeAllocated = new HashMap<String, Map<String, Double>>(); //map portcode to current weight and holdings mkt val
		Map<String, Double> portMap = new HashMap<String, Double>();
		
		MarketValueSingleton singleton = null;		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			results.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return results;
		}
		
		Map<Integer, Map<String, Object>> portDetails = new HashMap<Integer, Map<String, Object>>();
		String portCode = null;
		double portMktVal = 0;
		double adjPortMktVal = 0;
		double portHoldingMktVal = 0;
		double portHoldingsPct = 0;
		double currHoldingsMktVal = 0; //total holdings of portfolios to be allocated
		double totalPortMktVal = 0; //total of market values of portfolios to be allocated
		int portID = 0;
		double overrideQuantity = 0; //to be subtracted from allocation goal
		Map<String, Object> secRestResults = new HashMap<String, Object>();
		
		for (String strategy : strategies.keySet()) {
			portDetails = singleton.getStrategyPortfolioDetails(strategy);
			secRestResults = SecurityRestrictionChecker.checkStrategyRestrictions(security, strategy);
			
			for (Integer id : portDetails.keySet()) { //only getting port details for the specified strategy, so no longer need to check
				portCode = portDetails.get(id).get(DETAILS_PORTCODE_COL_NAME).toString();
				portID = id;
				
				//check sec restriction and if sale quant must be greater than zero
				if (!(secRestResults.containsKey(portCode + "SecurityRestriction") && secRestResults.get(portCode + "SecurityRestriction").toString().equalsIgnoreCase("true")) && !(action.equalsIgnoreCase("sell") && singleton.getSpecificSecurityHoldingsQuant(portID, cusip) <= 0.0)) {
					//if portfolio doesn't have a (valid) allocation override
					if (!(inputObj.has(portCode + TT_ALLOCATION_OVERRIDE) && ! inputObj.get(portCode + TT_ALLOCATION_OVERRIDE).toString().equals(""))) {
						portMktVal = Double.parseDouble(portDetails.get(id).get(DETAILS_MV_COL_NAME).toString());
						//portID = id;				
					
						if (inputObj.has(portCode + TT_NAV_ADJUST) && ! inputObj.get(portCode + TT_NAV_ADJUST).toString().equals("")) {
							adjPortMktVal = portMktVal + inputObj.getDouble((portCode + TT_NAV_ADJUST).toString());
						} else {
							adjPortMktVal = portMktVal;
						}
					
						if (strategies.get(strategy).equalsIgnoreCase("security")) {
							portHoldingMktVal = singleton.getSpecificSecurityHoldingsQuant(portID, cusip) * (price + accrInt) / security.getValuationFactor();
						} else { //ticker  
							portHoldingMktVal = singleton.getSpecificIssuerHoldingsMktVal(portID, ticker);
							//adjust for estimated price of trade ticket security passed in if there is a security holding
							if (singleton.getSpecificSecurityHoldingsQuant(portID, cusip) != 0) { 
								//take total ticker market value, subtract DB security held mkt val, add estimated price adjusted security mkt val
								portHoldingMktVal = portHoldingMktVal - singleton.getAllPortfolioSecHoldings().get(portID).get(cusip).getMarketValue() + (singleton.getSpecificSecurityHoldingsQuant(portID, cusip) * (price + accrInt) / security.getValuationFactor());
							}
						}
						currHoldingsMktVal = currHoldingsMktVal + portHoldingMktVal;
						totalPortMktVal = totalPortMktVal + adjPortMktVal;
						
						portHoldingsPct = portHoldingMktVal / adjPortMktVal * 100;
						portMap.put("holdingsWeight", portHoldingsPct);
						portMap.put("holdingsMktVal", portHoldingMktVal);	
						portMap.put("portMktVal", adjPortMktVal);
						portsToBeAllocated.put(portCode, portMap);
						portMap = new HashMap<String, Double>();
					} else {
						overrideQuantity = overrideQuantity + Double.parseDouble(inputObj.get(portCode + TT_ALLOCATION_OVERRIDE).toString());
					}
				}
			}
		}
		
		double goalAllocQuantity = targetAllocationQuant - overrideQuantity; //all in 1000s for cb
		double mktValToAllocate = (goalAllocQuantity * security.getQuantityFactor()) * (price + accrInt) / security.getValuationFactor();
		double targetAllocationWeight = getTargetAllocationWeight(action, portsToBeAllocated, currHoldingsMktVal, mktValToAllocate, totalPortMktVal);
		Map<String, Object> allocationResults = new HashMap<String, Object>();
		String resultString = null;
		
		DecimalFormat numFourDec = new DecimalFormat("#,###.0000");
		
		for (String strategy : strategies.keySet()) {
			allocationResults.put(strategy, numFourDec.format(targetAllocationWeight));
		}
		
		//all strategies not listed should be set to blank
		List<String> allStrategies = new ArrayList<String>();
		allStrategies.add("SDHY");
		allStrategies.add("CORECON");
		allStrategies.add("COREUNC");
		allStrategies.add("ENRG");
		for (String strat : allStrategies) {
			if (!allocationResults.containsKey(strat)) {
				allocationResults.put(strat, "");
			}
		}
		
		resultString = JSONStringConverter.getJSONForTTHoldings(allocationResults);
		results = new JSONObject(resultString);
		
		return results;
	}
	
	protected double getTargetAllocationWeight(String action, Map<String, Map<String, Double>> portsToAllocate, double currHoldingsMktVal, double mktValToAdd, double totalMktVal) {
		//inputs: 
		//market value of quantity to be added (ticker or security)
		//list of portfolios to be allocated to - market value
		double targetWeight = 0;
		
		targetWeight = action.equalsIgnoreCase("buy") ? (mktValToAdd + currHoldingsMktVal) / totalMktVal * 100 : (currHoldingsMktVal - mktValToAdd) / totalMktVal * 100;

		if (action.equalsIgnoreCase("buy")) {
			//find max holdingsWeight
			if (getMaxHoldingsWeight(portsToAllocate) != null) {
				double maxWeight = Double.parseDouble(getMaxHoldingsWeight(portsToAllocate).get("maxWeight").toString());
				String maxPortCode = getMaxHoldingsWeight(portsToAllocate).get("portCode").toString();		
				
				if (maxWeight > targetWeight) {
					//recalv currHoldingsMktVal and totalMktVal
					currHoldingsMktVal = currHoldingsMktVal - portsToAllocate.get(maxPortCode).get("holdingsMktVal");
					totalMktVal = totalMktVal - portsToAllocate.get(maxPortCode).get("portMktVal");
					
					portsToAllocate.remove(maxPortCode);
					
					return getTargetAllocationWeight(action, portsToAllocate, currHoldingsMktVal, mktValToAdd, totalMktVal);
				} else {
					return targetWeight;
				}
			} else {
				return targetWeight;
			}
		} else { //sell
			//find min holdingsWeight
			if (getMinHoldingsWeight(portsToAllocate) != null) {
				double minWeight = Double.parseDouble(getMinHoldingsWeight(portsToAllocate).get("minWeight").toString());
				String minPortCode = getMinHoldingsWeight(portsToAllocate).get("portCode").toString();

				if (minWeight < targetWeight) {				
					//recalc currHoldingsMktVal and totalMktVal
					currHoldingsMktVal = currHoldingsMktVal - portsToAllocate.get(minPortCode).get("holdingsMktVal");
					totalMktVal = totalMktVal - portsToAllocate.get(minPortCode).get("portMktVal");
					
					portsToAllocate.remove(minPortCode);

					return getTargetAllocationWeight(action, portsToAllocate, currHoldingsMktVal, mktValToAdd, totalMktVal);
				} else {
					return targetWeight;
				}
			} else {
				return targetWeight;
			}
		}	
	}
	
	protected Map<String, Object> getMaxHoldingsWeight(Map<String, Map<String, Double>> portsToAllocate) {
		double maxWeight = 0;
		Map<String, Object> maxMap = new HashMap<String, Object>();
		
		for (String portCode : portsToAllocate.keySet()) {
			if (Double.parseDouble(portsToAllocate.get(portCode).get("holdingsWeight").toString()) > maxWeight) {
				maxWeight = Double.parseDouble(portsToAllocate.get(portCode).get("holdingsWeight").toString());
				maxMap.put("portCode", portCode);
				maxMap.put("maxWeight", maxWeight);
			}
		}
		
		return maxWeight == 0 ? null : maxMap;		
	}
	
	protected Map<String, Object> getMinHoldingsWeight(Map<String, Map<String, Double>> portsToAllocate) {
		double minWeight = 1000;
		Map<String, Object> minMap = new HashMap<String, Object>();
		
		for (String portCode : portsToAllocate.keySet()) {
			if (Double.parseDouble(portsToAllocate.get(portCode).get("holdingsWeight").toString()) < minWeight) {
				minWeight = Double.parseDouble(portsToAllocate.get(portCode).get("holdingsWeight").toString());
				minMap.put("portCode", portCode);
				minMap.put("minWeight", minWeight);
			}
		}
		
		return minWeight == 0 ? null : minMap;		
	}

}
