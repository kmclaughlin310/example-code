package com.sky.tt.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.write.TableWrite;
import com.sky.util.ErrorHandlingUtility;

public class UpdateSavedTradesTable extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 300457826723689388L;
	private static final Logger log = Logger.getLogger(UpdateSavedTradesTable.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject results = new JSONObject();
		
		//log.debug(request.getParameter("jsonString"));
		JSONObject inputObj = new JSONObject(request.getParameter("jsonString").toString().replace("\\", "/"));
		String action = inputObj.getString("action");
		int tradeID = Integer.parseInt(inputObj.getString("tradeID"));

		
		if (action.equalsIgnoreCase("delete")) {
			try {
				@SuppressWarnings("unused")
				int id = TableWrite.deleteRowsByID("CustomTradeTicket.SavedTrades", "SavedTradeID", tradeID);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				results.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return results;
			} catch (FilterException e) {
				log.error(e);
				e.printStackTrace();
				results.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return results;
			} 
			results.put("message", "Saved trade successfully deleted.");
		} else if (action.equalsIgnoreCase("update")) {
			Map<String, Object> updateData = new HashMap<String, Object>();
			updateData.put("PMValuationComment", inputObj.getString("valuationComment"));
			updateData.put("TraderComment", inputObj.getString("traderComment"));
			
			try {
				@SuppressWarnings("unused")
				int id = TableWrite.updateRowByID("CustomTradeTicket.SavedTrades", updateData, "SavedTradeID", tradeID);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				results.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return results;
			} catch (FilterException e) {
				log.error(e);
				e.printStackTrace();
				results.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return results;
			}
			results.put("message", "Saved trade successfully updated.");
		}
		
		return results;
	}

}
