package com.sky.tt.security;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;

public class APXIndustryLookupSingleton {

	private static final Logger log = Logger.getLogger(APXIndustryLookupSingleton.class);
	
	private static Map<String, String> industryGroupLookup;
	private static Map<String, String> industrySectorLookup;
	private static Map<String, String> bbgSectorLookup;
	private static Map<String, String> bbgIndustryLookup;
	
	private static final String APX_INDUSTRY_TABLE = "AdvApp.vIndustryGroup";
	private static final String APX_SECTOR_TABLE = "AdvApp.vIndustrySector";
	private static final String BBG_INDUSTRY_MAP_TABLE = "CustomTradeTicket.BloombergIndustryMap";
	
	private static final String APX_INDUSTRY_CODE_COLUMN = "IndustryGroupCode";
	private static final String APX_INDUSTRY_NAME_COLUMN = "IndustryGroupName";
	private static final String APX_SECTOR_CODE_COLUMN = "SectorCode";
	private static final String APX_SECTOR_NAME_COLUMN = "SectorName";
	
	private static final String BBG_INDUSTRY_COLUMN = "BBGIndustryCode";
	private static final String BBG_INDUSTRY_MAP_COLUMN = "IndustryCode";
	private static final String BBG_SECTOR_MAP_COLUMN = "SectorCode";
	
	private static final String UNMAPPED_SECTOR = "256";
	private static final String UNMAPPED_INDUSTRY = "-2";
	
	private static final long REFRESH_INTERVAL = 1440;
	private Date timeAtRefresh = null;
	
	
	private static class SingletonHolder {
		private static final APXIndustryLookupSingleton INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new APXIndustryLookupSingleton();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	private APXIndustryLookupSingleton() throws TradeTicketDBException {
		createIndustryLookups();
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	private void createIndustryLookups() throws TradeTicketDBException {
		List<Map<String, Object>> groupDBList = null;
		List<Map<String, Object>> sectorDBList = null;
		List<Map<String, Object>> bbgIndustryDBList = null;
		
		industryGroupLookup = new HashMap<String, String>();
		industrySectorLookup = new HashMap<String, String>();
		bbgSectorLookup = new HashMap<String, String>();
		bbgIndustryLookup = new HashMap<String, String>();
		
		
		try {
			groupDBList = TableQuery.getRows(APX_INDUSTRY_TABLE);
		} catch (TradeTicketDBException e) {
			log.error("Error getting APX Industry list.", e);
			throw e;
		}
		
		for (Map<String, Object> group : groupDBList) {
			industryGroupLookup.put(group.get(APX_INDUSTRY_CODE_COLUMN).toString(), group.get(APX_INDUSTRY_NAME_COLUMN).toString());
		}
		
		try {
			sectorDBList = TableQuery.getRows(APX_SECTOR_TABLE);
		} catch (TradeTicketDBException e) {
			log.error("Error getting APX Sector list.", e);
			throw e;
		}
		
		for (Map<String, Object> sector : sectorDBList) {
			industrySectorLookup.put(sector.get(APX_SECTOR_CODE_COLUMN).toString(), sector.get(APX_SECTOR_NAME_COLUMN).toString());
		}
		
		try {
			bbgIndustryDBList = TableQuery.getRows(BBG_INDUSTRY_MAP_TABLE);
		} catch (TradeTicketDBException e) {
			log.error("Error getting BBG Industry Map.", e);
			throw e;
		}
		
		for (Map<String, Object> bbgMap : bbgIndustryDBList) {
			bbgSectorLookup.put(bbgMap.get(BBG_INDUSTRY_COLUMN).toString(), bbgMap.get(BBG_SECTOR_MAP_COLUMN).toString());
			bbgIndustryLookup.put(bbgMap.get(BBG_INDUSTRY_COLUMN).toString(), bbgMap.get(BBG_INDUSTRY_MAP_COLUMN).toString());
		}
		
		
	}
	
	public String getIndustryGroup(String groupCode) {
		checkStaleness();
		return industryGroupLookup.containsKey(groupCode) ? industryGroupLookup.get(groupCode) : null;
	}
	
	public String getIndustrySector(String sectorCode) {
		checkStaleness();
		return industrySectorLookup.containsKey(sectorCode) ? industrySectorLookup.get(sectorCode) : null;
	}

	public String getIndustryGroupCodeFromBBG(String bbgIndustry) {
		checkStaleness();
		return bbgIndustryLookup.containsKey(bbgIndustry) ? bbgIndustryLookup.get(bbgIndustry) : UNMAPPED_INDUSTRY;
	}
	
	public String getIndustrySectorCodeFromBBG(String bbgIndustry) {
		checkStaleness();
		return bbgSectorLookup.containsKey(bbgIndustry) ? bbgSectorLookup.get(bbgIndustry) : UNMAPPED_SECTOR;
	}
	
	public static APXIndustryLookupSingleton getInstance() throws TradeTicketDBException { 
		return SingletonHolder.INSTANCE;	
	}
	
	public void checkStaleness() {
		if (timeAtRefresh != null) {
			Date now = Calendar.getInstance().getTime();
			long diff = (now.getTime() - timeAtRefresh.getTime()) / (60 * 1000);
			if (diff >= REFRESH_INTERVAL) {
				SingletonHolder.INSTANCE.forceRefresh();
			}
		}
	}

	private void forceRefresh() {
		log.debug("APX industry lookup singleton refreshed.");
		
		try {
			createIndustryLookups();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
		}

		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	public static void forceSingletonRefresh() {
		SingletonHolder.INSTANCE.forceRefresh();
	}
}

