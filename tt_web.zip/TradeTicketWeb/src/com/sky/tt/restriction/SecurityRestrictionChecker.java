package com.sky.tt.restriction;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.filter.OrderByClause;
import com.sky.tt.db.filter.FilterClause.FieldComparator;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.handler.JSONHandlerDashNotes;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.security.Security;

public class SecurityRestrictionChecker {
	private static final Logger log = Logger.getLogger(SecurityRestrictionChecker.class);
	public static Map<String, Object> checkRestrictions(Security security, Integer portID) {
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		//what if there are no restrictions??
		List<Map<String, Object>> secRestrictionList = null;
		SecurityRestriction restriction = null;
		Portfolio portfolio = null;
		Map<String, Object> results = new HashMap<String, Object>();
		GenericFilter filter = new GenericFilter();
		
		
		if (portID != null) {
			if (singleton.isInRestrictionGroup(portID)) {
				filter.addFilterClause(new FilterClause("PortfolioID", FieldComparator.EQ, singleton.getParentPortfolioGroup(portID)));
			} else {
				filter.addFilterClause(new FilterClause("PortfolioID", FieldComparator.EQ, Integer.valueOf(portID)));
			}
			
			try {
				secRestrictionList = TableQuery.getRows("CustomTradeTktRestriction.vSecurityRestrictionList", filter);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.error(e);
				return null;
			}
			if (secRestrictionList.isEmpty()) {
				return results;
			}
		} else {
			try {
				secRestrictionList = TableQuery.getRows("CustomTradeTktRestriction.vSecurityRestrictionList");
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.error(e);
				return null;
			}
		}
		
		for(Map<String, Object> rest : secRestrictionList) {
				Class<SecurityRestriction> clazz = null;
				try {
					clazz = (Class<SecurityRestriction>) Class.forName(rest.get("JavaClassName").toString());
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				
				Constructor<SecurityRestriction> ctor = null;
				try {
					ctor = clazz.getConstructor(int.class);
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (SecurityException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				try {
					restriction = ctor.newInstance(Integer.parseInt(rest.get("SecurityRestrictionID").toString()));
				} catch (NumberFormatException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InstantiationException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalAccessException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InvocationTargetException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} 
				
				try {
					restriction.init();
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				if (singleton.isRestrictionGroup(Integer.parseInt(rest.get("PortfolioID").toString()))) {
					for (int member : singleton.getPortfolioGroupMembers(Integer.parseInt(rest.get("PortfolioID").toString()))) {
						if (! results.containsKey(singleton.getPortCode(member) + "SecurityRestriction") || (results.containsKey(singleton.getPortCode(member) + "SecurityRestriction") && results.get(singleton.getPortCode(member) + "SecurityRestriction").toString().equalsIgnoreCase("false"))) {
							results.put(singleton.getPortCode(member) + "SecurityRestriction", (restriction.checkRestriction(security, portfolio) == false ? "false" : "true"));
						}
					}
				} else if (! results.containsKey(rest.get("PortfolioCode").toString() + "SecurityRestriction") || (results.containsKey(rest.get("PortfolioCode").toString() + "SecurityRestriction") && results.get(rest.get("PortfolioCode").toString() + "SecurityRestriction").toString().equalsIgnoreCase("false"))) {
					results.put(rest.get("PortfolioCode").toString() + "SecurityRestriction", (restriction.checkRestriction(security, portfolio) == false ? "false" : "true"));
				}
		}	
		
		return results;		
	}
	
	public static Map<String, Object> checkStrategyRestrictions(Security security, String strategy) { //CORE, SDHY, ENRG; strategy flag is for CORE only to indicate constrained or unconstrained 
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		List<Map<String, Object>> secRestrictionList = null;
		SecurityRestriction restriction = null;
		Portfolio portfolio = null;
		Map<String, Object> results = new HashMap<String, Object>();
		GenericFilter filter = new GenericFilter();
		
		filter.addFilterClause(new FilterClause("Strategy", FieldComparator.EQ, strategy));
		filter.addFilterClause(new FilterClause("Strategy", FieldComparator.ISNULL, null, false)); //or strategy = null
		
		try {
			secRestrictionList = TableQuery.getRows("CustomTradeTktRestriction.vSecurityRestrictionList", filter);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		for(Map<String, Object> rest : secRestrictionList) {
				Class<SecurityRestriction> clazz = null;
				try {
					clazz = (Class<SecurityRestriction>) Class.forName(rest.get("JavaClassName").toString());
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				Constructor<SecurityRestriction> ctor = null;
				try {
					ctor = clazz.getConstructor(int.class);
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (SecurityException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				try {
					restriction = ctor.newInstance(Integer.parseInt(rest.get("SecurityRestrictionID").toString()));
				} catch (NumberFormatException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InstantiationException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalAccessException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InvocationTargetException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} 
				
				try {
					restriction.init();
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}

				if (singleton.isRestrictionGroup(Integer.parseInt(rest.get("PortfolioID").toString()))) {
					for (int member : singleton.getPortfolioGroupMembers(Integer.parseInt(rest.get("PortfolioID").toString()))) {
						if (! results.containsKey(singleton.getPortCode(member) + "SecurityRestriction") || (results.containsKey(singleton.getPortCode(member) + "SecurityRestriction") && results.get(singleton.getPortCode(member) + "SecurityRestriction").toString().equalsIgnoreCase("false"))) {
							results.put(singleton.getPortCode(member) + "SecurityRestriction", (restriction.checkRestriction(security, portfolio) == false ? "false" : "true"));
						}
					}
				} else if (! results.containsKey(rest.get("PortfolioCode").toString() + "SecurityRestriction") || (results.containsKey(rest.get("PortfolioCode").toString() + "SecurityRestriction") && results.get(rest.get("PortfolioCode").toString() + "SecurityRestriction").toString().equalsIgnoreCase("false"))) {
					results.put(rest.get("PortfolioCode").toString() + "SecurityRestriction", (restriction.checkRestriction(security, portfolio) == false ? "false" : "true"));
				}
		}	
		
		return results;		
	}
	
	public static List<Map<String, Object>> getPortfolioRestrictionDetails(Security security, Integer portID) {
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		List<Map<String, Object>> secRestrictionList = null;
		SecurityRestriction restriction = null;
		Portfolio portfolio = null;

		List<Map<String, Object>> resultsList = new ArrayList<Map<String, Object>>();
		GenericFilter filter = new GenericFilter();
		
		if (singleton.isInRestrictionGroup(portID)) {
			filter.addFilterClause(new FilterClause("PortfolioID", FieldComparator.EQ, singleton.getParentPortfolioGroup(portID)));
		} else {
			filter.addFilterClause(new FilterClause("PortfolioID", FieldComparator.EQ, Integer.valueOf(portID)));
		}
		
		try {
			secRestrictionList = TableQuery.getRows("CustomTradeTktRestriction.vSecurityRestrictionDetailsList", filter);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}

		
		for(Map<String, Object> rest : secRestrictionList) {
				Class<SecurityRestriction> clazz = null;
				try {
					clazz = (Class<SecurityRestriction>) Class.forName(rest.get("JavaClassName").toString());
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				Constructor<SecurityRestriction> ctor = null;
				try {
					ctor = clazz.getConstructor(int.class);
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (SecurityException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				try {
					restriction = ctor.newInstance(Integer.parseInt(rest.get("SecurityRestrictionID").toString()));
				} catch (NumberFormatException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InstantiationException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalAccessException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InvocationTargetException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} 
				
				try {
					restriction.init();
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				Map<String, Object> resultsMap = new HashMap<String, Object>();
				resultsMap.put("RestrictionDescription", rest.get("SecurityRestrictionDescription"));
				resultsMap.put("RestrictionResult", restriction.checkRestriction(security,portfolio));
				resultsMap.put("DescriptionDetails", rest.get("Details1") == null ? "" : rest.get("Details2") == null ? rest.get("Details1") : rest.get("Details1").toString() + rest.get("Details2").toString());

				String restrictionList = restriction.getRestrictedListText();
				resultsMap.put("RestrictionList", (restrictionList == null) ? "" : restrictionList);
				
				String resultText = "";
				try {
					resultText = restriction.getRestrictionResultText();
				} catch (RestrictionException e) {
					log.error(e);
				}
				resultsMap.put("RestrictionResultText", (resultText == null) ? "" : resultText);
				resultsList.add(resultsMap);
				//results.put(rest.get("PortfolioCode").toString() + "SecurityRestriction", (restriction.checkRestriction(security, portfolio) == false ? "false" : "true"));
		}	
		
		return resultsList;		
	}
	
	public static List<Map<String, Object>> getRestrictionsForArchive(Security security) {
		List<Map<String, Object>> secRestrictionList = null;
		SecurityRestriction restriction = null;
		Portfolio portfolio = null;
		
		List<Map<String, Object>> allResults = new ArrayList<Map<String, Object>>();
		Map<String, Object> result = new HashMap<String, Object>();
		
		try {
			secRestrictionList = TableQuery.getRows("CustomTradeTktRestriction.vSecurityRestrictionList");
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		for(Map<String, Object> rest : secRestrictionList) {
				Class<SecurityRestriction> clazz = null;
				try {
					clazz = (Class<SecurityRestriction>) Class.forName(rest.get("JavaClassName").toString());
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				Constructor<SecurityRestriction> ctor = null;
				try {
					ctor = clazz.getConstructor(int.class);
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (SecurityException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				try {
					restriction = ctor.newInstance(Integer.parseInt(rest.get("SecurityRestrictionID").toString()));
				} catch (NumberFormatException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InstantiationException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalAccessException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} catch (InvocationTargetException e) {
					e.printStackTrace();
					log.error(e);
					return null;
				} 
				
				try {
					restriction.init();
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e);
					return null;
				}
				
				result.put("PortfolioID", rest.get("PortfolioID"));
				result.put("RestrictionID", rest.get("SecurityRestrictionID"));
				result.put("RestrictionType", "SecurityRestrictionList");
				result.put("Result", restriction.checkRestriction(security, portfolio) == false ? "false" : "true");
				result.put("PortfolioCode", rest.get("PortfolioCode"));
				result.put("RestrictionDesc", rest.get("SecurityRestrictionDescription"));
				
				allResults.add(result);
				result = new HashMap<String, Object>();
		}

		return allResults;		
	}

}
