package com.sky.tt.handler;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterClause;
import com.sky.tt.db.filter.GenericFilter;
import com.sky.tt.db.filter.OrderByClause;
import com.sky.tt.db.query.MoxyTableQuery;
import com.sky.util.ErrorHandlingUtility;

public class GetCompletedMoxyTrades extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4529552322527877939L;
	private static final Logger log = Logger.getLogger(GetCompletedMoxyTrades.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		//will handle backfilling ALL trades as well - parameter will be either completedDaysBack or allDaysBack to specify
		boolean completedOnly = request.getParameter("completedDaysBack") != null;
		JSONObject returnObj = new JSONObject();
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		String today = sdf.format(date);
		String orderDateRestr = null;
		String busDaysBack = completedOnly ? request.getParameter("completedDaysBack") : request.getParameter("allDaysBack");
		DecimalFormat numNoDec = new DecimalFormat("#,###");
		DecimalFormat numThreeDec = new DecimalFormat("#,###.000");
		
		try {
			orderDateRestr = MoxyTableQuery.getScalarFunctionResult("dbo.fCustGetPrevBusinessDay('" + today + "'," + busDaysBack + ")").toString();
		} catch (TradeTicketDBException e1) {
			log.error(e1);
			e1.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e1));
			return returnObj;
		}
		
		/* select * from dbo.vcustblotterview WHERE OrderStatus = 'C' AND AllocStatus = 'Y'
		and OrderDate > dbo.fCustGetPrevBusinessDay(GETDATE(),2)
		order by case OrderStatus when 'c' then 1 when 'w' then 2 when 'p' then 3 when 'n' then 4 end asc, OrderDate asc */
		
		GenericFilter filter = new GenericFilter();
		
		if (completedOnly) {
			filter.addFilterClause(new FilterClause("OrderStatus", FilterClause.FieldComparator.EQ, "C"));
			filter.addFilterClause(new FilterClause("AllocStatus", FilterClause.FieldComparator.EQ, "Y"));
		}
		filter.addFilterClause(new FilterClause("OrderDate", FilterClause.FieldComparator.GT, orderDateRestr));
		filter.addOrderByClause(new OrderByClause("case OrderStatus when 'c' then 1 when 'w' then 2 when 'p' then 3 when 'n' then 4 end", "asc"));
		filter.addOrderByClause(new OrderByClause("SettleDate", "asc"));
		List<Map<String, Object>> trades = null;
				
		try {
			trades = MoxyTableQuery.getRows("dbo.vcustblotterview", filter);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}
		
		String tableString = "";	
		SimpleDateFormat noFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		SimpleDateFormat USdate = new SimpleDateFormat("MM/dd/yyyy");
		Map<String, String> minorErrors = new HashMap<String, String>();
		
		for (Map<String, Object> trade : trades) {
			try {
				tableString = tableString + 
						"<tr  class='clickShowAllocations'><td class='centerAlign'>" + trade.get("OrderID") + "</td>" +
						"<td class='centerAlign'>" + trade.get("OrderStatus") + "</td>" +
						"<td class='centerAlign'><span style='font-size:12pt;'>" + (trade.get("AllocStatus").toString().equalsIgnoreCase("y") ? "&#9679;" : "&#9675;").toString() + "</span></td>" +
						"<td class='centerAlign'>" + trade.get("TranCode") + "</td>" +
						"<td class='centerAlign'>" + USdate.format(noFormat.parse(trade.get("OrderDate").toString())) + "</td>" +
						"<td class='centerAlign'>" + USdate.format(noFormat.parse(trade.get("SettleDate").toString())) + "</td>" +
						"<td class='centerAlign'>" + trade.get("Symbol") + "</td>" +
						"<td>" + trade.get("ShortName") + "</td>" + 
						"<td class='rightAlign'>" + numThreeDec.format(trade.get("Coupon")) + "</td>" +
						"<td class='centerAlign'>" + USdate.format(noFormat.parse(trade.get("MaturityDate").toString())) + "</td>" +
						"<td class='rightAlign'>" + numNoDec.format(trade.get("Target")) + "</td>" +
						"<td class='rightAlign'>" + numNoDec.format(trade.get("Working")) + "</td>" +
						"<td class='rightAlign'>" + numNoDec.format(trade.get("Completed")) + "</td>" +
						"<td class='rightAlign'>" + numThreeDec.format(trade.get("AvgPrice")) + "</td>" +
						"<td>" + trade.get("Broker") + "</td>" +
						"<td class='rightAlign'>" + numThreeDec.format(trade.get("EstPrice")) + "</td>" +
						"<td>" + trade.get("Limit") + "</td>" +
						"<td>" + trade.get("Instr") + "</td>" +
						"<td><a rel='tooltip' title='" + trade.get("InternalComment") + "'>" + (trade.get("InternalComment").toString().length() < 29 ? trade.get("InternalComment") : trade.get("InternalComment").toString().substring(0, 28) + "...").toString() + "</a></td>" +
						"<td class='centerAlign'>" + trade.get("CreatedBy") + "</td></tr>";
			} catch (ParseException e) {
				log.error(e);
				e.printStackTrace();
				minorErrors.put("minorError", "Parse error occurred.");
			}
		}
		
		String jsonStrOutput = "{\"Rows\":\"" + tableString + "\"}";
		returnObj = new JSONObject(jsonStrOutput);
		
		if (! minorErrors.isEmpty()) {
			for (String e : minorErrors.keySet()) {
				returnObj.put(e, minorErrors.get(e));
			}
		}
		return returnObj;
	}

}
