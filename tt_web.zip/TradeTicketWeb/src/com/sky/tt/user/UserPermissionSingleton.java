package com.sky.tt.user;


import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;



public class UserPermissionSingleton {
	
	private static final Logger log = Logger.getLogger(UserPermissionSingleton.class);
	private static List<Map<String, Object>> userPermissions;
	
	private static final int SUBMIT_TRADE_TASK_ID = 1;
	private static final int EDIT_CASH_SHEET_TASK_ID = 2;
	private static final int SETUP_SEC_TASK_ID = 3;
	private static final int SAVE_TRADE_TASK_ID = 4;
	
	private static final long REFRESH_INTERVAL = 1440;
	private Date timeAtRefresh = null;
	
	private static final String USER_PERMISSIONS_TABLE = "CustomTradeTicket.UserPermissions";
	
	private static class SingletonHolder {
		private static final UserPermissionSingleton INSTANCE;
		
		static {
			try {
				log.debug("Instance does not exist yet, creating a new one.");
				INSTANCE = new UserPermissionSingleton();
			} catch (TradeTicketDBException e) {
				log.error("Error initializing: " + e.getMessage(), e);
				throw new ExceptionInInitializerError(e);
			}
		}	
	}
	
	private UserPermissionSingleton() throws TradeTicketDBException {
		createPermissionsMap();
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	public List<Map<String, Object>> getUserPermissions() {
		checkStaleness();
		return userPermissions;
	}
	
	public boolean userCanSubmitTrades(int userID) {
		checkStaleness();
		for (Map<String, Object> permissions : userPermissions) {
			if (Integer.parseInt(permissions.get("UserID").toString()) == userID && Integer.parseInt(permissions.get("TaskID").toString()) == SUBMIT_TRADE_TASK_ID) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean userCanEditCashSheet(int userID) {
		checkStaleness();
		for (Map<String, Object> permissions : userPermissions) {
			if (Integer.parseInt(permissions.get("UserID").toString()) == userID && Integer.parseInt(permissions.get("TaskID").toString()) == EDIT_CASH_SHEET_TASK_ID) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean userCanSetupSecurity(int userID) {
		checkStaleness();
		for (Map<String, Object> permissions : userPermissions) {
			if (Integer.parseInt(permissions.get("UserID").toString()) == userID && Integer.parseInt(permissions.get("TaskID").toString()) == SETUP_SEC_TASK_ID) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean userCanSaveTrades(int userID) {
		checkStaleness();
		for (Map<String, Object> permissions : userPermissions) {
			if (Integer.parseInt(permissions.get("UserID").toString()) == userID && Integer.parseInt(permissions.get("TaskID").toString()) == SAVE_TRADE_TASK_ID) {
				return true;
			}
		}
		
		return false;
	}
	
	public static UserPermissionSingleton getInstance() throws TradeTicketDBException { //*check if static field is null, if so create an instance, otherwise return what is already there
		return SingletonHolder.INSTANCE;		
	}
	
	private void refresh() throws TradeTicketDBException {
		log.debug("User permission singleton refreshed.");
		

		createPermissionsMap();
		
		timeAtRefresh = Calendar.getInstance().getTime();
	}
	
	public static void forceSingletonRefresh() throws TradeTicketDBException {
		SingletonHolder.INSTANCE.refresh();
	}
	
	private void createPermissionsMap() throws TradeTicketDBException {
		userPermissions = TableQuery.getRows(USER_PERMISSIONS_TABLE);
	}
	
	public void checkStaleness() {
		if (timeAtRefresh != null) {
			Date now = Calendar.getInstance().getTime();
			long diff = (now.getTime() - timeAtRefresh.getTime()) / (60 * 1000);
			if (diff >= REFRESH_INTERVAL) {
				try {
					SingletonHolder.INSTANCE.refresh();
				} catch (TradeTicketDBException e) {
					log.error(e);
					e.printStackTrace();
				}
			}
		}
	}
	
	
}
