package com.sky.tt.handler;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.db.write.TableWrite;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.util.ErrorHandlingUtility;

public class RefreshHoldingsTableServlet extends JSONHandlerServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4649984927149254425L;
	private static final Logger log = Logger.getLogger(RefreshHoldingsTableServlet.class);

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		
		//EXEC CustomTradeTicket.pUpdateCurrentHoldings 1
		
		JSONObject result =  new JSONObject();
		Map<String, String> minorErrors = new HashMap<String, String>();
		
		Map<Integer, Object> inputParams = new HashMap<Integer, Object>();
		inputParams.put(1, 1);
		
		try {
			TableWrite.executeStoredProcNoReturn("CustomTradeTicket.pUpdateCurrentHoldings", inputParams);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			result.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return result;
		} catch (FilterException e) {
			log.error(e);
			e.printStackTrace();
			result.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return result;
		}
		
		String lastRunTime = "n/a";
		
		try {
			lastRunTime = TableQuery.getRows("CustomTradeTicket.CurrentHoldingsCacheTime").get(0).get("LastUpdatedDate").toString();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			minorErrors.put("minorError", "Error occurred while retrieving most recent holdings cache time.");
		}
		
		//force market value singleton to reset
		try {
			MarketValueSingleton.forceMarketValueSingletonRefresh();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			minorErrors.put("minorError", !minorErrors.isEmpty() ? minorErrors.get("minorError") : "" + " Error occurred while refreshing market value singleton.");
		}

		
		//newTimeStamp
		result.put("newTimeStamp", lastRunTime);
		
		if (! minorErrors.isEmpty()) {
			for (String e : minorErrors.keySet()) {
				result.put(e, minorErrors.get(e));
			}
		}
		
		return result;
	}

}
