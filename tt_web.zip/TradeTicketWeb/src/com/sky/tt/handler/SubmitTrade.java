package com.sky.tt.handler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.filter.FilterException;
import com.sky.tt.db.write.MoxyTableWrite;
import com.sky.tt.db.write.TableWrite;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.portfolio.MarketValueSingleton;
import com.sky.tt.restriction.AggregateRestrictionChecker;
import com.sky.tt.restriction.SecurityRestrictionChecker;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityConverter;
import com.sky.tt.security.SecurityField;
import com.sky.tt.user.UserNotFoundException;
import com.sky.tt.user.UserNotLoggedInException;
import com.sky.tt.user.UserSession;
import com.sky.tt.user.UserSessionException;
import com.sky.util.ErrorHandlingUtility;
import com.sky.util.JSONArraySort;

public class SubmitTrade extends JSONHandlerServlet {
	//servlet steps:
	//re-test restrictions
	//submit trade
	//archive trade

	/**
	 * 
	 */
	private static final long serialVersionUID = -3455986358082287750L;
	private static final String TT_ACTION = "action";  //buy or sell
	private static final String TT_PRICE = "price";
	private static final String TT_CUSIP = "cusip";
	private static final String TT_SEC_TYPE = "SECTYPE_OVERRIDE";
	private static final String TT_TOTAL_ALLOCATION = "totalTradeQuantity";
	private static final String TT_LIMIT_COMMENT = "tradeLimit";
	private static final String TT_TIMING_COMMENT = "tradeTiming";
	private static final String TT_OTHER_COMMENT = "tradeComments";
	
	private static final Logger log = Logger.getLogger(SubmitTrade.class);
	
	private static final String TRADE_ARCHIVE_TABLE = "CustomTradeTktArchive.Trade";
	private static final String ALLOCATIONS_ARCHIVE_TABLE = "CustomTradeTktArchive.Allocation";
	private static final String RESTRICTIONS_ARCHIVE_TABLE = "CustomTradeTktArchive.Restriction";

	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject returnObj = new JSONObject();
		
		int userId = 0;
		String moxyUserId = null;
		try {
			userId = UserSession.getUserSessionFromRequest(request).getUser().getUserID();
			moxyUserId = UserSession.getUserSessionFromRequest(request).getUser().getMOXYUserID();
		} catch (UserNotFoundException e2) {
			log.error(e2);
			e2.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e2));
			return returnObj;
		} catch (UserNotLoggedInException e2) {
			log.error(e2);
			e2.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e2));
			return returnObj;
		} catch (UserSessionException e2) {
			log.error(e2);
			e2.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e2));
			return returnObj;
		}
		
		MarketValueSingleton singleton = null;
		
		try {
			singleton = MarketValueSingleton.getInstance();
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			return null;
		}
		
		
		//STEP 1 - CHECK RESTRICTIONS!!		
		String jsonStrInput = request.getParameter("jsonString");
		
		
		//create security
		JSONObject jsonObjForSecurity;
		JSONArray jsonSecArray = new JSONArray();
		Security security;
		
		jsonObjForSecurity = new JSONObject(jsonStrInput);
		jsonSecArray = new JSONArray(jsonObjForSecurity.get("SecurityData").toString());
		
		JSONObject tempObj = new JSONObject();
		for (String k : jsonSecArray.getJSONObject(0).keySet()) {
			tempObj.put(k, jsonSecArray.getJSONObject(0).get(k));
		}
		//security = converter.convertBBGMapToSecurity(tempObj.toString());
		if (!jsonObjForSecurity.getString("cusip").equalsIgnoreCase("ni")) {
			security = SecurityConverter.convertBBGMapToSecurity(tempObj.toString());
		} else { 
			security = SecurityConverter.convertNewIssueBBGMapToSecurity(tempObj.toString());
		}
		//end create security
		
		//create allocations map and portID/portCode map
		JSONArray jsonAllocArray = new JSONArray();
		Map<String, Double> allocations = new HashMap<String, Double>();
		Map<Integer, String> portfolioMap = new HashMap<Integer, String>(); //maps PortID to PortfolioCode for restriction checking
		
		jsonAllocArray = new JSONArray(jsonObjForSecurity.get("DashTable").toString());
		for (String k : jsonAllocArray.getJSONObject(0).keySet()) {
			if (k.length() > 16 && k.substring(k.length() - 16).equalsIgnoreCase("ActualAllocation")) {
				allocations.put(k.substring(0, k.length() - 16), Double.parseDouble(jsonAllocArray.getJSONObject(0).get(k).toString().replace(",","")));
			} else if (k.length() > 6 && k.substring(k.length() - 6).equalsIgnoreCase("PortID")) { ///portID
				portfolioMap.put(Integer.parseInt(jsonAllocArray.getJSONObject(0).get(k).toString()), k.substring(0, k.length() - 6).toString());
			}
		}
		//adjust for group restrictions
		double newAlloc = 0;
		Map<String, Double> adjAllocations = new HashMap<String, Double>();
		for (String port : allocations.keySet()) {
			if (singleton.isInRestrictionGroup(singleton.getPortID(port)) && !adjAllocations.containsKey(singleton.getPortCode(singleton.getParentPortfolioGroup(singleton.getPortID(port))))) {
				for (int member : singleton.getPortfolioGroupMembers(singleton.getParentPortfolioGroup(singleton.getPortID(port)))) {
					newAlloc = newAlloc + allocations.get(singleton.getPortCode(member));
				}
				adjAllocations.put(singleton.getPortCode(singleton.getParentPortfolioGroup(singleton.getPortID(port))), newAlloc);
			}
		}
		//end create allocations map and portID/portCode map
		
		Map<String, Object> parsedMap = new HashMap<String, Object>();		
		parsedMap = JSONStringConverter.getTTMapFromJSONString(jsonStrInput);
		
		//check restrictions and indicate if there are any that should prevent the trade submission
		String action = parsedMap.get("action").toString();
		double estimatedPrice = Double.parseDouble(parsedMap.get("price").toString());
		
		//get and double check restrictions
		int breachCount = 0;
		List<Map<String, Object>> secRestrictionResults = SecurityRestrictionChecker.getRestrictionsForArchive(security);

		for (Map<String, Object> rest : secRestrictionResults) {
			//if security restriction is true and allocation > 0
			/*if (rest.get("Result").toString().equalsIgnoreCase("true") && allocations.get(portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0 && action.equalsIgnoreCase("buy")) {
				breachCount++;
				returnObj.put("SecurityBreach" + breachCount, "PortfolioCode:" + portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString())) + " RestrictionID:" + rest.get("RestrictionID") + " RestrictionType:" + rest.get("RestrictionType"));
			}*/
			if (rest.get("Result").toString().equalsIgnoreCase("true") && action.equalsIgnoreCase("buy")) {
				//allocation needs to be adjusted for portfolio groups
				if (singleton.isRestrictionGroup(Integer.parseInt(rest.get("PortfolioID").toString()))) {
					if (adjAllocations.get(singleton.getPortCode(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0) {
						breachCount++;
						returnObj.put("SecurityBreach" + breachCount, " Portfolio: " + singleton.getPortCode(Integer.parseInt(rest.get("PortfolioID").toString())) + " Restriction Description: " + rest.get("RestrictionDesc") + " RestrictionType: " + rest.get("RestrictionType"));
					}
				} else if (allocations.get(portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0) {
					breachCount++;
					returnObj.put("SecurityBreach" + breachCount, " Portfolio: " + portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString())) + " Restriction Description: " + rest.get("RestrictionDesc") + " RestrictionType: " + rest.get("RestrictionType"));
				}
			}
		}
		
		
		List<Map<String, Object>> aggRestrictionResults = null;
		try {
			aggRestrictionResults = AggregateRestrictionChecker.getRestrictionsForArchive(security, action, estimatedPrice, allocations);
		} catch (Exception e1) {
			log.error(e1);
			e1.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e1));
			return returnObj;
		}
		for (Map<String, Object> rest : aggRestrictionResults) {
			//if security restriction is true and allocation > 0
			if (Double.parseDouble(rest.get("Result").toString()) >= 100) {
				if (singleton.isRestrictionGroup(Integer.parseInt(rest.get("PortfolioID").toString())) && adjAllocations.get(singleton.getPortCode(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0) {
					breachCount++;
					returnObj.put("SecurityBreach" + breachCount, " Portfolio: " + singleton.getPortCode(Integer.parseInt(rest.get("PortfolioID").toString())) + " Restriction Description: " + rest.get("RestrictionDesc") + " RestrictionType: " + rest.get("RestrictionType"));
				} else if (allocations.get(portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0) {
					breachCount++;
					returnObj.put("SecurityBreach" + breachCount, " Portfolio: " + portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString())) + " Restriction Description: " + rest.get("RestrictionDesc") + " RestrictionType: " + rest.get("RestrictionType"));
				}
			}
		}
		
		//for security breaches i.e. restriction breaches
		if (! returnObj.keySet().isEmpty()) { //if there are restrictions, return jsonObj
			returnObj.put("errors", "true");
			return returnObj;
		}
		
		
		
		//STEP 2 - SUBMIT TRADE
		Map<String, Object> insertData = new HashMap<String, Object>(); ///for inserts into SQL tables
		
		jsonStrInput = request.getParameter("jsonString");
		JSONObject inputObj = new JSONObject(jsonStrInput);	
		
		//insert trade into custMoxyOrderImport 
		insertData.put("SecType", inputObj.get(TT_SEC_TYPE));
		insertData.put("Symbol", inputObj.get(TT_CUSIP)); //will need to be changed for loans/stocks
		insertData.put("TranType", inputObj.getString(TT_ACTION).equalsIgnoreCase("buy") ? "by" : "sl");
		insertData.put("Price", inputObj.get(TT_PRICE));
		insertData.put("Quantity", Double.parseDouble(inputObj.get(TT_TOTAL_ALLOCATION).toString()) * Security.getQuantityFactor(inputObj.getString(TT_SEC_TYPE)));
		insertData.put("Limit", StringEscapeUtils.escapeSql(inputObj.get(TT_LIMIT_COMMENT).toString()));
		insertData.put("Instructions", StringEscapeUtils.escapeSql(inputObj.get(TT_TIMING_COMMENT).toString()));
		insertData.put("Comment", StringEscapeUtils.escapeSql(inputObj.get(TT_OTHER_COMMENT).toString()));
		insertData.put("UserID", moxyUserId);
		
		int importOrderID = 0;
		try {
			importOrderID = MoxyTableWrite.insertRow("custMoxyOrderImport", insertData);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}
		
		//inserts for allocations into custMoxyOrderAllocationImport
		insertData = new HashMap<String, Object>();
		String portCode = null;
		double allocation = 0.0;
		@SuppressWarnings("unused")
		int result;
		
		JSONArray dashTableArray = new JSONArray(inputObj.get("DashTable").toString());
		JSONObject dashObj = new JSONObject();
		for (String k : dashTableArray.getJSONObject(0).keySet()) {
			dashObj.put(k, dashTableArray.getJSONObject(0).get(k));
		}
		
		for (String key : dashObj.keySet()) {
			if (key.length() > 16 && key.substring(key.length() - 16).equalsIgnoreCase("ActualAllocation") && Double.parseDouble(dashObj.getString(key).replace(",","")) > 0) {
				portCode = key.substring(0, key.length() - 16);
				allocation = Double.parseDouble(dashObj.getString(key).replace(",","")) * Security.getQuantityFactor(inputObj.getString(TT_SEC_TYPE));
				
				insertData.put("ImportOrderID", importOrderID);
				insertData.put("PortfolioID", portCode);
				insertData.put("Quantity", allocation);
				insertData.put("SettleCashKey", null);
				insertData.put("CustodianID ", null);
				
				try {
					result = MoxyTableWrite.insertRow("custMoxyOrderAllocationImport", insertData);
				} catch (TradeTicketDBException e) {
					log.error(e);
					e.printStackTrace();
					returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
					return returnObj;
				}
				
				insertData = new HashMap<String, Object>();
			}			
		}
		
		//execute pCustImportMoxyOrder <ImportOrderID>
		Map<Integer, Object> procParams = new HashMap<Integer, Object>();
		procParams.put(1, importOrderID);
		try {
			MoxyTableWrite.executeStoredProcNoReturn("pCustImportMoxyOrder", procParams);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		} catch (FilterException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}
		
		returnObj.put("Message", "Trade successfully submitted.  Trade was not archived");		
		
		
		//STEP 3 - ARCHIVE!		
		//do inserts for each table
		Map<String, Object> rowData = new HashMap<String, Object>();
		int rowID = 0;
		int tradeID;
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		String timeStamp = sdf.format(date);
		
		//trade table
		rowData.put("UserID", userId);
		rowData.put("SecurityType", security.getValue(SecurityField.SECTYPE_OVERRIDE).toString());
		rowData.put("CUSIP", security.getValue(SecurityField.CUSIP).toString());
		rowData.put("EstPrice", Double.parseDouble(parsedMap.get("price").toString()));
		rowData.put("Action", parsedMap.get("action").toString());
		rowData.put("SecurityJSONString", jsonObjForSecurity.get("SecurityData").toString());
		rowData.put("TradeComments", parsedMap.get("tradeComments").toString());
		rowData.put("TradeTiming", parsedMap.get("tradeTiming").toString());
		rowData.put("TradeLimit", parsedMap.get("tradeLimit").toString());
		rowData.put("OrderDate", timeStamp);
		
		try {
			rowID = TableWrite.insertRow(TRADE_ARCHIVE_TABLE, rowData);
		} catch (TradeTicketDBException e) {
			log.error(e);
			e.printStackTrace();
			returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
			return returnObj;
		}
		tradeID = rowID;
		
		//restriction table
		rowData = new HashMap<String, Object>();
		
		for (Map<String, Object> rest : secRestrictionResults) {
			rowData.put("TradeID", tradeID);
			for (String colName : rest.keySet()) {
				if (!(colName.equalsIgnoreCase("PortfolioCode") || colName.equalsIgnoreCase("RestrictionDesc"))) {
					rowData.put(colName, rest.get(colName));
				}
			}
			try {
				rowID = TableWrite.insertRow(RESTRICTIONS_ARCHIVE_TABLE, rowData);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return returnObj;
			}
			rowData = new HashMap<String, Object>();
		}
		
		for (Map<String, Object> rest : aggRestrictionResults) {
			rowData.put("TradeID", tradeID);
			for (String colName : rest.keySet()) {
				if (!(colName.equalsIgnoreCase("PortfolioCode") || colName.equalsIgnoreCase("RestrictionDesc"))) {
					rowData.put(colName, rest.get(colName));
				}
			}
			try {
				rowID = TableWrite.insertRow(RESTRICTIONS_ARCHIVE_TABLE, rowData);
			} catch (TradeTicketDBException e) {
				log.error(e);
				e.printStackTrace();
				returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
				return returnObj;
			}
			rowData = new HashMap<String, Object>();
		}
		
		//allocation table	
		//first need to create map of maps for each portfolio with portfolio code
		Map<String, Object> dashMap = JSONArraySort.sortArray(jsonAllocArray);
		portCode = null;
		String prevPortCode = null;
		List<String> allocationTableColumns = new ArrayList<String>();
		
		allocationTableColumns.add("PortID");
		allocationTableColumns.add("MarketValueAI");
		allocationTableColumns.add("CashPct");
		allocationTableColumns.add("PreAllocatedCash");
		allocationTableColumns.add("NAVAdjustment");
		allocationTableColumns.add("SecurityRestriction");
		allocationTableColumns.add("AggregateRestriction");
		allocationTableColumns.add("PctRelativeToTarget");
		allocationTableColumns.add("SecHoldings");
		allocationTableColumns.add("ActualAllocation");
		allocationTableColumns.add("AllocationOverride");
		allocationTableColumns.add("SecHoldingsPct");
		allocationTableColumns.add("ProFormaSecHoldingsPct");
		allocationTableColumns.add("TickerHoldingsPct");
		allocationTableColumns.add("ProFormaTickerHoldingsPct");
		allocationTableColumns.add("MinPiece");
		allocationTableColumns.add("Notes");
		
		//first column is "ActualAllocation", ie first key in dashMap should be an ActualAllocation key
		for (String key : dashMap.keySet()) {
			if (key.length() > 16 && key.substring(key.length() - 16).equalsIgnoreCase("ActualAllocation")) {
				portCode = key.substring(0, key.length() - 16);
			} else {
				portCode = null;
			}
			if (portCode != null && !portCode.equalsIgnoreCase(prevPortCode)) {
				rowData.put("TradeID", tradeID);
				for (String column : allocationTableColumns) {
					rowData.put(column, dashMap.get(portCode + ((column.equalsIgnoreCase("Notes") ? "SecSpecificNotes" : column))));
				}				
				prevPortCode = portCode;
				try {
					rowID = TableWrite.insertRow(ALLOCATIONS_ARCHIVE_TABLE, rowData);
				} catch (TradeTicketDBException e) {
					log.error(e);
					e.printStackTrace();
					returnObj.put("ERROR", ErrorHandlingUtility.getStackTraceString(e));
					return returnObj;
				}
				rowData = new HashMap<String, Object>();
			}			
		}
		
		
		returnObj.put("Message", "Trade successfully submitted and archived.");
		
		return returnObj;
	}

}
