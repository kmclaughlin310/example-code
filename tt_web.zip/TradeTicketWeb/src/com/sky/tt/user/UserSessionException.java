package com.sky.tt.user;

public class UserSessionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1211673367754888721L;

	public UserSessionException() {
		super();
	}

	public UserSessionException(String message) {
		super(message);
	}

	public UserSessionException(Throwable cause) {
		super(cause);
	}

	public UserSessionException(String message, Throwable cause) {
		super(message, cause);
	}
}
