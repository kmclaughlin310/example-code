package com.sky.tt.db.filter;

import java.sql.PreparedStatement;

public interface Filter {
	
	public String getWhereClause();
	
	public void setParameters(PreparedStatement stmt, int startParameterId);
	
	public String getOrderByClause();
	
	public String getOrderByField();		
	
}





/*package com.sky.skyaudit.db.filter;

import java.sql.PreparedStatement;

public interface AuditFilter {
	
	public String getWhereClause() throws AuditFilterException;
	
	public void setParameters(PreparedStatement stmt, int startParameterId) throws AuditFilterException;
	
	public String getOrderByClause() throws AuditFilterException;
	
	public String getOrderByField() throws AuditFilterException;
	
}
*/