package com.sky.tt.strategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;

public class StrategyUtility {
	
	private static final Logger log = Logger.getLogger(StrategyUtility.class);
	
	public List<String> getStrategiesFromDB() {
		
		List<String> strategyList = new ArrayList<String>();
		List<Map<String, Object>> dbStrategyList = null;
		
		try {
			dbStrategyList = TableQuery.getRows("CustomTradeTicket.Strategies");
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
			log.error(e);
			return null;
		}
		
		for (Map<String, Object> strat : dbStrategyList) {
			strategyList.add(strat.get("StrategyShortCode").toString());
		}
		
		return strategyList;
	}

}
