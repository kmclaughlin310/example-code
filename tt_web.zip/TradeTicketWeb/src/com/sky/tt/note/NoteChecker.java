package com.sky.tt.note;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.query.TableQuery;
import com.sky.tt.handler.JSONHandlerDashNotes;
import com.sky.tt.security.Security;

public class NoteChecker {
	
	private static final Logger log = Logger.getLogger(JSONHandlerDashNotes.class);

	public static Map<String, String> checkNotes(Security security, Map<String, Object> tradeTicketData) {
		//map portfolio code to note result
		List<Map<String, Object>> noteList = null;
		TradeTicketNote note = null;
		Map<String, String> results = new HashMap<String, String>();
		
		try {
			noteList = TableQuery.getRows("CustomTradeTicket.vNotes");
		} catch (TradeTicketDBException e1) {
			log.error(e1);
			e1.printStackTrace();
			return null;
		}

		for(Map<String, Object> n : noteList) {
			Class<TradeTicketNote> clazz = null;
			try {
				clazz = (Class<TradeTicketNote>) Class.forName(n.get("JavaClassName").toString());
			} catch (ClassNotFoundException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			}
			
			Constructor<TradeTicketNote> ctor = null;

			try {
				ctor = clazz.getConstructor(int.class);
			} catch (NoSuchMethodException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			} catch (SecurityException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			}

			
			try {
				note = ctor.newInstance(Integer.parseInt(n.get("NoteID").toString()));
			} catch (NumberFormatException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			} catch (InstantiationException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			} catch (IllegalAccessException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			} catch (IllegalArgumentException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			} catch (InvocationTargetException e) {
				log.error(e);
				e.printStackTrace();
				return null;
			}
			
			try {
				note.init();
			} catch (Exception e) {
				log.error(e);
				e.printStackTrace();
				return null;
			}
			
			if (results.containsKey(n.get("PortfolioCode").toString())) {
				results.put(n.get("PortfolioCode").toString(), results.get(n.get("PortfolioCode").toString()) + " " + note.getNote(security, tradeTicketData));
			} else {
				results.put(n.get("PortfolioCode").toString(), note.getNote(security, tradeTicketData));
			}
		}	
		return results;		
	}
}
