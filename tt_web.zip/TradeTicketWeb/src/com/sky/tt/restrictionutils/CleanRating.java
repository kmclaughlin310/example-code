package com.sky.tt.restrictionutils;

public class CleanRating {
	
	public static String getCleanRating(String rawRating) {
		if (rawRating == null) {
			return null;
		} else if (rawRating.endsWith("u") || rawRating.endsWith("e")) {
			return rawRating.substring(0, rawRating.length() - 1);
		} else if (rawRating.startsWith("(P)")) {
			return rawRating.substring(3);
		} else {
			return rawRating;
		}		
	}
	
}
