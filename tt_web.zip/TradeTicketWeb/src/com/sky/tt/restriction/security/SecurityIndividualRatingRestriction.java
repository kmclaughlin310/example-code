package com.sky.tt.restriction.security;

import org.apache.log4j.Logger;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.restrictionutils.Inequality;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton;
import com.sky.tt.security.ratingcalc.RatingConverterSingleton.RatingType;

public class SecurityIndividualRatingRestriction extends SecurityRestriction{
	
	private static final Logger log = Logger.getLogger(SecurityIndividualRatingRestriction.class);
	
	private static final String SECURITY_RATING_RESTRICTION_VALUE = "RatingRestrictionValue";
	private static final String INEQUALITY_PARAMETER_NAME = "InequalitySymbol";
	private static final String INCLUDE_EPU_RATINGS_PARAMETER_NAME = "IncludeEPURatings";
	
	protected double restrictionValue;
	protected Inequality inequal;
	protected boolean includeEPURatings = false;

	public SecurityIndividualRatingRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		
		restrictionValue = Double.parseDouble(parameterMap.get(SECURITY_RATING_RESTRICTION_VALUE).toString());
		inequal = Inequality.getInequality((parameterMap.get(INEQUALITY_PARAMETER_NAME).toString()));
		if (parameterMap.containsKey(INCLUDE_EPU_RATINGS_PARAMETER_NAME)) {
			includeEPURatings = (parameterMap.get(INCLUDE_EPU_RATINGS_PARAMETER_NAME).toString().equalsIgnoreCase("Y") ? true : false);
		}
		
	}

	@Override
	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			// exclude no ratings		
			double spRating = 0;
			double mdyRating = 0;
			double fitchRating = 0;
			
			RatingConverterSingleton converter = null;
			try {
				converter = RatingConverterSingleton.getInstance();
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
				log.error(e);
				restrictionTested = false;
				restrictionResult = true;
				return true;
			}
			
			
			spRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_SP, includeEPURatings);
			mdyRating = converter.getNumericSecurityRating(security, RatingType.MOODY, SecurityField.RAW_MOODY, includeEPURatings);
			fitchRating = converter.getNumericSecurityRating(security, RatingType.SP_FITCH, SecurityField.RAW_FITCH, includeEPURatings);
			
			restrictionResultText = "SP: " + converter.getSPRatingText(spRating)
						+ "Mdy: " + converter.getMoodyRatingText(mdyRating)
						+ "Ftch: " + converter.getSPRatingText(fitchRating);
			

			
			switch (inequal) { //rating must be > 0 to count as an actual rating
			case LT:
				restrictionResult = ((spRating >= restrictionValue) 
						|| (mdyRating >= restrictionValue) 
						|| (fitchRating >= restrictionValue));
				break;
			case GT:
				restrictionResult = ((spRating <= restrictionValue && spRating > 0) 
						|| (mdyRating <= restrictionValue && mdyRating > 0) 
						|| (fitchRating <= restrictionValue && fitchRating > 0));
				break;
			case LTE:
				restrictionResult = ((spRating > restrictionValue) 
						|| (mdyRating > restrictionValue) 
						|| (fitchRating > restrictionValue));
				break;
			case GTE:
				restrictionResult = ((spRating < restrictionValue && spRating > 0) 
						|| (mdyRating < restrictionValue && mdyRating > 0) 
						|| (fitchRating < restrictionValue && fitchRating > 0));
				break;

			default:
				restrictionResult =  true;	
				break;
			}
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 
		
		restrictionTested = true;
		return restrictionResult;
		
	}

}
