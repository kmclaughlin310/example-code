package com.sky.tt.handler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.sky.tt.db.connection.TradeTicketDBException;
import com.sky.tt.db.write.TableWrite;
import com.sky.tt.jsonconvert.JSONStringConverter;
import com.sky.tt.restriction.AggregateRestrictionChecker;
import com.sky.tt.restriction.SecurityRestrictionChecker;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityConverter;
import com.sky.tt.security.SecurityField;
import com.sky.tt.user.UserNotFoundException;
import com.sky.tt.user.UserNotLoggedInException;
import com.sky.tt.user.UserSession;
import com.sky.tt.user.UserSessionException;
import com.sky.util.JSONArraySort;



public class PreTradeSubmitServlet extends JSONHandlerServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8947657720745851016L;
	
	private static final String TRADE_ARCHIVE_TABLE = "CustomTradeTktArchive.Trade";
	private static final String ALLOCATIONS_ARCHIVE_TABLE = "CustomTradeTktArchive.Allocation";
	private static final String RESTRICTIONS_ARCHIVE_TABLE = "CustomTradeTktArchive.Restriction";
	
	private static final Logger log = Logger.getLogger(PreTradeSubmitServlet.class);
	
	protected JSONObject handleRequest(HttpServletRequest request) throws ServletException, IOException {
		JSONObject jsonObj = new JSONObject();
		
		String jsonStrInput = request.getParameter("jsonString");
		
		
		//create security
		JSONObject jsonObjForSecurity;
		JSONArray jsonSecArray = new JSONArray();
		Security security;
		
		jsonObjForSecurity = new JSONObject(jsonStrInput);
		jsonSecArray = new JSONArray(jsonObjForSecurity.get("SecurityData").toString());
		
		JSONObject tempObj = new JSONObject();
		for (String k : jsonSecArray.getJSONObject(0).keySet()) {
			tempObj.put(k, jsonSecArray.getJSONObject(0).get(k));
		}
		//security = converter.convertBBGMapToSecurity(tempObj.toString());
		if (!jsonObjForSecurity.getString("cusip").equalsIgnoreCase("ni")) {
			security = SecurityConverter.convertBBGMapToSecurity(tempObj.toString());
		} else { 
			security = SecurityConverter.convertNewIssueBBGMapToSecurity(tempObj.toString());
		}
		//end create security
		
		//create allocations map and portID/portCode map
		JSONArray jsonAllocArray = new JSONArray();
		Map<String, Double> allocations = new HashMap<String, Double>();
		Map<Integer, String> portfolioMap = new HashMap<Integer, String>(); //maps PortID to PortfolioCode for restriction checking
		
		jsonAllocArray = new JSONArray(jsonObjForSecurity.get("DashTable").toString());
		for (String k : jsonAllocArray.getJSONObject(0).keySet()) {
			if (k.length() > 16 && k.substring(k.length() - 16).equalsIgnoreCase("ActualAllocation")) {
				allocations.put(k.substring(0, k.length() - 16), Double.parseDouble(jsonAllocArray.getJSONObject(0).get(k).toString().replace(",","")));
			} else if (k.length() > 6 && k.substring(k.length() - 6).equalsIgnoreCase("PortID")) { ///portID
				portfolioMap.put(Integer.parseInt(jsonAllocArray.getJSONObject(0).get(k).toString()), k.substring(0, k.length() - 6).toString());
			}
		}
		//end create allocations map and portID/portCode map
		
		
		Map<String, Object> parsedMap = new HashMap<String, Object>();		
		parsedMap = JSONStringConverter.getTTMapFromJSONString(jsonStrInput);
		
		//check restrictions and indicate if there are any that should prevent the trade submission
		String action = parsedMap.get("action").toString();
		double estimatedPrice = Double.parseDouble(parsedMap.get("price").toString());
		
		//get and double check restrictions
		int breachCount = 0;
		List<Map<String, Object>> secRestrictionResults = SecurityRestrictionChecker.getRestrictionsForArchive(security);
		for (Map<String, Object> rest : secRestrictionResults) {
			//if security restriction is true and allocation > 0
			if (rest.get("Result").toString().equalsIgnoreCase("true") && allocations.get(portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0) {
				breachCount++;
				jsonObj.put("SecurityBreach" + breachCount, "PortfolioCode:" + portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString())) + " RestrictionID:" + rest.get("RestrictionID") + " RestrictionType:" + rest.get("RestrictionType"));
			}
		}
		
		
		List<Map<String, Object>> aggRestrictionResults = null;
		try {
			aggRestrictionResults = AggregateRestrictionChecker.getRestrictionsForArchive(security, action, estimatedPrice, allocations);
		} catch (Exception e1) {
			e1.printStackTrace();
			log.debug(e1);
		}
		for (Map<String, Object> rest : aggRestrictionResults) {
			//if security restriction is true and allocation > 0
			if (Double.parseDouble(rest.get("Result").toString()) >= 100 && allocations.get(portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString()))) > 0) {
				breachCount++;
				jsonObj.put("SecurityBreach" + breachCount, "Portfolio:" + portfolioMap.get(Integer.parseInt(rest.get("PortfolioID").toString())) + " RestrictionID:" + rest.get("RestrictionID") + " RestrictionType:" + rest.get("RestrictionType"));
			}
		}
		
		if (! jsonObj.keySet().isEmpty()) { //if there are restrictions, return jsonObj
			jsonObj.put("errors", "true");
			return jsonObj;
		}
		
		
		//do inserts for each table
		Map<String, Object> rowData = new HashMap<String, Object>();
		int rowID = 0;
		int tradeID;
		
		//trade table
		try {
			rowData.put("UserID",  UserSession.getUserSessionFromRequest(request).getUser().getUserID());
		} catch (UserNotFoundException e) {
			e.printStackTrace();
		} catch (UserNotLoggedInException e) {
			e.printStackTrace();
		} catch (UserSessionException e) {
			e.printStackTrace();
		}
		rowData.put("SecurityType", security.getValue(SecurityField.SECTYPE_OVERRIDE).toString());
		rowData.put("CUSIP", security.getValue(SecurityField.CUSIP).toString());
		rowData.put("EstPrice", Double.parseDouble(parsedMap.get("price").toString()));
		rowData.put("Action", parsedMap.get("action").toString());
		rowData.put("SecurityJSONString", jsonObjForSecurity.get("SecurityData").toString());
		rowData.put("TradeComments", parsedMap.get("tradeComments").toString());
		rowData.put("TradeTiming", parsedMap.get("tradeTiming").toString());
		rowData.put("TradeLimit", parsedMap.get("tradeLimit").toString());
		
		//restriction table
		try {
			rowID = TableWrite.insertRow(TRADE_ARCHIVE_TABLE, rowData);
		} catch (TradeTicketDBException e) {
			e.printStackTrace();
		}
		tradeID = rowID;
		
		rowData = new HashMap<String, Object>();
		
		for (Map<String, Object> rest : secRestrictionResults) {
			rowData.put("TradeID", tradeID);
			for (String colName : rest.keySet()) {
				rowData.put(colName, rest.get(colName));
			}
			try {
				rowID = TableWrite.insertRow(RESTRICTIONS_ARCHIVE_TABLE, rowData);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
			}
			rowData = new HashMap<String, Object>();
		}
		
		for (Map<String, Object> rest : aggRestrictionResults) {
			rowData.put("TradeID", tradeID);
			for (String colName : rest.keySet()) {
				rowData.put(colName, rest.get(colName));
			}
			try {
				rowID = TableWrite.insertRow(RESTRICTIONS_ARCHIVE_TABLE, rowData);
			} catch (TradeTicketDBException e) {
				e.printStackTrace();
			}
			rowData = new HashMap<String, Object>();
		}
		
		//allocation table	
		//first need to create map of maps for each portfolio with portfolio code
		Map<String, Object> dashMap = JSONArraySort.sortArray(jsonAllocArray);
		String portCode = null;
		String prevPortCode = null;
		List<String> allocationTableColumns = new ArrayList<String>();
		
		allocationTableColumns.add("PortID");
		allocationTableColumns.add("MarketValueAI");
		allocationTableColumns.add("CashPct");
		allocationTableColumns.add("PreAllocatedCash");
		allocationTableColumns.add("NAVAdjustment");
		allocationTableColumns.add("SecurityRestriction");
		allocationTableColumns.add("AggregateRestriction");
		allocationTableColumns.add("PctRelativeToTarget");
		allocationTableColumns.add("SecHoldings");
		allocationTableColumns.add("ActualAllocation");
		allocationTableColumns.add("AllocationOverride");
		allocationTableColumns.add("SecHoldingsPct");
		allocationTableColumns.add("ProFormaSecHoldingsPct");
		allocationTableColumns.add("TickerHoldingsPct");
		allocationTableColumns.add("ProFormaTickerHoldingsPct");
		allocationTableColumns.add("MinPiece");
		allocationTableColumns.add("Notes");
		
		//first column is "ActualAllocation", ie first key in dashMap should be an ActualAllocation key
		for (String key : dashMap.keySet()) {
			if (key.length() > 16 && key.substring(key.length() - 16).equalsIgnoreCase("ActualAllocation")) {
				portCode = key.substring(0, key.length() - 16);
			}
			if (portCode != null && !portCode.equalsIgnoreCase(prevPortCode)) {
				rowData.put("TradeID", tradeID);
				for (String column : allocationTableColumns) {
					rowData.put(column, dashMap.get(portCode + column));
				}				
				prevPortCode = portCode;
				try {
					rowID = TableWrite.insertRow(ALLOCATIONS_ARCHIVE_TABLE, rowData);
				} catch (TradeTicketDBException e) {
					e.printStackTrace();
				}
				rowData = new HashMap<String, Object>();
			}			
		}
		
		
		

		//what to return?
		/*String jsonStrOutput;
		jsonStrOutput = JSONStringConverter.getJSONForTTHoldings(allocations);*/
		//jsonObj = new JSONObject(jsonStrOutput);
		jsonObj.put("errors", "false");
		
		return jsonObj;
	}
	
}
