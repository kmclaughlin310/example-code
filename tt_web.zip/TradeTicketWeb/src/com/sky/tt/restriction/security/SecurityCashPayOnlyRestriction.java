package com.sky.tt.restriction.security;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityCashPayOnlyRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityCashPayOnlyRestriction.class);
	
	public SecurityCashPayOnlyRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
	}

	@Override
	public boolean checkRestriction(Security security, Portfolio portfolio) {
		
		restrictionResultText = security.getValue(SecurityField.COUPON_TYPE).toString();
		
		try {		
			if ((security.getValue(SecurityField.COUPON_TYPE).toString().equalsIgnoreCase("pay-in-kind") && Double.parseDouble(security.getValue(SecurityField.INTEREST_ACCRUED).toString()) == 0) || security.getValue(SecurityField.COUPON_TYPE).toString().equalsIgnoreCase("zero coupon")) {
				restrictionTested = true;
				restrictionResult = true;
				return true;
			} else {
				restrictionTested = true;
				restrictionResult = false;
				return false;
			}
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			restrictionResult = true;
			return true;
		} 

	}
}
