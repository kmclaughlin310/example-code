package com.sky.tt.restriction.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.sky.tt.portfolio.Portfolio;
import com.sky.tt.restriction.SecurityRestriction;
import com.sky.tt.security.Security;
import com.sky.tt.security.SecurityField;

public class SecurityAllCountryFieldsRestriction extends SecurityRestriction {
	private static final Logger log = Logger.getLogger(SecurityAllCountryFieldsRestriction.class);
	private static final String RESTRICTED_COUNTRIES_PARAMETER_NAME = "RestrictedCountryList";
	
	protected String restrictedCountryString;

	public SecurityAllCountryFieldsRestriction(int restrictionId) {
		super(restrictionId);
	}
	
	public void init() throws Exception {
		super.init();
		restrictedCountryString = parameterMap.get(RESTRICTED_COUNTRIES_PARAMETER_NAME).toString();		
	}

	public boolean checkRestriction(Security security, Portfolio portfolio) {
		try {
			
			restrictionResultText = security.getValue(SecurityField.COUNTRY_INCORP).toString() + ", " 
					+ security.getValue(SecurityField.ISSUE_COUNTRY).toString() + ", "
					+ security.getValue(SecurityField.RISK_COUNTRY).toString();
			
			//RETURN TRUE IF VIOLATION
			List<String> restrictedCountryList = new ArrayList<String>(Arrays.asList(restrictedCountryString.split("\\s*,\\s*")));
			
			//to make list case insensitive
			Set<String> restrictionListNoCase = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
			restrictionListNoCase.addAll(restrictedCountryList);
			
			//check country of incorporation, country of domicile, and country of risk
			if (restrictionListNoCase.contains(security.getValue(SecurityField.COUNTRY_INCORP).toString()) || restrictionListNoCase.contains(security.getValue(SecurityField.ISSUE_COUNTRY).toString()) || restrictionListNoCase.contains(security.getValue(SecurityField.RISK_COUNTRY).toString())) {
				restrictionTested = true;
				restrictionResult = true;
				return true;
			}
			restrictionTested = true;
			restrictionResult = false;
			return false;
		} catch (Exception e) {
			log.error(e);
			restrictionTested = false;
			return true;
		} 
		
	}
	
	@Override
	public String getRestrictedListText() {
		return restrictedCountryString;
	}

}
